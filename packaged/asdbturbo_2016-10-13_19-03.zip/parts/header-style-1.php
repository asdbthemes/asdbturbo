<?php
get_template_part('parts/sections/nav-topbar');
get_template_part('parts/sections/site-branding');
get_template_part('parts/sections/nav-header');
get_template_part('parts/sections/nav-subheader');
//if(!is_front_page()) {
get_template_part('parts/sections/section-page-title');
//} else {
//get_template_part('parts/sections/section-top-news');
//}
//if(!is_front_page()) {get_template_part('parts/sections/section-breadcrumbs');}
?>