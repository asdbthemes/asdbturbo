<?php get_template_part('parts/sections/nav-footer'); ?>
<?php get_template_part('parts/sections/footer-widget-area'); ?>
<?php get_template_part('parts/sections/subfooter'); ?>
