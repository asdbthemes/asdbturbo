( function( $ ) {
      $(document).on("click", ".cmb-radio-image", function() {
        $(this).closest(".cmb-type-radio-image").find(".cmb-radio-image").removeClass("cmb-radio-image-selected");
        $(this).toggleClass("cmb-radio-image-selected");
      });
} )( jQuery );

/*!
 * jQuery Form Plugin
 * version: 3.51.0-2014.06.20
 * Requires jQuery v1.5 or later
 * Copyright (c) 2014 M. Alsup
 * Examples and documentation at: http://malsup.com/jquery/form/
 * Project repository: https://github.com/malsup/form
 * Dual licensed under the MIT and GPL licenses.
 * https://github.com/malsup/form#copyright-and-license
 */
/*global ActiveXObject */

// AMD support
(function (factory) {
    "use strict";
    if (typeof define === 'function' && define.amd) {
        // using AMD; register as anon module
        define(['jquery'], factory);
    } else {
        // no AMD; invoke directly
        factory( (typeof(jQuery) != 'undefined') ? jQuery : window.Zepto );
    }
}

(function($) {
"use strict";

/*
    Usage Note:
    -----------
    Do not use both ajaxSubmit and ajaxForm on the same form.  These
    functions are mutually exclusive.  Use ajaxSubmit if you want
    to bind your own submit handler to the form.  For example,

    $(document).ready(function() {
        $('#myForm').on('submit', function(e) {
            e.preventDefault(); // <-- important
            $(this).ajaxSubmit({
                target: '#output'
            });
        });
    });

    Use ajaxForm when you want the plugin to manage all the event binding
    for you.  For example,

    $(document).ready(function() {
        $('#myForm').ajaxForm({
            target: '#output'
        });
    });

    You can also use ajaxForm with delegation (requires jQuery v1.7+), so the
    form does not have to exist when you invoke ajaxForm:

    $('#myForm').ajaxForm({
        delegation: true,
        target: '#output'
    });

    When using ajaxForm, the ajaxSubmit function will be invoked for you
    at the appropriate time.
*/

/**
 * Feature detection
 */
var feature = {};
feature.fileapi = $("<input type='file'/>").get(0).files !== undefined;
feature.formdata = window.FormData !== undefined;

var hasProp = !!$.fn.prop;

// attr2 uses prop when it can but checks the return type for
// an expected string.  this accounts for the case where a form 
// contains inputs with names like "action" or "method"; in those
// cases "prop" returns the element
$.fn.attr2 = function() {
    if ( ! hasProp ) {
        return this.attr.apply(this, arguments);
    }
    var val = this.prop.apply(this, arguments);
    if ( ( val && val.jquery ) || typeof val === 'string' ) {
        return val;
    }
    return this.attr.apply(this, arguments);
};

/**
 * ajaxSubmit() provides a mechanism for immediately submitting
 * an HTML form using AJAX.
 */
$.fn.ajaxSubmit = function(options) {
    /*jshint scripturl:true */

    // fast fail if nothing selected (http://dev.jquery.com/ticket/2752)
    if (!this.length) {
        log('ajaxSubmit: skipping submit process - no element selected');
        return this;
    }

    var method, action, url, $form = this;

    if (typeof options == 'function') {
        options = { success: options };
    }
    else if ( options === undefined ) {
        options = {};
    }

    method = options.type || this.attr2('method');
    action = options.url  || this.attr2('action');

    url = (typeof action === 'string') ? $.trim(action) : '';
    url = url || window.location.href || '';
    if (url) {
        // clean url (don't include hash vaue)
        url = (url.match(/^([^#]+)/)||[])[1];
    }

    options = $.extend(true, {
        url:  url,
        success: $.ajaxSettings.success,
        type: method || $.ajaxSettings.type,
        iframeSrc: /^https/i.test(window.location.href || '') ? 'javascript:false' : 'about:blank'
    }, options);

    // hook for manipulating the form data before it is extracted;
    // convenient for use with rich editors like tinyMCE or FCKEditor
    var veto = {};
    this.trigger('form-pre-serialize', [this, options, veto]);
    if (veto.veto) {
        log('ajaxSubmit: submit vetoed via form-pre-serialize trigger');
        return this;
    }

    // provide opportunity to alter form data before it is serialized
    if (options.beforeSerialize && options.beforeSerialize(this, options) === false) {
        log('ajaxSubmit: submit aborted via beforeSerialize callback');
        return this;
    }

    var traditional = options.traditional;
    if ( traditional === undefined ) {
        traditional = $.ajaxSettings.traditional;
    }

    var elements = [];
    var qx, a = this.formToArray(options.semantic, elements);
    if (options.data) {
        options.extraData = options.data;
        qx = $.param(options.data, traditional);
    }

    // give pre-submit callback an opportunity to abort the submit
    if (options.beforeSubmit && options.beforeSubmit(a, this, options) === false) {
        log('ajaxSubmit: submit aborted via beforeSubmit callback');
        return this;
    }

    // fire vetoable 'validate' event
    this.trigger('form-submit-validate', [a, this, options, veto]);
    if (veto.veto) {
        log('ajaxSubmit: submit vetoed via form-submit-validate trigger');
        return this;
    }

    var q = $.param(a, traditional);
    if (qx) {
        q = ( q ? (q + '&' + qx) : qx );
    }
    if (options.type.toUpperCase() == 'GET') {
        options.url += (options.url.indexOf('?') >= 0 ? '&' : '?') + q;
        options.data = null;  // data is null for 'get'
    }
    else {
        options.data = q; // data is the query string for 'post'
    }

    var callbacks = [];
    if (options.resetForm) {
        callbacks.push(function() { $form.resetForm(); });
    }
    if (options.clearForm) {
        callbacks.push(function() { $form.clearForm(options.includeHidden); });
    }

    // perform a load on the target only if dataType is not provided
    if (!options.dataType && options.target) {
        var oldSuccess = options.success || function(){};
        callbacks.push(function(data) {
            var fn = options.replaceTarget ? 'replaceWith' : 'html';
            $(options.target)[fn](data).each(oldSuccess, arguments);
        });
    }
    else if (options.success) {
        callbacks.push(options.success);
    }

    options.success = function(data, status, xhr) { // jQuery 1.4+ passes xhr as 3rd arg
        var context = options.context || this ;    // jQuery 1.4+ supports scope context
        for (var i=0, max=callbacks.length; i < max; i++) {
            callbacks[i].apply(context, [data, status, xhr || $form, $form]);
        }
    };

    if (options.error) {
        var oldError = options.error;
        options.error = function(xhr, status, error) {
            var context = options.context || this;
            oldError.apply(context, [xhr, status, error, $form]);
        };
    }

     if (options.complete) {
        var oldComplete = options.complete;
        options.complete = function(xhr, status) {
            var context = options.context || this;
            oldComplete.apply(context, [xhr, status, $form]);
        };
    }

    // are there files to upload?

    // [value] (issue #113), also see comment:
    // https://github.com/malsup/form/commit/588306aedba1de01388032d5f42a60159eea9228#commitcomment-2180219
    var fileInputs = $('input[type=file]:enabled', this).filter(function() { return $(this).val() !== ''; });

    var hasFileInputs = fileInputs.length > 0;
    var mp = 'multipart/form-data';
    var multipart = ($form.attr('enctype') == mp || $form.attr('encoding') == mp);

    var fileAPI = feature.fileapi && feature.formdata;
    log("fileAPI :" + fileAPI);
    var shouldUseFrame = (hasFileInputs || multipart) && !fileAPI;

    var jqxhr;

    // options.iframe allows user to force iframe mode
    // 06-NOV-09: now defaulting to iframe mode if file input is detected
    if (options.iframe !== false && (options.iframe || shouldUseFrame)) {
        // hack to fix Safari hang (thanks to Tim Molendijk for this)
        // see:  http://groups.google.com/group/jquery-dev/browse_thread/thread/36395b7ab510dd5d
        if (options.closeKeepAlive) {
            $.get(options.closeKeepAlive, function() {
                jqxhr = fileUploadIframe(a);
            });
        }
        else {
            jqxhr = fileUploadIframe(a);
        }
    }
    else if ((hasFileInputs || multipart) && fileAPI) {
        jqxhr = fileUploadXhr(a);
    }
    else {
        jqxhr = $.ajax(options);
    }

    $form.removeData('jqxhr').data('jqxhr', jqxhr);

    // clear element array
    for (var k=0; k < elements.length; k++) {
        elements[k] = null;
    }

    // fire 'notify' event
    this.trigger('form-submit-notify', [this, options]);
    return this;

    // utility fn for deep serialization
    function deepSerialize(extraData){
        var serialized = $.param(extraData, options.traditional).split('&');
        var len = serialized.length;
        var result = [];
        var i, part;
        for (i=0; i < len; i++) {
            // #252; undo param space replacement
            serialized[i] = serialized[i].replace(/\+/g,' ');
            part = serialized[i].split('=');
            // #278; use array instead of object storage, favoring array serializations
            result.push([decodeURIComponent(part[0]), decodeURIComponent(part[1])]);
        }
        return result;
    }

     // XMLHttpRequest Level 2 file uploads (big hat tip to francois2metz)
    function fileUploadXhr(a) {
        var formdata = new FormData();

        for (var i=0; i < a.length; i++) {
            formdata.append(a[i].name, a[i].value);
        }

        if (options.extraData) {
            var serializedData = deepSerialize(options.extraData);
            for (i=0; i < serializedData.length; i++) {
                if (serializedData[i]) {
                    formdata.append(serializedData[i][0], serializedData[i][1]);
                }
            }
        }

        options.data = null;

        var s = $.extend(true, {}, $.ajaxSettings, options, {
            contentType: false,
            processData: false,
            cache: false,
            type: method || 'POST'
        });

        if (options.uploadProgress) {
            // workaround because jqXHR does not expose upload property
            s.xhr = function() {
                var xhr = $.ajaxSettings.xhr();
                if (xhr.upload) {
                    xhr.upload.addEventListener('progress', function(event) {
                        var percent = 0;
                        var position = event.loaded || event.position; /*event.position is deprecated*/
                        var total = event.total;
                        if (event.lengthComputable) {
                            percent = Math.ceil(position / total * 100);
                        }
                        options.uploadProgress(event, position, total, percent);
                    }, false);
                }
                return xhr;
            };
        }

        s.data = null;
        var beforeSend = s.beforeSend;
        s.beforeSend = function(xhr, o) {
            //Send FormData() provided by user
            if (options.formData) {
                o.data = options.formData;
            }
            else {
                o.data = formdata;
            }
            if(beforeSend) {
                beforeSend.call(this, xhr, o);
            }
        };
        return $.ajax(s);
    }

    // private function for handling file uploads (hat tip to YAHOO!)
    function fileUploadIframe(a) {
        var form = $form[0], el, i, s, g, id, $io, io, xhr, sub, n, timedOut, timeoutHandle;
        var deferred = $.Deferred();

        // #341
        deferred.abort = function(status) {
            xhr.abort(status);
        };

        if (a) {
            // ensure that every serialized input is still enabled
            for (i=0; i < elements.length; i++) {
                el = $(elements[i]);
                if ( hasProp ) {
                    el.prop('disabled', false);
                }
                else {
                    el.removeAttr('disabled');
                }
            }
        }

        s = $.extend(true, {}, $.ajaxSettings, options);
        s.context = s.context || s;
        id = 'jqFormIO' + (new Date().getTime());
        if (s.iframeTarget) {
            $io = $(s.iframeTarget);
            n = $io.attr2('name');
            if (!n) {
                $io.attr2('name', id);
            }
            else {
                id = n;
            }
        }
        else {
            $io = $('<iframe name="' + id + '" src="'+ s.iframeSrc +'" />');
            $io.css({ position: 'absolute', top: '-1000px', left: '-1000px' });
        }
        io = $io[0];


        xhr = { // mock object
            aborted: 0,
            responseText: null,
            responseXML: null,
            status: 0,
            statusText: 'n/a',
            getAllResponseHeaders: function() {},
            getResponseHeader: function() {},
            setRequestHeader: function() {},
            abort: function(status) {
                var e = (status === 'timeout' ? 'timeout' : 'aborted');
                log('aborting upload... ' + e);
                this.aborted = 1;

                try { // #214, #257
                    if (io.contentWindow.document.execCommand) {
                        io.contentWindow.document.execCommand('Stop');
                    }
                }
                catch(ignore) {}

                $io.attr('src', s.iframeSrc); // abort op in progress
                xhr.error = e;
                if (s.error) {
                    s.error.call(s.context, xhr, e, status);
                }
                if (g) {
                    $.event.trigger("ajaxError", [xhr, s, e]);
                }
                if (s.complete) {
                    s.complete.call(s.context, xhr, e);
                }
            }
        };

        g = s.global;
        // trigger ajax global events so that activity/block indicators work like normal
        if (g && 0 === $.active++) {
            $.event.trigger("ajaxStart");
        }
        if (g) {
            $.event.trigger("ajaxSend", [xhr, s]);
        }

        if (s.beforeSend && s.beforeSend.call(s.context, xhr, s) === false) {
            if (s.global) {
                $.active--;
            }
            deferred.reject();
            return deferred;
        }
        if (xhr.aborted) {
            deferred.reject();
            return deferred;
        }

        // add submitting element to data if we know it
        sub = form.clk;
        if (sub) {
            n = sub.name;
            if (n && !sub.disabled) {
                s.extraData = s.extraData || {};
                s.extraData[n] = sub.value;
                if (sub.type == "image") {
                    s.extraData[n+'.x'] = form.clk_x;
                    s.extraData[n+'.y'] = form.clk_y;
                }
            }
        }

        var CLIENT_TIMEOUT_ABORT = 1;
        var SERVER_ABORT = 2;
                
        function getDoc(frame) {
            /* it looks like contentWindow or contentDocument do not
             * carry the protocol property in ie8, when running under ssl
             * frame.document is the only valid response document, since
             * the protocol is know but not on the other two objects. strange?
             * "Same origin policy" http://en.wikipedia.org/wiki/Same_origin_policy
             */
            
            var doc = null;
            
            // IE8 cascading access check
            try {
                if (frame.contentWindow) {
                    doc = frame.contentWindow.document;
                }
            } catch(err) {
                // IE8 access denied under ssl & missing protocol
                log('cannot get iframe.contentWindow document: ' + err);
            }

            if (doc) { // successful getting content
                return doc;
            }

            try { // simply checking may throw in ie8 under ssl or mismatched protocol
                doc = frame.contentDocument ? frame.contentDocument : frame.document;
            } catch(err) {
                // last attempt
                log('cannot get iframe.contentDocument: ' + err);
                doc = frame.document;
            }
            return doc;
        }

        // Rails CSRF hack (thanks to Yvan Barthelemy)
        var csrf_token = $('meta[name=csrf-token]').attr('content');
        var csrf_param = $('meta[name=csrf-param]').attr('content');
        if (csrf_param && csrf_token) {
            s.extraData = s.extraData || {};
            s.extraData[csrf_param] = csrf_token;
        }

        // take a breath so that pending repaints get some cpu time before the upload starts
        function doSubmit() {
            // make sure form attrs are set
            var t = $form.attr2('target'), 
                a = $form.attr2('action'), 
                mp = 'multipart/form-data',
                et = $form.attr('enctype') || $form.attr('encoding') || mp;

            // update form attrs in IE friendly way
            form.setAttribute('target',id);
            if (!method || /post/i.test(method) ) {
                form.setAttribute('method', 'POST');
            }
            if (a != s.url) {
                form.setAttribute('action', s.url);
            }

            // ie borks in some cases when setting encoding
            if (! s.skipEncodingOverride && (!method || /post/i.test(method))) {
                $form.attr({
                    encoding: 'multipart/form-data',
                    enctype:  'multipart/form-data'
                });
            }

            // support timout
            if (s.timeout) {
                timeoutHandle = setTimeout(function() { timedOut = true; cb(CLIENT_TIMEOUT_ABORT); }, s.timeout);
            }

            // look for server aborts
            function checkState() {
                try {
                    var state = getDoc(io).readyState;
                    log('state = ' + state);
                    if (state && state.toLowerCase() == 'uninitialized') {
                        setTimeout(checkState,50);
                    }
                }
                catch(e) {
                    log('Server abort: ' , e, ' (', e.name, ')');
                    cb(SERVER_ABORT);
                    if (timeoutHandle) {
                        clearTimeout(timeoutHandle);
                    }
                    timeoutHandle = undefined;
                }
            }

            // add "extra" data to form if provided in options
            var extraInputs = [];
            try {
                if (s.extraData) {
                    for (var n in s.extraData) {
                        if (s.extraData.hasOwnProperty(n)) {
                           // if using the $.param format that allows for multiple values with the same name
                           if($.isPlainObject(s.extraData[n]) && s.extraData[n].hasOwnProperty('name') && s.extraData[n].hasOwnProperty('value')) {
                               extraInputs.push(
                               $('<input type="hidden" name="'+s.extraData[n].name+'">').val(s.extraData[n].value)
                                   .appendTo(form)[0]);
                           } else {
                               extraInputs.push(
                               $('<input type="hidden" name="'+n+'">').val(s.extraData[n])
                                   .appendTo(form)[0]);
                           }
                        }
                    }
                }

                if (!s.iframeTarget) {
                    // add iframe to doc and submit the form
                    $io.appendTo('body');
                }
                if (io.attachEvent) {
                    io.attachEvent('onload', cb);
                }
                else {
                    io.addEventListener('load', cb, false);
                }
                setTimeout(checkState,15);

                try {
                    form.submit();
                } catch(err) {
                    // just in case form has element with name/id of 'submit'
                    var submitFn = document.createElement('form').submit;
                    submitFn.apply(form);
                }
            }
            finally {
                // reset attrs and remove "extra" input elements
                form.setAttribute('action',a);
                form.setAttribute('enctype', et); // #380
                if(t) {
                    form.setAttribute('target', t);
                } else {
                    $form.removeAttr('target');
                }
                $(extraInputs).remove();
            }
        }

        if (s.forceSync) {
            doSubmit();
        }
        else {
            setTimeout(doSubmit, 10); // this lets dom updates render
        }

        var data, doc, domCheckCount = 50, callbackProcessed;

        function cb(e) {
            if (xhr.aborted || callbackProcessed) {
                return;
            }
            
            doc = getDoc(io);
            if(!doc) {
                log('cannot access response document');
                e = SERVER_ABORT;
            }
            if (e === CLIENT_TIMEOUT_ABORT && xhr) {
                xhr.abort('timeout');
                deferred.reject(xhr, 'timeout');
                return;
            }
            else if (e == SERVER_ABORT && xhr) {
                xhr.abort('server abort');
                deferred.reject(xhr, 'error', 'server abort');
                return;
            }

            if (!doc || doc.location.href == s.iframeSrc) {
                // response not received yet
                if (!timedOut) {
                    return;
                }
            }
            if (io.detachEvent) {
                io.detachEvent('onload', cb);
            }
            else {
                io.removeEventListener('load', cb, false);
            }

            var status = 'success', errMsg;
            try {
                if (timedOut) {
                    throw 'timeout';
                }

                var isXml = s.dataType == 'xml' || doc.XMLDocument || $.isXMLDoc(doc);
                log('isXml='+isXml);
                if (!isXml && window.opera && (doc.body === null || !doc.body.innerHTML)) {
                    if (--domCheckCount) {
                        // in some browsers (Opera) the iframe DOM is not always traversable when
                        // the onload callback fires, so we loop a bit to accommodate
                        log('requeing onLoad callback, DOM not available');
                        setTimeout(cb, 250);
                        return;
                    }
                    // let this fall through because server response could be an empty document
                    //log('Could not access iframe DOM after mutiple tries.');
                    //throw 'DOMException: not available';
                }

                //log('response detected');
                var docRoot = doc.body ? doc.body : doc.documentElement;
                xhr.responseText = docRoot ? docRoot.innerHTML : null;
                xhr.responseXML = doc.XMLDocument ? doc.XMLDocument : doc;
                if (isXml) {
                    s.dataType = 'xml';
                }
                xhr.getResponseHeader = function(header){
                    var headers = {'content-type': s.dataType};
                    return headers[header.toLowerCase()];
                };
                // support for XHR 'status' & 'statusText' emulation :
                if (docRoot) {
                    xhr.status = Number( docRoot.getAttribute('status') ) || xhr.status;
                    xhr.statusText = docRoot.getAttribute('statusText') || xhr.statusText;
                }

                var dt = (s.dataType || '').toLowerCase();
                var scr = /(json|script|text)/.test(dt);
                if (scr || s.textarea) {
                    // see if user embedded response in textarea
                    var ta = doc.getElementsByTagName('textarea')[0];
                    if (ta) {
                        xhr.responseText = ta.value;
                        // support for XHR 'status' & 'statusText' emulation :
                        xhr.status = Number( ta.getAttribute('status') ) || xhr.status;
                        xhr.statusText = ta.getAttribute('statusText') || xhr.statusText;
                    }
                    else if (scr) {
                        // account for browsers injecting pre around json response
                        var pre = doc.getElementsByTagName('pre')[0];
                        var b = doc.getElementsByTagName('body')[0];
                        if (pre) {
                            xhr.responseText = pre.textContent ? pre.textContent : pre.innerText;
                        }
                        else if (b) {
                            xhr.responseText = b.textContent ? b.textContent : b.innerText;
                        }
                    }
                }
                else if (dt == 'xml' && !xhr.responseXML && xhr.responseText) {
                    xhr.responseXML = toXml(xhr.responseText);
                }

                try {
                    data = httpData(xhr, dt, s);
                }
                catch (err) {
                    status = 'parsererror';
                    xhr.error = errMsg = (err || status);
                }
            }
            catch (err) {
                log('error caught: ',err);
                status = 'error';
                xhr.error = errMsg = (err || status);
            }

            if (xhr.aborted) {
                log('upload aborted');
                status = null;
            }

            if (xhr.status) { // we've set xhr.status
                status = (xhr.status >= 200 && xhr.status < 300 || xhr.status === 304) ? 'success' : 'error';
            }

            // ordering of these callbacks/triggers is odd, but that's how $.ajax does it
            if (status === 'success') {
                if (s.success) {
                    s.success.call(s.context, data, 'success', xhr);
                }
                deferred.resolve(xhr.responseText, 'success', xhr);
                if (g) {
                    $.event.trigger("ajaxSuccess", [xhr, s]);
                }
            }
            else if (status) {
                if (errMsg === undefined) {
                    errMsg = xhr.statusText;
                }
                if (s.error) {
                    s.error.call(s.context, xhr, status, errMsg);
                }
                deferred.reject(xhr, 'error', errMsg);
                if (g) {
                    $.event.trigger("ajaxError", [xhr, s, errMsg]);
                }
            }

            if (g) {
                $.event.trigger("ajaxComplete", [xhr, s]);
            }

            if (g && ! --$.active) {
                $.event.trigger("ajaxStop");
            }

            if (s.complete) {
                s.complete.call(s.context, xhr, status);
            }

            callbackProcessed = true;
            if (s.timeout) {
                clearTimeout(timeoutHandle);
            }

            // clean up
            setTimeout(function() {
                if (!s.iframeTarget) {
                    $io.remove();
                }
                else { //adding else to clean up existing iframe response.
                    $io.attr('src', s.iframeSrc);
                }
                xhr.responseXML = null;
            }, 100);
        }

        var toXml = $.parseXML || function(s, doc) { // use parseXML if available (jQuery 1.5+)
            if (window.ActiveXObject) {
                doc = new ActiveXObject('Microsoft.XMLDOM');
                doc.async = 'false';
                doc.loadXML(s);
            }
            else {
                doc = (new DOMParser()).parseFromString(s, 'text/xml');
            }
            return (doc && doc.documentElement && doc.documentElement.nodeName != 'parsererror') ? doc : null;
        };
        var parseJSON = $.parseJSON || function(s) {
            /*jslint evil:true */
            return window['eval']('(' + s + ')');
        };

        var httpData = function( xhr, type, s ) { // mostly lifted from jq1.4.4

            var ct = xhr.getResponseHeader('content-type') || '',
                xml = type === 'xml' || !type && ct.indexOf('xml') >= 0,
                data = xml ? xhr.responseXML : xhr.responseText;

            if (xml && data.documentElement.nodeName === 'parsererror') {
                if ($.error) {
                    $.error('parsererror');
                }
            }
            if (s && s.dataFilter) {
                data = s.dataFilter(data, type);
            }
            if (typeof data === 'string') {
                if (type === 'json' || !type && ct.indexOf('json') >= 0) {
                    data = parseJSON(data);
                } else if (type === "script" || !type && ct.indexOf("javascript") >= 0) {
                    $.globalEval(data);
                }
            }
            return data;
        };

        return deferred;
    }
};

/**
 * ajaxForm() provides a mechanism for fully automating form submission.
 *
 * The advantages of using this method instead of ajaxSubmit() are:
 *
 * 1: This method will include coordinates for <input type="image" /> elements (if the element
 *    is used to submit the form).
 * 2. This method will include the submit element's name/value data (for the element that was
 *    used to submit the form).
 * 3. This method binds the submit() method to the form for you.
 *
 * The options argument for ajaxForm works exactly as it does for ajaxSubmit.  ajaxForm merely
 * passes the options argument along after properly binding events for submit elements and
 * the form itself.
 */
$.fn.ajaxForm = function(options) {
    options = options || {};
    options.delegation = options.delegation && $.isFunction($.fn.on);

    // in jQuery 1.3+ we can fix mistakes with the ready state
    if (!options.delegation && this.length === 0) {
        var o = { s: this.selector, c: this.context };
        if (!$.isReady && o.s) {
            log('DOM not ready, queuing ajaxForm');
            $(function() {
                $(o.s,o.c).ajaxForm(options);
            });
            return this;
        }
        // is your DOM ready?  http://docs.jquery.com/Tutorials:Introducing_$(document).ready()
        log('terminating; zero elements found by selector' + ($.isReady ? '' : ' (DOM not ready)'));
        return this;
    }

    if ( options.delegation ) {
        $(document)
            .off('submit.form-plugin', this.selector, doAjaxSubmit)
            .off('click.form-plugin', this.selector, captureSubmittingElement)
            .on('submit.form-plugin', this.selector, options, doAjaxSubmit)
            .on('click.form-plugin', this.selector, options, captureSubmittingElement);
        return this;
    }

    return this.ajaxFormUnbind()
        .bind('submit.form-plugin', options, doAjaxSubmit)
        .bind('click.form-plugin', options, captureSubmittingElement);
};

// private event handlers
function doAjaxSubmit(e) {
    /*jshint validthis:true */
    var options = e.data;
    if (!e.isDefaultPrevented()) { // if event has been canceled, don't proceed
        e.preventDefault();
        $(e.target).ajaxSubmit(options); // #365
    }
}

function captureSubmittingElement(e) {
    /*jshint validthis:true */
    var target = e.target;
    var $el = $(target);
    if (!($el.is("[type=submit],[type=image]"))) {
        // is this a child element of the submit el?  (ex: a span within a button)
        var t = $el.closest('[type=submit]');
        if (t.length === 0) {
            return;
        }
        target = t[0];
    }
    var form = this;
    form.clk = target;
    if (target.type == 'image') {
        if (e.offsetX !== undefined) {
            form.clk_x = e.offsetX;
            form.clk_y = e.offsetY;
        } else if (typeof $.fn.offset == 'function') {
            var offset = $el.offset();
            form.clk_x = e.pageX - offset.left;
            form.clk_y = e.pageY - offset.top;
        } else {
            form.clk_x = e.pageX - target.offsetLeft;
            form.clk_y = e.pageY - target.offsetTop;
        }
    }
    // clear form vars
    setTimeout(function() { form.clk = form.clk_x = form.clk_y = null; }, 100);
}


// ajaxFormUnbind unbinds the event handlers that were bound by ajaxForm
$.fn.ajaxFormUnbind = function() {
    return this.unbind('submit.form-plugin click.form-plugin');
};

/**
 * formToArray() gathers form element data into an array of objects that can
 * be passed to any of the following ajax functions: $.get, $.post, or load.
 * Each object in the array has both a 'name' and 'value' property.  An example of
 * an array for a simple login form might be:
 *
 * [ { name: 'username', value: 'jresig' }, { name: 'password', value: 'secret' } ]
 *
 * It is this array that is passed to pre-submit callback functions provided to the
 * ajaxSubmit() and ajaxForm() methods.
 */
$.fn.formToArray = function(semantic, elements) {
    var a = [];
    if (this.length === 0) {
        return a;
    }

    var form = this[0];
    var formId = this.attr('id');
    var els = semantic ? form.getElementsByTagName('*') : form.elements;
    var els2;

    if (els && !/MSIE [678]/.test(navigator.userAgent)) { // #390
        els = $(els).get();  // convert to standard array
    }

    // #386; account for inputs outside the form which use the 'form' attribute
    if ( formId ) {
        els2 = $(':input[form="' + formId + '"]').get(); // hat tip @thet
        if ( els2.length ) {
            els = (els || []).concat(els2);
        }
    }

    if (!els || !els.length) {
        return a;
    }

    var i,j,n,v,el,max,jmax;
    for(i=0, max=els.length; i < max; i++) {
        el = els[i];
        n = el.name;
        if (!n || el.disabled) {
            continue;
        }

        if (semantic && form.clk && el.type == "image") {
            // handle image inputs on the fly when semantic == true
            if(form.clk == el) {
                a.push({name: n, value: $(el).val(), type: el.type });
                a.push({name: n+'.x', value: form.clk_x}, {name: n+'.y', value: form.clk_y});
            }
            continue;
        }

        v = $.fieldValue(el, true);
        if (v && v.constructor == Array) {
            if (elements) {
                elements.push(el);
            }
            for(j=0, jmax=v.length; j < jmax; j++) {
                a.push({name: n, value: v[j]});
            }
        }
        else if (feature.fileapi && el.type == 'file') {
            if (elements) {
                elements.push(el);
            }
            var files = el.files;
            if (files.length) {
                for (j=0; j < files.length; j++) {
                    a.push({name: n, value: files[j], type: el.type});
                }
            }
            else {
                // #180
                a.push({ name: n, value: '', type: el.type });
            }
        }
        else if (v !== null && typeof v != 'undefined') {
            if (elements) {
                elements.push(el);
            }
            a.push({name: n, value: v, type: el.type, required: el.required});
        }
    }

    if (!semantic && form.clk) {
        // input type=='image' are not found in elements array! handle it here
        var $input = $(form.clk), input = $input[0];
        n = input.name;
        if (n && !input.disabled && input.type == 'image') {
            a.push({name: n, value: $input.val()});
            a.push({name: n+'.x', value: form.clk_x}, {name: n+'.y', value: form.clk_y});
        }
    }
    return a;
};

/**
 * Serializes form data into a 'submittable' string. This method will return a string
 * in the format: name1=value1&amp;name2=value2
 */
$.fn.formSerialize = function(semantic) {
    //hand off to jQuery.param for proper encoding
    return $.param(this.formToArray(semantic));
};

/**
 * Serializes all field elements in the jQuery object into a query string.
 * This method will return a string in the format: name1=value1&amp;name2=value2
 */
$.fn.fieldSerialize = function(successful) {
    var a = [];
    this.each(function() {
        var n = this.name;
        if (!n) {
            return;
        }
        var v = $.fieldValue(this, successful);
        if (v && v.constructor == Array) {
            for (var i=0,max=v.length; i < max; i++) {
                a.push({name: n, value: v[i]});
            }
        }
        else if (v !== null && typeof v != 'undefined') {
            a.push({name: this.name, value: v});
        }
    });
    //hand off to jQuery.param for proper encoding
    return $.param(a);
};

/**
 * Returns the value(s) of the element in the matched set.  For example, consider the following form:
 *
 *  <form><fieldset>
 *      <input name="A" type="text" />
 *      <input name="A" type="text" />
 *      <input name="B" type="checkbox" value="B1" />
 *      <input name="B" type="checkbox" value="B2"/>
 *      <input name="C" type="radio" value="C1" />
 *      <input name="C" type="radio" value="C2" />
 *  </fieldset></form>
 *
 *  var v = $('input[type=text]').fieldValue();
 *  // if no values are entered into the text inputs
 *  v == ['','']
 *  // if values entered into the text inputs are 'foo' and 'bar'
 *  v == ['foo','bar']
 *
 *  var v = $('input[type=checkbox]').fieldValue();
 *  // if neither checkbox is checked
 *  v === undefined
 *  // if both checkboxes are checked
 *  v == ['B1', 'B2']
 *
 *  var v = $('input[type=radio]').fieldValue();
 *  // if neither radio is checked
 *  v === undefined
 *  // if first radio is checked
 *  v == ['C1']
 *
 * The successful argument controls whether or not the field element must be 'successful'
 * (per http://www.w3.org/TR/html4/interact/forms.html#successful-controls).
 * The default value of the successful argument is true.  If this value is false the value(s)
 * for each element is returned.
 *
 * Note: This method *always* returns an array.  If no valid value can be determined the
 *    array will be empty, otherwise it will contain one or more values.
 */
$.fn.fieldValue = function(successful) {
    for (var val=[], i=0, max=this.length; i < max; i++) {
        var el = this[i];
        var v = $.fieldValue(el, successful);
        if (v === null || typeof v == 'undefined' || (v.constructor == Array && !v.length)) {
            continue;
        }
        if (v.constructor == Array) {
            $.merge(val, v);
        }
        else {
            val.push(v);
        }
    }
    return val;
};

/**
 * Returns the value of the field element.
 */
$.fieldValue = function(el, successful) {
    var n = el.name, t = el.type, tag = el.tagName.toLowerCase();
    if (successful === undefined) {
        successful = true;
    }

    if (successful && (!n || el.disabled || t == 'reset' || t == 'button' ||
        (t == 'checkbox' || t == 'radio') && !el.checked ||
        (t == 'submit' || t == 'image') && el.form && el.form.clk != el ||
        tag == 'select' && el.selectedIndex == -1)) {
            return null;
    }

    if (tag == 'select') {
        var index = el.selectedIndex;
        if (index < 0) {
            return null;
        }
        var a = [], ops = el.options;
        var one = (t == 'select-one');
        var max = (one ? index+1 : ops.length);
        for(var i=(one ? index : 0); i < max; i++) {
            var op = ops[i];
            if (op.selected) {
                var v = op.value;
                if (!v) { // extra pain for IE...
                    v = (op.attributes && op.attributes.value && !(op.attributes.value.specified)) ? op.text : op.value;
                }
                if (one) {
                    return v;
                }
                a.push(v);
            }
        }
        return a;
    }
    return $(el).val();
};

/**
 * Clears the form data.  Takes the following actions on the form's input fields:
 *  - input text fields will have their 'value' property set to the empty string
 *  - select elements will have their 'selectedIndex' property set to -1
 *  - checkbox and radio inputs will have their 'checked' property set to false
 *  - inputs of type submit, button, reset, and hidden will *not* be effected
 *  - button elements will *not* be effected
 */
$.fn.clearForm = function(includeHidden) {
    return this.each(function() {
        $('input,select,textarea', this).clearFields(includeHidden);
    });
};

/**
 * Clears the selected form elements.
 */
$.fn.clearFields = $.fn.clearInputs = function(includeHidden) {
    var re = /^(?:color|date|datetime|email|month|number|password|range|search|tel|text|time|url|week)$/i; // 'hidden' is not in this list
    return this.each(function() {
        var t = this.type, tag = this.tagName.toLowerCase();
        if (re.test(t) || tag == 'textarea') {
            this.value = '';
        }
        else if (t == 'checkbox' || t == 'radio') {
            this.checked = false;
        }
        else if (tag == 'select') {
            this.selectedIndex = -1;
        }
        else if (t == "file") {
            if (/MSIE/.test(navigator.userAgent)) {
                $(this).replaceWith($(this).clone(true));
            } else {
                $(this).val('');
            }
        }
        else if (includeHidden) {
            // includeHidden can be the value true, or it can be a selector string
            // indicating a special test; for example:
            //  $('#myForm').clearForm('.special:hidden')
            // the above would clean hidden inputs that have the class of 'special'
            if ( (includeHidden === true && /hidden/.test(t)) ||
                 (typeof includeHidden == 'string' && $(this).is(includeHidden)) ) {
                this.value = '';
            }
        }
    });
};

/**
 * Resets the form data.  Causes all form elements to be reset to their original value.
 */
$.fn.resetForm = function() {
    return this.each(function() {
        // guard against an input with the name of 'reset'
        // note that IE reports the reset function as an 'object'
        if (typeof this.reset == 'function' || (typeof this.reset == 'object' && !this.reset.nodeType)) {
            this.reset();
        }
    });
};

/**
 * Enables or disables any matching elements.
 */
$.fn.enable = function(b) {
    if (b === undefined) {
        b = true;
    }
    return this.each(function() {
        this.disabled = !b;
    });
};

/**
 * Checks/unchecks any matching checkboxes or radio buttons and
 * selects/deselects and matching option elements.
 */
$.fn.selected = function(select) {
    if (select === undefined) {
        select = true;
    }
    return this.each(function() {
        var t = this.type;
        if (t == 'checkbox' || t == 'radio') {
            this.checked = select;
        }
        else if (this.tagName.toLowerCase() == 'option') {
            var $sel = $(this).parent('select');
            if (select && $sel[0] && $sel[0].type == 'select-one') {
                // deselect all other options
                $sel.find('option').selected(false);
            }
            this.selected = select;
        }
    });
};

// expose debug var
$.fn.ajaxSubmit.debug = false;

// helper fn for console logging
function log() {
    if (!$.fn.ajaxSubmit.debug) {
        return;
    }
    var msg = '[jquery.form] ' + Array.prototype.join.call(arguments,'');
    if (window.console && window.console.log) {
        window.console.log(msg);
    }
    else if (window.opera && window.opera.postError) {
        window.opera.postError(msg);
    }
}

}));

/**
 * [jQuery-lazyload-any]{@link https://github.com/emn178/jquery-lazyload-any}
 *
 * @version 0.3.0
 * @author Yi-Cyuan Chen [emn178@gmail.com]
 * @copyright Yi-Cyuan Chen 2014-2016
 * @license MIT
 */
(function(d,k,l){function m(){var a=d(this),c;if(c=a.is(":visible")){c=a[0].getBoundingClientRect();var b=-a.data("jquery-lazyload-any").threshold,e=n-b,f=p-b;c=(c.top>=b&&c.top<=e||c.bottom>=b&&c.bottom<=e)&&(c.left>=b&&c.left<=f||c.right>=b&&c.right<=f)}c&&a.trigger("appear")}function q(){n=k.innerHeight||l.documentElement.clientHeight;p=k.innerWidth||l.documentElement.clientWidth;g()}function g(){h=h.filter(":jquery-lazyload-any-appear");1==this.nodeType?d(this).find(":jquery-lazyload-any-appear").each(m):
h.each(m)}function v(){var a=d(this),c=a.data("jquery-lazyload-any"),b=a.data("lazyload");b||(b=a.children().filter('script[type="text/lazyload"]').get(0),b=d(b).html());b||(b=(b=a.contents().filter(function(){return 8===this.nodeType}).get(0))&&d.trim(b.data));b=w.html(b).contents();a.replaceWith(b);d.isFunction(c.load)&&c.load.call(b,b)}function r(){var a=d(this),c;a.data("jquery-lazyload-any-scroller")?c=!1:(c=a.css("overflow"),"scroll"!=c&&"auto"!=c?c=!1:(a.data("jquery-lazyload-any-scroller",
1),a.bind("scroll",g),c=!0));var b;a.data("jquery-lazyload-any-display")?b=void 0:"none"!=a.css("display")?b=void 0:(a.data("jquery-lazyload-any-display",1),a._bindShow(g),b=!0);c|b&&!a.data("jquery-lazyload-any-watch")&&(a.data("jquery-lazyload-any-watch",1),a.bind("appear",t))}function t(){var a=d(this);0===a.find(":jquery-lazyload-any-appear").length&&(a.removeData("jquery-lazyload-any-scroller").removeData("jquery-lazyload-any-display").removeData("jquery-lazyload-any-watch"),a.unbind("scroll",
g).unbind("appear",t)._unbindShow(g))}var w=d("<div/>"),n,p,u=!1,h=d();d.expr[":"]["jquery-lazyload-any-appear"]=function(a){return void 0!==d(a).data("jquery-lazyload-any-appear")};d.fn.lazyload=function(a){var c={threshold:0,trigger:"appear"};d.extend(c,a);a=c.trigger.split(" ");this.data("jquery-lazyload-any-appear",-1!=d.inArray("appear",a)).data("jquery-lazyload-any",c);this.bind(c.trigger,v);this.each(m);this.parents().each(r);this.each(function(){h=h.add(this)});u||(u=!0,q(),d(l).ready(function(){d(k).bind("resize",
q).bind("scroll",g)}));return this};d.lazyload={check:g,refresh:function(a){(void 0===a?h:d(a)).each(function(){var a=d(this);a.is(":jquery-lazyload-any-appear")&&a.parents().each(r)})}};(function(){function a(){var a=d(this),b="none"!=a.css("display");a.data("jquery-lazyload-any-show")!=b&&(a.data("jquery-lazyload-any-show",b),b&&a.trigger("show"))}function c(){f=f.filter(":jquery-lazyload-any-show");f.each(a);0===f.length&&(e=clearInterval(e))}var b=50,e,f=d();d.expr[":"]["jquery-lazyload-any-show"]=
function(a){return void 0!==d(a).data("jquery-lazyload-any-show")};d.fn._bindShow=function(a){this.bind("show",a);this.data("jquery-lazyload-any-show","none"!=this.css("display"));f=f.add(this);b&&!e&&(e=setInterval(c,b))};d.fn._unbindShow=function(a){this.unbind("show",a);this.removeData("jquery-lazyload-any-show")};d.lazyload.setInterval=function(a){a==b||!d.isNumeric(a)||0>a||(b=a,e=clearInterval(e),0<b&&(e=setInterval(c,b)))}})()})(jQuery,window,document);

// Magnific Popup v1.1.0 by Dmitry Semenov
// http://bit.ly/magnific-popup#build=inline+image+ajax+iframe+gallery+retina+imagezoom
(function(a){typeof define=="function"&&define.amd?define(["jquery"],a):typeof exports=="object"?a(require("jquery")):a(window.jQuery||window.Zepto)})(function(a){var b="Close",c="BeforeClose",d="AfterClose",e="BeforeAppend",f="MarkupParse",g="Open",h="Change",i="mfp",j="."+i,k="mfp-ready",l="mfp-removing",m="mfp-prevent-close",n,o=function(){},p=!!window.jQuery,q,r=a(window),s,t,u,v,w=function(a,b){n.ev.on(i+a+j,b)},x=function(b,c,d,e){var f=document.createElement("div");return f.className="mfp-"+b,d&&(f.innerHTML=d),e?c&&c.appendChild(f):(f=a(f),c&&f.appendTo(c)),f},y=function(b,c){n.ev.triggerHandler(i+b,c),n.st.callbacks&&(b=b.charAt(0).toLowerCase()+b.slice(1),n.st.callbacks[b]&&n.st.callbacks[b].apply(n,a.isArray(c)?c:[c]))},z=function(b){if(b!==v||!n.currTemplate.closeBtn)n.currTemplate.closeBtn=a(n.st.closeMarkup.replace("%title%",n.st.tClose)),v=b;return n.currTemplate.closeBtn},A=function(){a.magnificPopup.instance||(n=new o,n.init(),a.magnificPopup.instance=n)},B=function(){var a=document.createElement("p").style,b=["ms","O","Moz","Webkit"];if(a.transition!==undefined)return!0;while(b.length)if(b.pop()+"Transition"in a)return!0;return!1};o.prototype={constructor:o,init:function(){var b=navigator.appVersion;n.isLowIE=n.isIE8=document.all&&!document.addEventListener,n.isAndroid=/android/gi.test(b),n.isIOS=/iphone|ipad|ipod/gi.test(b),n.supportsTransition=B(),n.probablyMobile=n.isAndroid||n.isIOS||/(Opera Mini)|Kindle|webOS|BlackBerry|(Opera Mobi)|(Windows Phone)|IEMobile/i.test(navigator.userAgent),s=a(document),n.popupsCache={}},open:function(b){var c;if(b.isObj===!1){n.items=b.items.toArray(),n.index=0;var d=b.items,e;for(c=0;c<d.length;c++){e=d[c],e.parsed&&(e=e.el[0]);if(e===b.el[0]){n.index=c;break}}}else n.items=a.isArray(b.items)?b.items:[b.items],n.index=b.index||0;if(n.isOpen){n.updateItemHTML();return}n.types=[],u="",b.mainEl&&b.mainEl.length?n.ev=b.mainEl.eq(0):n.ev=s,b.key?(n.popupsCache[b.key]||(n.popupsCache[b.key]={}),n.currTemplate=n.popupsCache[b.key]):n.currTemplate={},n.st=a.extend(!0,{},a.magnificPopup.defaults,b),n.fixedContentPos=n.st.fixedContentPos==="auto"?!n.probablyMobile:n.st.fixedContentPos,n.st.modal&&(n.st.closeOnContentClick=!1,n.st.closeOnBgClick=!1,n.st.showCloseBtn=!1,n.st.enableEscapeKey=!1),n.bgOverlay||(n.bgOverlay=x("bg").on("click"+j,function(){n.close()}),n.wrap=x("wrap").attr("tabindex",-1).on("click"+j,function(a){n._checkIfClose(a.target)&&n.close()}),n.container=x("container",n.wrap)),n.contentContainer=x("content"),n.st.preloader&&(n.preloader=x("preloader",n.container,n.st.tLoading));var h=a.magnificPopup.modules;for(c=0;c<h.length;c++){var i=h[c];i=i.charAt(0).toUpperCase()+i.slice(1),n["init"+i].call(n)}y("BeforeOpen"),n.st.showCloseBtn&&(n.st.closeBtnInside?(w(f,function(a,b,c,d){c.close_replaceWith=z(d.type)}),u+=" mfp-close-btn-in"):n.wrap.append(z())),n.st.alignTop&&(u+=" mfp-align-top"),n.fixedContentPos?n.wrap.css({overflow:n.st.overflowY,overflowX:"hidden",overflowY:n.st.overflowY}):n.wrap.css({top:r.scrollTop(),position:"absolute"}),(n.st.fixedBgPos===!1||n.st.fixedBgPos==="auto"&&!n.fixedContentPos)&&n.bgOverlay.css({height:s.height(),position:"absolute"}),n.st.enableEscapeKey&&s.on("keyup"+j,function(a){a.keyCode===27&&n.close()}),r.on("resize"+j,function(){n.updateSize()}),n.st.closeOnContentClick||(u+=" mfp-auto-cursor"),u&&n.wrap.addClass(u);var l=n.wH=r.height(),m={};if(n.fixedContentPos&&n._hasScrollBar(l)){var o=n._getScrollbarSize();o&&(m.marginRight=o)}n.fixedContentPos&&(n.isIE7?a("body, html").css("overflow","hidden"):m.overflow="hidden");var p=n.st.mainClass;return n.isIE7&&(p+=" mfp-ie7"),p&&n._addClassToMFP(p),n.updateItemHTML(),y("BuildControls"),a("html").css(m),n.bgOverlay.add(n.wrap).prependTo(n.st.prependTo||a(document.body)),n._lastFocusedEl=document.activeElement,setTimeout(function(){n.content?(n._addClassToMFP(k),n._setFocus()):n.bgOverlay.addClass(k),s.on("focusin"+j,n._onFocusIn)},16),n.isOpen=!0,n.updateSize(l),y(g),b},close:function(){if(!n.isOpen)return;y(c),n.isOpen=!1,n.st.removalDelay&&!n.isLowIE&&n.supportsTransition?(n._addClassToMFP(l),setTimeout(function(){n._close()},n.st.removalDelay)):n._close()},_close:function(){y(b);var c=l+" "+k+" ";n.bgOverlay.detach(),n.wrap.detach(),n.container.empty(),n.st.mainClass&&(c+=n.st.mainClass+" "),n._removeClassFromMFP(c);if(n.fixedContentPos){var e={marginRight:""};n.isIE7?a("body, html").css("overflow",""):e.overflow="",a("html").css(e)}s.off("keyup"+j+" focusin"+j),n.ev.off(j),n.wrap.attr("class","mfp-wrap").removeAttr("style"),n.bgOverlay.attr("class","mfp-bg"),n.container.attr("class","mfp-container"),n.st.showCloseBtn&&(!n.st.closeBtnInside||n.currTemplate[n.currItem.type]===!0)&&n.currTemplate.closeBtn&&n.currTemplate.closeBtn.detach(),n.st.autoFocusLast&&n._lastFocusedEl&&a(n._lastFocusedEl).focus(),n.currItem=null,n.content=null,n.currTemplate=null,n.prevHeight=0,y(d)},updateSize:function(a){if(n.isIOS){var b=document.documentElement.clientWidth/window.innerWidth,c=window.innerHeight*b;n.wrap.css("height",c),n.wH=c}else n.wH=a||r.height();n.fixedContentPos||n.wrap.css("height",n.wH),y("Resize")},updateItemHTML:function(){var b=n.items[n.index];n.contentContainer.detach(),n.content&&n.content.detach(),b.parsed||(b=n.parseEl(n.index));var c=b.type;y("BeforeChange",[n.currItem?n.currItem.type:"",c]),n.currItem=b;if(!n.currTemplate[c]){var d=n.st[c]?n.st[c].markup:!1;y("FirstMarkupParse",d),d?n.currTemplate[c]=a(d):n.currTemplate[c]=!0}t&&t!==b.type&&n.container.removeClass("mfp-"+t+"-holder");var e=n["get"+c.charAt(0).toUpperCase()+c.slice(1)](b,n.currTemplate[c]);n.appendContent(e,c),b.preloaded=!0,y(h,b),t=b.type,n.container.prepend(n.contentContainer),y("AfterChange")},appendContent:function(a,b){n.content=a,a?n.st.showCloseBtn&&n.st.closeBtnInside&&n.currTemplate[b]===!0?n.content.find(".mfp-close").length||n.content.append(z()):n.content=a:n.content="",y(e),n.container.addClass("mfp-"+b+"-holder"),n.contentContainer.append(n.content)},parseEl:function(b){var c=n.items[b],d;c.tagName?c={el:a(c)}:(d=c.type,c={data:c,src:c.src});if(c.el){var e=n.types;for(var f=0;f<e.length;f++)if(c.el.hasClass("mfp-"+e[f])){d=e[f];break}c.src=c.el.attr("data-mfp-src"),c.src||(c.src=c.el.attr("href"))}return c.type=d||n.st.type||"inline",c.index=b,c.parsed=!0,n.items[b]=c,y("ElementParse",c),n.items[b]},addGroup:function(a,b){var c=function(c){c.mfpEl=this,n._openClick(c,a,b)};b||(b={});var d="click.magnificPopup";b.mainEl=a,b.items?(b.isObj=!0,a.off(d).on(d,c)):(b.isObj=!1,b.delegate?a.off(d).on(d,b.delegate,c):(b.items=a,a.off(d).on(d,c)))},_openClick:function(b,c,d){var e=d.midClick!==undefined?d.midClick:a.magnificPopup.defaults.midClick;if(!e&&(b.which===2||b.ctrlKey||b.metaKey||b.altKey||b.shiftKey))return;var f=d.disableOn!==undefined?d.disableOn:a.magnificPopup.defaults.disableOn;if(f)if(a.isFunction(f)){if(!f.call(n))return!0}else if(r.width()<f)return!0;b.type&&(b.preventDefault(),n.isOpen&&b.stopPropagation()),d.el=a(b.mfpEl),d.delegate&&(d.items=c.find(d.delegate)),n.open(d)},updateStatus:function(a,b){if(n.preloader){q!==a&&n.container.removeClass("mfp-s-"+q),!b&&a==="loading"&&(b=n.st.tLoading);var c={status:a,text:b};y("UpdateStatus",c),a=c.status,b=c.text,n.preloader.html(b),n.preloader.find("a").on("click",function(a){a.stopImmediatePropagation()}),n.container.addClass("mfp-s-"+a),q=a}},_checkIfClose:function(b){if(a(b).hasClass(m))return;var c=n.st.closeOnContentClick,d=n.st.closeOnBgClick;if(c&&d)return!0;if(!n.content||a(b).hasClass("mfp-close")||n.preloader&&b===n.preloader[0])return!0;if(b!==n.content[0]&&!a.contains(n.content[0],b)){if(d&&a.contains(document,b))return!0}else if(c)return!0;return!1},_addClassToMFP:function(a){n.bgOverlay.addClass(a),n.wrap.addClass(a)},_removeClassFromMFP:function(a){this.bgOverlay.removeClass(a),n.wrap.removeClass(a)},_hasScrollBar:function(a){return(n.isIE7?s.height():document.body.scrollHeight)>(a||r.height())},_setFocus:function(){(n.st.focus?n.content.find(n.st.focus).eq(0):n.wrap).focus()},_onFocusIn:function(b){if(b.target!==n.wrap[0]&&!a.contains(n.wrap[0],b.target))return n._setFocus(),!1},_parseMarkup:function(b,c,d){var e;d.data&&(c=a.extend(d.data,c)),y(f,[b,c,d]),a.each(c,function(c,d){if(d===undefined||d===!1)return!0;e=c.split("_");if(e.length>1){var f=b.find(j+"-"+e[0]);if(f.length>0){var g=e[1];g==="replaceWith"?f[0]!==d[0]&&f.replaceWith(d):g==="img"?f.is("img")?f.attr("src",d):f.replaceWith(a("<img>").attr("src",d).attr("class",f.attr("class"))):f.attr(e[1],d)}}else b.find(j+"-"+c).html(d)})},_getScrollbarSize:function(){if(n.scrollbarSize===undefined){var a=document.createElement("div");a.style.cssText="width: 99px; height: 99px; overflow: scroll; position: absolute; top: -9999px;",document.body.appendChild(a),n.scrollbarSize=a.offsetWidth-a.clientWidth,document.body.removeChild(a)}return n.scrollbarSize}},a.magnificPopup={instance:null,proto:o.prototype,modules:[],open:function(b,c){return A(),b?b=a.extend(!0,{},b):b={},b.isObj=!0,b.index=c||0,this.instance.open(b)},close:function(){return a.magnificPopup.instance&&a.magnificPopup.instance.close()},registerModule:function(b,c){c.options&&(a.magnificPopup.defaults[b]=c.options),a.extend(this.proto,c.proto),this.modules.push(b)},defaults:{disableOn:0,key:null,midClick:!1,mainClass:"",preloader:!0,focus:"",closeOnContentClick:!1,closeOnBgClick:!0,closeBtnInside:!0,showCloseBtn:!0,enableEscapeKey:!0,modal:!1,alignTop:!1,removalDelay:0,prependTo:null,fixedContentPos:"auto",fixedBgPos:"auto",overflowY:"auto",closeMarkup:'<button title="%title%" type="button" class="mfp-close">&#215;</button>',tClose:"Close (Esc)",tLoading:"Loading...",autoFocusLast:!0}},a.fn.magnificPopup=function(b){A();var c=a(this);if(typeof b=="string")if(b==="open"){var d,e=p?c.data("magnificPopup"):c[0].magnificPopup,f=parseInt(arguments[1],10)||0;e.items?d=e.items[f]:(d=c,e.delegate&&(d=d.find(e.delegate)),d=d.eq(f)),n._openClick({mfpEl:d},c,e)}else n.isOpen&&n[b].apply(n,Array.prototype.slice.call(arguments,1));else b=a.extend(!0,{},b),p?c.data("magnificPopup",b):c[0].magnificPopup=b,n.addGroup(c,b);return c};var C="inline",D,E,F,G=function(){F&&(E.after(F.addClass(D)).detach(),F=null)};a.magnificPopup.registerModule(C,{options:{hiddenClass:"hide",markup:"",tNotFound:"Content not found"},proto:{initInline:function(){n.types.push(C),w(b+"."+C,function(){G()})},getInline:function(b,c){G();if(b.src){var d=n.st.inline,e=a(b.src);if(e.length){var f=e[0].parentNode;f&&f.tagName&&(E||(D=d.hiddenClass,E=x(D),D="mfp-"+D),F=e.after(E).detach().removeClass(D)),n.updateStatus("ready")}else n.updateStatus("error",d.tNotFound),e=a("<div>");return b.inlineElement=e,e}return n.updateStatus("ready"),n._parseMarkup(c,{},b),c}}});var H="ajax",I,J=function(){I&&a(document.body).removeClass(I)},K=function(){J(),n.req&&n.req.abort()};a.magnificPopup.registerModule(H,{options:{settings:null,cursor:"mfp-ajax-cur",tError:'<a href="%url%">The content</a> could not be loaded.'},proto:{initAjax:function(){n.types.push(H),I=n.st.ajax.cursor,w(b+"."+H,K),w("BeforeChange."+H,K)},getAjax:function(b){I&&a(document.body).addClass(I),n.updateStatus("loading");var c=a.extend({url:b.src,success:function(c,d,e){var f={data:c,xhr:e};y("ParseAjax",f),n.appendContent(a(f.data),H),b.finished=!0,J(),n._setFocus(),setTimeout(function(){n.wrap.addClass(k)},16),n.updateStatus("ready"),y("AjaxContentAdded")},error:function(){J(),b.finished=b.loadError=!0,n.updateStatus("error",n.st.ajax.tError.replace("%url%",b.src))}},n.st.ajax.settings);return n.req=a.ajax(c),""}}});var L,M=function(b){if(b.data&&b.data.title!==undefined)return b.data.title;var c=n.st.image.titleSrc;if(c){if(a.isFunction(c))return c.call(n,b);if(b.el)return b.el.attr(c)||""}return""};a.magnificPopup.registerModule("image",{options:{markup:'<div class="mfp-figure"><div class="mfp-close"></div><figure><div class="mfp-img"></div><figcaption><div class="mfp-bottom-bar"><div class="mfp-title"></div><div class="mfp-counter"></div></div></figcaption></figure></div>',cursor:"mfp-zoom-out-cur",titleSrc:"title",verticalFit:!0,tError:'<a href="%url%">The image</a> could not be loaded.'},proto:{initImage:function(){var c=n.st.image,d=".image";n.types.push("image"),w(g+d,function(){n.currItem.type==="image"&&c.cursor&&a(document.body).addClass(c.cursor)}),w(b+d,function(){c.cursor&&a(document.body).removeClass(c.cursor),r.off("resize"+j)}),w("Resize"+d,n.resizeImage),n.isLowIE&&w("AfterChange",n.resizeImage)},resizeImage:function(){var a=n.currItem;if(!a||!a.img)return;if(n.st.image.verticalFit){var b=0;n.isLowIE&&(b=parseInt(a.img.css("padding-top"),10)+parseInt(a.img.css("padding-bottom"),10)),a.img.css("max-height",n.wH-b)}},_onImageHasSize:function(a){a.img&&(a.hasSize=!0,L&&clearInterval(L),a.isCheckingImgSize=!1,y("ImageHasSize",a),a.imgHidden&&(n.content&&n.content.removeClass("mfp-loading"),a.imgHidden=!1))},findImageSize:function(a){var b=0,c=a.img[0],d=function(e){L&&clearInterval(L),L=setInterval(function(){if(c.naturalWidth>0){n._onImageHasSize(a);return}b>200&&clearInterval(L),b++,b===3?d(10):b===40?d(50):b===100&&d(500)},e)};d(1)},getImage:function(b,c){var d=0,e=function(){b&&(b.img[0].complete?(b.img.off(".mfploader"),b===n.currItem&&(n._onImageHasSize(b),n.updateStatus("ready")),b.hasSize=!0,b.loaded=!0,y("ImageLoadComplete")):(d++,d<200?setTimeout(e,100):f()))},f=function(){b&&(b.img.off(".mfploader"),b===n.currItem&&(n._onImageHasSize(b),n.updateStatus("error",g.tError.replace("%url%",b.src))),b.hasSize=!0,b.loaded=!0,b.loadError=!0)},g=n.st.image,h=c.find(".mfp-img");if(h.length){var i=document.createElement("img");i.className="mfp-img",b.el&&b.el.find("img").length&&(i.alt=b.el.find("img").attr("alt")),b.img=a(i).on("load.mfploader",e).on("error.mfploader",f),i.src=b.src,h.is("img")&&(b.img=b.img.clone()),i=b.img[0],i.naturalWidth>0?b.hasSize=!0:i.width||(b.hasSize=!1)}return n._parseMarkup(c,{title:M(b),img_replaceWith:b.img},b),n.resizeImage(),b.hasSize?(L&&clearInterval(L),b.loadError?(c.addClass("mfp-loading"),n.updateStatus("error",g.tError.replace("%url%",b.src))):(c.removeClass("mfp-loading"),n.updateStatus("ready")),c):(n.updateStatus("loading"),b.loading=!0,b.hasSize||(b.imgHidden=!0,c.addClass("mfp-loading"),n.findImageSize(b)),c)}}});var N,O=function(){return N===undefined&&(N=document.createElement("p").style.MozTransform!==undefined),N};a.magnificPopup.registerModule("zoom",{options:{enabled:!1,easing:"ease-in-out",duration:300,opener:function(a){return a.is("img")?a:a.find("img")}},proto:{initZoom:function(){var a=n.st.zoom,d=".zoom",e;if(!a.enabled||!n.supportsTransition)return;var f=a.duration,g=function(b){var c=b.clone().removeAttr("style").removeAttr("class").addClass("mfp-animated-image"),d="all "+a.duration/1e3+"s "+a.easing,e={position:"fixed",zIndex:9999,left:0,top:0,"-webkit-backface-visibility":"hidden"},f="transition";return e["-webkit-"+f]=e["-moz-"+f]=e["-o-"+f]=e[f]=d,c.css(e),c},h=function(){n.content.css("visibility","visible")},i,j;w("BuildControls"+d,function(){if(n._allowZoom()){clearTimeout(i),n.content.css("visibility","hidden"),e=n._getItemToZoom();if(!e){h();return}j=g(e),j.css(n._getOffset()),n.wrap.append(j),i=setTimeout(function(){j.css(n._getOffset(!0)),i=setTimeout(function(){h(),setTimeout(function(){j.remove(),e=j=null,y("ZoomAnimationEnded")},16)},f)},16)}}),w(c+d,function(){if(n._allowZoom()){clearTimeout(i),n.st.removalDelay=f;if(!e){e=n._getItemToZoom();if(!e)return;j=g(e)}j.css(n._getOffset(!0)),n.wrap.append(j),n.content.css("visibility","hidden"),setTimeout(function(){j.css(n._getOffset())},16)}}),w(b+d,function(){n._allowZoom()&&(h(),j&&j.remove(),e=null)})},_allowZoom:function(){return n.currItem.type==="image"},_getItemToZoom:function(){return n.currItem.hasSize?n.currItem.img:!1},_getOffset:function(b){var c;b?c=n.currItem.img:c=n.st.zoom.opener(n.currItem.el||n.currItem);var d=c.offset(),e=parseInt(c.css("padding-top"),10),f=parseInt(c.css("padding-bottom"),10);d.top-=a(window).scrollTop()-e;var g={width:c.width(),height:(p?c.innerHeight():c[0].offsetHeight)-f-e};return O()?g["-moz-transform"]=g.transform="translate("+d.left+"px,"+d.top+"px)":(g.left=d.left,g.top=d.top),g}}});var P="iframe",Q="//about:blank",R=function(a){if(n.currTemplate[P]){var b=n.currTemplate[P].find("iframe");b.length&&(a||(b[0].src=Q),n.isIE8&&b.css("display",a?"block":"none"))}};a.magnificPopup.registerModule(P,{options:{markup:'<div class="mfp-iframe-scaler"><div class="mfp-close"></div><iframe class="mfp-iframe" src="//about:blank" frameborder="0" allowfullscreen></iframe></div>',srcAction:"iframe_src",patterns:{youtube:{index:"youtube.com",id:"v=",src:"//www.youtube.com/embed/%id%?autoplay=1"},vimeo:{index:"vimeo.com/",id:"/",src:"//player.vimeo.com/video/%id%?autoplay=1"},gmaps:{index:"//maps.google.",src:"%id%&output=embed"}}},proto:{initIframe:function(){n.types.push(P),w("BeforeChange",function(a,b,c){b!==c&&(b===P?R():c===P&&R(!0))}),w(b+"."+P,function(){R()})},getIframe:function(b,c){var d=b.src,e=n.st.iframe;a.each(e.patterns,function(){if(d.indexOf(this.index)>-1)return this.id&&(typeof this.id=="string"?d=d.substr(d.lastIndexOf(this.id)+this.id.length,d.length):d=this.id.call(this,d)),d=this.src.replace("%id%",d),!1});var f={};return e.srcAction&&(f[e.srcAction]=d),n._parseMarkup(c,f,b),n.updateStatus("ready"),c}}});var S=function(a){var b=n.items.length;return a>b-1?a-b:a<0?b+a:a},T=function(a,b,c){return a.replace(/%curr%/gi,b+1).replace(/%total%/gi,c)};a.magnificPopup.registerModule("gallery",{options:{enabled:!1,arrowMarkup:'<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',preload:[0,2],navigateByImgClick:!0,arrows:!0,tPrev:"Previous (Left arrow key)",tNext:"Next (Right arrow key)",tCounter:"%curr% of %total%"},proto:{initGallery:function(){var c=n.st.gallery,d=".mfp-gallery";n.direction=!0;if(!c||!c.enabled)return!1;u+=" mfp-gallery",w(g+d,function(){c.navigateByImgClick&&n.wrap.on("click"+d,".mfp-img",function(){if(n.items.length>1)return n.next(),!1}),s.on("keydown"+d,function(a){a.keyCode===37?n.prev():a.keyCode===39&&n.next()})}),w("UpdateStatus"+d,function(a,b){b.text&&(b.text=T(b.text,n.currItem.index,n.items.length))}),w(f+d,function(a,b,d,e){var f=n.items.length;d.counter=f>1?T(c.tCounter,e.index,f):""}),w("BuildControls"+d,function(){if(n.items.length>1&&c.arrows&&!n.arrowLeft){var b=c.arrowMarkup,d=n.arrowLeft=a(b.replace(/%title%/gi,c.tPrev).replace(/%dir%/gi,"left")).addClass(m),e=n.arrowRight=a(b.replace(/%title%/gi,c.tNext).replace(/%dir%/gi,"right")).addClass(m);d.click(function(){n.prev()}),e.click(function(){n.next()}),n.container.append(d.add(e))}}),w(h+d,function(){n._preloadTimeout&&clearTimeout(n._preloadTimeout),n._preloadTimeout=setTimeout(function(){n.preloadNearbyImages(),n._preloadTimeout=null},16)}),w(b+d,function(){s.off(d),n.wrap.off("click"+d),n.arrowRight=n.arrowLeft=null})},next:function(){n.direction=!0,n.index=S(n.index+1),n.updateItemHTML()},prev:function(){n.direction=!1,n.index=S(n.index-1),n.updateItemHTML()},goTo:function(a){n.direction=a>=n.index,n.index=a,n.updateItemHTML()},preloadNearbyImages:function(){var a=n.st.gallery.preload,b=Math.min(a[0],n.items.length),c=Math.min(a[1],n.items.length),d;for(d=1;d<=(n.direction?c:b);d++)n._preloadItem(n.index+d);for(d=1;d<=(n.direction?b:c);d++)n._preloadItem(n.index-d)},_preloadItem:function(b){b=S(b);if(n.items[b].preloaded)return;var c=n.items[b];c.parsed||(c=n.parseEl(b)),y("LazyLoad",c),c.type==="image"&&(c.img=a('<img class="mfp-img" />').on("load.mfploader",function(){c.hasSize=!0}).on("error.mfploader",function(){c.hasSize=!0,c.loadError=!0,y("LazyLoadError",c)}).attr("src",c.src)),c.preloaded=!0}}});var U="retina";a.magnificPopup.registerModule(U,{options:{replaceSrc:function(a){return a.src.replace(/\.\w+$/,function(a){return"@2x"+a})},ratio:1},proto:{initRetina:function(){if(window.devicePixelRatio>1){var a=n.st.retina,b=a.ratio;b=isNaN(b)?b():b,b>1&&(w("ImageHasSize."+U,function(a,c){c.img.css({"max-width":c.img[0].naturalWidth/b,width:"100%"})}),w("ElementParse."+U,function(c,d){d.src=a.replaceSrc(d,b)}))}}}}),A()})
/**
 * File js-enabled.js
 *
 * If Javascript is enabled, replace the <body> class "no-js".
 */
document.body.className = document.body.className.replace( 'no-js', 'js' );
/**
 * File modal.js
 *
 * Deal with multiple modals and their media.
 */
window.WDS_Modal = {};

( function ( window, $, app ) {

	// Constructor.
	app.init = function() {
		app.cache();

		if ( app.meetsRequirements() ) {
			app.bindEvents();
		}
	};

	// Cache all the things.
	app.cache = function() {
		app.$c = {
			body: $( 'body' ),
		};
	};

	// Do we meet the requirements?
	app.meetsRequirements = function() {
		return $( '.modal-trigger' ).length;
	};

	// Combine all events.
	app.bindEvents = function() {

		// Triger a modal to open
		app.$c.body.on( 'click', '.modal-trigger', app.openModal );

		// Trigger the close button to close the modal
		app.$c.body.on( 'click', '.close', app.closeModal );

		// Allow the user to close the modal by hitting the esc key
		app.$c.body.on( 'keydown', app.escKeyClose );

		// Allow the user to close the modal by clicking outside of the modal
		app.$c.body.on( 'click', 'div.modal-open', app.closeModalByClick );
	};

	// Open the modal.
	app.openModal = function() {

		// Figure out which modal we're opening and store the object.
		var $modal = $( $( this ).data( 'target' ) );

		// Display the modal.
		$modal.addClass( 'modal-open' );

		// Add body class.
		app.$c.body.addClass( 'modal-open' );
	};

	// Close the modal.
	app.closeModal = function() {

		// Figure the opened modal we're closing and store the object.
		var $modal = $( $( 'div.modal-open .close' ).data( 'target' ) );

		// Find the iframe in the $modal object.
		var $iframe = $modal.find( 'iframe' );

		// Get the iframe src URL.
		var url = $iframe.attr( 'src' );

		// Remove the source URL, then add it back, so the video can be played again later.
		$iframe.attr( 'src', '' ).attr( 'src', url );

		// Finally, hide the modal.
		$modal.removeClass( 'modal-open' );

		// Remove the body class.
		app.$c.body.removeClass( 'modal-open' );
	};

	// Close if "esc" key is pressed.
	app.escKeyClose = function(e) {
		if ( 27 == e.keyCode ) {
			app.closeModal();
		}
	};

	// Close if the user clicks outside of the modal
	app.closeModalByClick = function(e) {

		// If the parent container is NOT the modal dialog container, close the modal
		if ( ! $( e.target ).parents( 'div' ).hasClass( 'modal-dialog' ) ) {
			app.closeModal();
		}
	};

	// Engage!
	$( app.init );

} )( window, jQuery, window.WDS_Modal );
/*
	scripts.js

	License: GNU General Public License v3.0
	License URI: http://www.gnu.org/licenses/gpl-3.0.html

	Copyright: (c) 2013 Alexander "Alx" Agnarson, http://alxmedia.se
*/

"use strict";

jQuery(document).ready(function($) {


$('.lazyload').lazyload({
  // Sets the pixels to load earlier. Setting threshold to 200 causes image to load 200 pixels
  // before it appears on viewport. It should be greater or equal zero.
  threshold: 0,

  // Sets the callback function when the load event is firing.
  // element: The content in lazyload tag will be returned as a jQuery object.
  load: function(element) {},

  // Sets events to trigger lazyload. Default is customized event `appear`, it will trigger when
  // element appear in screen. You could set other events including each one separated by a space.
  trigger: "appear touchstart"
});

// $('.lightbox').magnificPopup({type:'image'});
// $('.wpb-modal-image').magnificPopup({type:'image'});

jQuery( 'article' ).magnificPopup({
        type: 'image',
        delegate: ".wpb-modal-image",
        gallery: {
            enabled: true,
            preload: [0,2],
			navigateByImgClick: true,
			arrowMarkup: '<span class="mfp-arrow mfp-arrow-%dir%" title="%title%"><i class="fa fa-2x fa-angle-%dir%"></i></span>',
			tPrev: 'Previous',
			tNext: 'Next',
			tCounter: '<span class="mfp-counter">%curr% of %total%</span>'
        },
});

/*  Toggle header search
/* ------------------------------------ */
	$('.toggle-search').click(function(){
		$('.toggle-search').toggleClass('active');
		$('.search-expand').fadeToggle(250);
            setTimeout(function(){
                $('.search-expand input').focus();
            }, 300);
	});

/*  Scroll to top
/* ------------------------------------ */
	$('a#gototop').click(function() {
		$('html, body').animate({scrollTop:0},'slow');
		return false;
	});

/*  Comments / pingbacks tabs
/* ------------------------------------ */
    $(".tabs .tabs-title").click(function() {
        $(".tabs .tabs-title").removeClass('is-active');
        $(this).addClass("is-active");
        $(".tabs-content .tabs-panel").removeClass('is-active').hide();
        var selected_tab = $(this).find("a").attr("href");
        $(selected_tab).fadeIn();
        console.log(selected_tab);
        return false;
    });

/*  Table odd row class
/* ------------------------------------ */
	$('table tr:odd').addClass('alt');


/*  Dropdown menu animation
/* ------------------------------------ */
	$('.nav ul.sub-menu').hide();
	$('.nav li').hover(
		function() {
			$(this).children('ul.sub-menu').slideDown('fast');
		},
		function() {
			$(this).children('ul.sub-menu').hide();
		}
	);

/*  Mobile menu smooth toggle height
/* ------------------------------------ */
	$('.nav-toggle').on('click', function() {
		slide($('.nav-wrap .nav', $(this).parent()));
	});

	function slide(content) {
		var wrapper = content.parent();
		var contentHeight = content.outerHeight(true);
		var wrapperHeight = wrapper.height();

		wrapper.toggleClass('expand');
		if (wrapper.hasClass('expand')) {
		setTimeout(function() {
			wrapper.addClass('transition').css('height', contentHeight);
		}, 10);
	}
	else {
		setTimeout(function() {
			wrapper.css('height', wrapperHeight);
			setTimeout(function() {
			wrapper.addClass('transition').css('height', 0);
			}, 10);
		}, 10);
	}

	wrapper.one('transitionEnd webkitTransitionEnd transitionend oTransitionEnd msTransitionEnd', function() {
		if(wrapper.hasClass('open')) {
			wrapper.removeClass('transition').css('height', 'auto');
		}
	});
	}

});
/**
 * File search.js
 *
 * Deal with the search form.
 */
window.WDS_Search = {};

( function ( window, $, app ) {

	// Constructor.
	app.init = function() {
		app.cache();

		if ( app.meetsRequirements() ) {
			app.bindEvents();
		}
	};

	// Cache all the things.
	app.cache = function() {
		app.$c = {
			body: $( 'body' ),
		};
	};

	// Do we meet the requirements?
	app.meetsRequirements = function() {
		return $( '.search-field' ).length;
	};

	// Combine all events.
	app.bindEvents = function() {

		// Remove placeholder text from search field on focus.
		app.$c.body.on( 'focus', '.search-field', app.removePlaceholderText );

		// Add placeholder text back to search field on blur.
		app.$c.body.on( 'blur', '.search-field', app.addPlaceholderText );
	};

	// Remove placeholder text from search field.
	app.removePlaceholderText = function() {

		var $search_field = $( this );

		$search_field.data( 'placeholder', $search_field.attr( 'placeholder' ) ).attr( 'placeholder', '' );
	};

	// Replace placeholder text from search field.
	app.addPlaceholderText = function() {

		var $search_field = $( this );

		$search_field.attr( 'placeholder', $search_field.data( 'placeholder' ) ).data( 'placeholder', '' );
	};

	// Engage!
	$( app.init );

} )( window, jQuery, window.WDS_Search );
/**
 * File skip-link-focus-fix.js.
 *
 * Helps with accessibility for keyboard only users.
 *
 * Learn more: https://git.io/vWdr2
 */
( function() {
	var isWebkit = navigator.userAgent.toLowerCase().indexOf( 'webkit' ) > -1,
	    isOpera  = navigator.userAgent.toLowerCase().indexOf( 'opera' )  > -1,
	    isIe     = navigator.userAgent.toLowerCase().indexOf( 'msie' )   > -1;

	if ( ( isWebkit || isOpera || isIe ) && document.getElementById && window.addEventListener ) {
		window.addEventListener( 'hashchange', function() {
			var id = location.hash.substring( 1 ),
				element;

			if ( ! ( /^[A-z0-9_-]+$/.test( id ) ) ) {
				return;
			}

			element = document.getElementById( id );

			if ( element ) {
				if ( ! ( /^(?:a|select|input|button|textarea)$/i.test( element.tagName ) ) ) {
					element.tabIndex = -1;
				}

				element.focus();
			}
		}, false );
	}
})();
/*
     _ _      _       _
 ___| (_) ___| | __  (_)___
/ __| | |/ __| |/ /  | / __|
\__ \ | | (__|   < _ | \__ \
|___/_|_|\___|_|\_(_)/ |___/
                   |__/

 Version: 1.6.0
  Author: Ken Wheeler
 Website: http://kenwheeler.github.io
    Docs: http://kenwheeler.github.io/slick
    Repo: http://github.com/kenwheeler/slick
  Issues: http://github.com/kenwheeler/slick/issues

 */
!function(a){"use strict";"function"==typeof define&&define.amd?define(["jquery"],a):"undefined"!=typeof exports?module.exports=a(require("jquery")):a(jQuery)}(function(a){"use strict";var b=window.Slick||{};b=function(){function c(c,d){var f,e=this;e.defaults={accessibility:!0,adaptiveHeight:!1,appendArrows:a(c),appendDots:a(c),arrows:!0,asNavFor:null,prevArrow:'<button type="button" data-role="none" class="slick-prev" aria-label="Previous" tabindex="0" role="button">Previous</button>',nextArrow:'<button type="button" data-role="none" class="slick-next" aria-label="Next" tabindex="0" role="button">Next</button>',autoplay:!1,autoplaySpeed:3e3,centerMode:!1,centerPadding:"50px",cssEase:"ease",customPaging:function(b,c){return a('<button type="button" data-role="none" role="button" tabindex="0" />').text(c+1)},dots:!1,dotsClass:"slick-dots",draggable:!0,easing:"linear",edgeFriction:.35,fade:!1,focusOnSelect:!1,infinite:!0,initialSlide:0,lazyLoad:"ondemand",mobileFirst:!1,pauseOnHover:!0,pauseOnFocus:!0,pauseOnDotsHover:!1,respondTo:"window",responsive:null,rows:1,rtl:!1,slide:"",slidesPerRow:1,slidesToShow:1,slidesToScroll:1,speed:500,swipe:!0,swipeToSlide:!1,touchMove:!0,touchThreshold:5,useCSS:!0,useTransform:!0,variableWidth:!1,vertical:!1,verticalSwiping:!1,waitForAnimate:!0,zIndex:1e3},e.initials={animating:!1,dragging:!1,autoPlayTimer:null,currentDirection:0,currentLeft:null,currentSlide:0,direction:1,$dots:null,listWidth:null,listHeight:null,loadIndex:0,$nextArrow:null,$prevArrow:null,slideCount:null,slideWidth:null,$slideTrack:null,$slides:null,sliding:!1,slideOffset:0,swipeLeft:null,$list:null,touchObject:{},transformsEnabled:!1,unslicked:!1},a.extend(e,e.initials),e.activeBreakpoint=null,e.animType=null,e.animProp=null,e.breakpoints=[],e.breakpointSettings=[],e.cssTransitions=!1,e.focussed=!1,e.interrupted=!1,e.hidden="hidden",e.paused=!0,e.positionProp=null,e.respondTo=null,e.rowCount=1,e.shouldClick=!0,e.$slider=a(c),e.$slidesCache=null,e.transformType=null,e.transitionType=null,e.visibilityChange="visibilitychange",e.windowWidth=0,e.windowTimer=null,f=a(c).data("slick")||{},e.options=a.extend({},e.defaults,d,f),e.currentSlide=e.options.initialSlide,e.originalSettings=e.options,"undefined"!=typeof document.mozHidden?(e.hidden="mozHidden",e.visibilityChange="mozvisibilitychange"):"undefined"!=typeof document.webkitHidden&&(e.hidden="webkitHidden",e.visibilityChange="webkitvisibilitychange"),e.autoPlay=a.proxy(e.autoPlay,e),e.autoPlayClear=a.proxy(e.autoPlayClear,e),e.autoPlayIterator=a.proxy(e.autoPlayIterator,e),e.changeSlide=a.proxy(e.changeSlide,e),e.clickHandler=a.proxy(e.clickHandler,e),e.selectHandler=a.proxy(e.selectHandler,e),e.setPosition=a.proxy(e.setPosition,e),e.swipeHandler=a.proxy(e.swipeHandler,e),e.dragHandler=a.proxy(e.dragHandler,e),e.keyHandler=a.proxy(e.keyHandler,e),e.instanceUid=b++,e.htmlExpr=/^(?:\s*(<[\w\W]+>)[^>]*)$/,e.registerBreakpoints(),e.init(!0)}var b=0;return c}(),b.prototype.activateADA=function(){var a=this;a.$slideTrack.find(".slick-active").attr({"aria-hidden":"false"}).find("a, input, button, select").attr({tabindex:"0"})},b.prototype.addSlide=b.prototype.slickAdd=function(b,c,d){var e=this;if("boolean"==typeof c)d=c,c=null;else if(0>c||c>=e.slideCount)return!1;e.unload(),"number"==typeof c?0===c&&0===e.$slides.length?a(b).appendTo(e.$slideTrack):d?a(b).insertBefore(e.$slides.eq(c)):a(b).insertAfter(e.$slides.eq(c)):d===!0?a(b).prependTo(e.$slideTrack):a(b).appendTo(e.$slideTrack),e.$slides=e.$slideTrack.children(this.options.slide),e.$slideTrack.children(this.options.slide).detach(),e.$slideTrack.append(e.$slides),e.$slides.each(function(b,c){a(c).attr("data-slick-index",b)}),e.$slidesCache=e.$slides,e.reinit()},b.prototype.animateHeight=function(){var a=this;if(1===a.options.slidesToShow&&a.options.adaptiveHeight===!0&&a.options.vertical===!1){var b=a.$slides.eq(a.currentSlide).outerHeight(!0);a.$list.animate({height:b},a.options.speed)}},b.prototype.animateSlide=function(b,c){var d={},e=this;e.animateHeight(),e.options.rtl===!0&&e.options.vertical===!1&&(b=-b),e.transformsEnabled===!1?e.options.vertical===!1?e.$slideTrack.animate({left:b},e.options.speed,e.options.easing,c):e.$slideTrack.animate({top:b},e.options.speed,e.options.easing,c):e.cssTransitions===!1?(e.options.rtl===!0&&(e.currentLeft=-e.currentLeft),a({animStart:e.currentLeft}).animate({animStart:b},{duration:e.options.speed,easing:e.options.easing,step:function(a){a=Math.ceil(a),e.options.vertical===!1?(d[e.animType]="translate("+a+"px, 0px)",e.$slideTrack.css(d)):(d[e.animType]="translate(0px,"+a+"px)",e.$slideTrack.css(d))},complete:function(){c&&c.call()}})):(e.applyTransition(),b=Math.ceil(b),e.options.vertical===!1?d[e.animType]="translate3d("+b+"px, 0px, 0px)":d[e.animType]="translate3d(0px,"+b+"px, 0px)",e.$slideTrack.css(d),c&&setTimeout(function(){e.disableTransition(),c.call()},e.options.speed))},b.prototype.getNavTarget=function(){var b=this,c=b.options.asNavFor;return c&&null!==c&&(c=a(c).not(b.$slider)),c},b.prototype.asNavFor=function(b){var c=this,d=c.getNavTarget();null!==d&&"object"==typeof d&&d.each(function(){var c=a(this).slick("getSlick");c.unslicked||c.slideHandler(b,!0)})},b.prototype.applyTransition=function(a){var b=this,c={};b.options.fade===!1?c[b.transitionType]=b.transformType+" "+b.options.speed+"ms "+b.options.cssEase:c[b.transitionType]="opacity "+b.options.speed+"ms "+b.options.cssEase,b.options.fade===!1?b.$slideTrack.css(c):b.$slides.eq(a).css(c)},b.prototype.autoPlay=function(){var a=this;a.autoPlayClear(),a.slideCount>a.options.slidesToShow&&(a.autoPlayTimer=setInterval(a.autoPlayIterator,a.options.autoplaySpeed))},b.prototype.autoPlayClear=function(){var a=this;a.autoPlayTimer&&clearInterval(a.autoPlayTimer)},b.prototype.autoPlayIterator=function(){var a=this,b=a.currentSlide+a.options.slidesToScroll;a.paused||a.interrupted||a.focussed||(a.options.infinite===!1&&(1===a.direction&&a.currentSlide+1===a.slideCount-1?a.direction=0:0===a.direction&&(b=a.currentSlide-a.options.slidesToScroll,a.currentSlide-1===0&&(a.direction=1))),a.slideHandler(b))},b.prototype.buildArrows=function(){var b=this;b.options.arrows===!0&&(b.$prevArrow=a(b.options.prevArrow).addClass("slick-arrow"),b.$nextArrow=a(b.options.nextArrow).addClass("slick-arrow"),b.slideCount>b.options.slidesToShow?(b.$prevArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),b.$nextArrow.removeClass("slick-hidden").removeAttr("aria-hidden tabindex"),b.htmlExpr.test(b.options.prevArrow)&&b.$prevArrow.prependTo(b.options.appendArrows),b.htmlExpr.test(b.options.nextArrow)&&b.$nextArrow.appendTo(b.options.appendArrows),b.options.infinite!==!0&&b.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true")):b.$prevArrow.add(b.$nextArrow).addClass("slick-hidden").attr({"aria-disabled":"true",tabindex:"-1"}))},b.prototype.buildDots=function(){var c,d,b=this;if(b.options.dots===!0&&b.slideCount>b.options.slidesToShow){for(b.$slider.addClass("slick-dotted"),d=a("<ul />").addClass(b.options.dotsClass),c=0;c<=b.getDotCount();c+=1)d.append(a("<li />").append(b.options.customPaging.call(this,b,c)));b.$dots=d.appendTo(b.options.appendDots),b.$dots.find("li").first().addClass("slick-active").attr("aria-hidden","false")}},b.prototype.buildOut=function(){var b=this;b.$slides=b.$slider.children(b.options.slide+":not(.slick-cloned)").addClass("slick-slide"),b.slideCount=b.$slides.length,b.$slides.each(function(b,c){a(c).attr("data-slick-index",b).data("originalStyling",a(c).attr("style")||"")}),b.$slider.addClass("slick-slider"),b.$slideTrack=0===b.slideCount?a('<div class="slick-track"/>').appendTo(b.$slider):b.$slides.wrapAll('<div class="slick-track"/>').parent(),b.$list=b.$slideTrack.wrap('<div aria-live="polite" class="slick-list"/>').parent(),b.$slideTrack.css("opacity",0),(b.options.centerMode===!0||b.options.swipeToSlide===!0)&&(b.options.slidesToScroll=1),a("img[data-lazy]",b.$slider).not("[src]").addClass("slick-loading"),b.setupInfinite(),b.buildArrows(),b.buildDots(),b.updateDots(),b.setSlideClasses("number"==typeof b.currentSlide?b.currentSlide:0),b.options.draggable===!0&&b.$list.addClass("draggable")},b.prototype.buildRows=function(){var b,c,d,e,f,g,h,a=this;if(e=document.createDocumentFragment(),g=a.$slider.children(),a.options.rows>1){for(h=a.options.slidesPerRow*a.options.rows,f=Math.ceil(g.length/h),b=0;f>b;b++){var i=document.createElement("div");for(c=0;c<a.options.rows;c++){var j=document.createElement("div");for(d=0;d<a.options.slidesPerRow;d++){var k=b*h+(c*a.options.slidesPerRow+d);g.get(k)&&j.appendChild(g.get(k))}i.appendChild(j)}e.appendChild(i)}a.$slider.empty().append(e),a.$slider.children().children().children().css({width:100/a.options.slidesPerRow+"%",display:"inline-block"})}},b.prototype.checkResponsive=function(b,c){var e,f,g,d=this,h=!1,i=d.$slider.width(),j=window.innerWidth||a(window).width();if("window"===d.respondTo?g=j:"slider"===d.respondTo?g=i:"min"===d.respondTo&&(g=Math.min(j,i)),d.options.responsive&&d.options.responsive.length&&null!==d.options.responsive){f=null;for(e in d.breakpoints)d.breakpoints.hasOwnProperty(e)&&(d.originalSettings.mobileFirst===!1?g<d.breakpoints[e]&&(f=d.breakpoints[e]):g>d.breakpoints[e]&&(f=d.breakpoints[e]));null!==f?null!==d.activeBreakpoint?(f!==d.activeBreakpoint||c)&&(d.activeBreakpoint=f,"unslick"===d.breakpointSettings[f]?d.unslick(f):(d.options=a.extend({},d.originalSettings,d.breakpointSettings[f]),b===!0&&(d.currentSlide=d.options.initialSlide),d.refresh(b)),h=f):(d.activeBreakpoint=f,"unslick"===d.breakpointSettings[f]?d.unslick(f):(d.options=a.extend({},d.originalSettings,d.breakpointSettings[f]),b===!0&&(d.currentSlide=d.options.initialSlide),d.refresh(b)),h=f):null!==d.activeBreakpoint&&(d.activeBreakpoint=null,d.options=d.originalSettings,b===!0&&(d.currentSlide=d.options.initialSlide),d.refresh(b),h=f),b||h===!1||d.$slider.trigger("breakpoint",[d,h])}},b.prototype.changeSlide=function(b,c){var f,g,h,d=this,e=a(b.currentTarget);switch(e.is("a")&&b.preventDefault(),e.is("li")||(e=e.closest("li")),h=d.slideCount%d.options.slidesToScroll!==0,f=h?0:(d.slideCount-d.currentSlide)%d.options.slidesToScroll,b.data.message){case"previous":g=0===f?d.options.slidesToScroll:d.options.slidesToShow-f,d.slideCount>d.options.slidesToShow&&d.slideHandler(d.currentSlide-g,!1,c);break;case"next":g=0===f?d.options.slidesToScroll:f,d.slideCount>d.options.slidesToShow&&d.slideHandler(d.currentSlide+g,!1,c);break;case"index":var i=0===b.data.index?0:b.data.index||e.index()*d.options.slidesToScroll;d.slideHandler(d.checkNavigable(i),!1,c),e.children().trigger("focus");break;default:return}},b.prototype.checkNavigable=function(a){var c,d,b=this;if(c=b.getNavigableIndexes(),d=0,a>c[c.length-1])a=c[c.length-1];else for(var e in c){if(a<c[e]){a=d;break}d=c[e]}return a},b.prototype.cleanUpEvents=function(){var b=this;b.options.dots&&null!==b.$dots&&a("li",b.$dots).off("click.slick",b.changeSlide).off("mouseenter.slick",a.proxy(b.interrupt,b,!0)).off("mouseleave.slick",a.proxy(b.interrupt,b,!1)),b.$slider.off("focus.slick blur.slick"),b.options.arrows===!0&&b.slideCount>b.options.slidesToShow&&(b.$prevArrow&&b.$prevArrow.off("click.slick",b.changeSlide),b.$nextArrow&&b.$nextArrow.off("click.slick",b.changeSlide)),b.$list.off("touchstart.slick mousedown.slick",b.swipeHandler),b.$list.off("touchmove.slick mousemove.slick",b.swipeHandler),b.$list.off("touchend.slick mouseup.slick",b.swipeHandler),b.$list.off("touchcancel.slick mouseleave.slick",b.swipeHandler),b.$list.off("click.slick",b.clickHandler),a(document).off(b.visibilityChange,b.visibility),b.cleanUpSlideEvents(),b.options.accessibility===!0&&b.$list.off("keydown.slick",b.keyHandler),b.options.focusOnSelect===!0&&a(b.$slideTrack).children().off("click.slick",b.selectHandler),a(window).off("orientationchange.slick.slick-"+b.instanceUid,b.orientationChange),a(window).off("resize.slick.slick-"+b.instanceUid,b.resize),a("[draggable!=true]",b.$slideTrack).off("dragstart",b.preventDefault),a(window).off("load.slick.slick-"+b.instanceUid,b.setPosition),a(document).off("ready.slick.slick-"+b.instanceUid,b.setPosition)},b.prototype.cleanUpSlideEvents=function(){var b=this;b.$list.off("mouseenter.slick",a.proxy(b.interrupt,b,!0)),b.$list.off("mouseleave.slick",a.proxy(b.interrupt,b,!1))},b.prototype.cleanUpRows=function(){var b,a=this;a.options.rows>1&&(b=a.$slides.children().children(),b.removeAttr("style"),a.$slider.empty().append(b))},b.prototype.clickHandler=function(a){var b=this;b.shouldClick===!1&&(a.stopImmediatePropagation(),a.stopPropagation(),a.preventDefault())},b.prototype.destroy=function(b){var c=this;c.autoPlayClear(),c.touchObject={},c.cleanUpEvents(),a(".slick-cloned",c.$slider).detach(),c.$dots&&c.$dots.remove(),c.$prevArrow&&c.$prevArrow.length&&(c.$prevArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),c.htmlExpr.test(c.options.prevArrow)&&c.$prevArrow.remove()),c.$nextArrow&&c.$nextArrow.length&&(c.$nextArrow.removeClass("slick-disabled slick-arrow slick-hidden").removeAttr("aria-hidden aria-disabled tabindex").css("display",""),c.htmlExpr.test(c.options.nextArrow)&&c.$nextArrow.remove()),c.$slides&&(c.$slides.removeClass("slick-slide slick-active slick-center slick-visible slick-current").removeAttr("aria-hidden").removeAttr("data-slick-index").each(function(){a(this).attr("style",a(this).data("originalStyling"))}),c.$slideTrack.children(this.options.slide).detach(),c.$slideTrack.detach(),c.$list.detach(),c.$slider.append(c.$slides)),c.cleanUpRows(),c.$slider.removeClass("slick-slider"),c.$slider.removeClass("slick-initialized"),c.$slider.removeClass("slick-dotted"),c.unslicked=!0,b||c.$slider.trigger("destroy",[c])},b.prototype.disableTransition=function(a){var b=this,c={};c[b.transitionType]="",b.options.fade===!1?b.$slideTrack.css(c):b.$slides.eq(a).css(c)},b.prototype.fadeSlide=function(a,b){var c=this;c.cssTransitions===!1?(c.$slides.eq(a).css({zIndex:c.options.zIndex}),c.$slides.eq(a).animate({opacity:1},c.options.speed,c.options.easing,b)):(c.applyTransition(a),c.$slides.eq(a).css({opacity:1,zIndex:c.options.zIndex}),b&&setTimeout(function(){c.disableTransition(a),b.call()},c.options.speed))},b.prototype.fadeSlideOut=function(a){var b=this;b.cssTransitions===!1?b.$slides.eq(a).animate({opacity:0,zIndex:b.options.zIndex-2},b.options.speed,b.options.easing):(b.applyTransition(a),b.$slides.eq(a).css({opacity:0,zIndex:b.options.zIndex-2}))},b.prototype.filterSlides=b.prototype.slickFilter=function(a){var b=this;null!==a&&(b.$slidesCache=b.$slides,b.unload(),b.$slideTrack.children(this.options.slide).detach(),b.$slidesCache.filter(a).appendTo(b.$slideTrack),b.reinit())},b.prototype.focusHandler=function(){var b=this;b.$slider.off("focus.slick blur.slick").on("focus.slick blur.slick","*:not(.slick-arrow)",function(c){c.stopImmediatePropagation();var d=a(this);setTimeout(function(){b.options.pauseOnFocus&&(b.focussed=d.is(":focus"),b.autoPlay())},0)})},b.prototype.getCurrent=b.prototype.slickCurrentSlide=function(){var a=this;return a.currentSlide},b.prototype.getDotCount=function(){var a=this,b=0,c=0,d=0;if(a.options.infinite===!0)for(;b<a.slideCount;)++d,b=c+a.options.slidesToScroll,c+=a.options.slidesToScroll<=a.options.slidesToShow?a.options.slidesToScroll:a.options.slidesToShow;else if(a.options.centerMode===!0)d=a.slideCount;else if(a.options.asNavFor)for(;b<a.slideCount;)++d,b=c+a.options.slidesToScroll,c+=a.options.slidesToScroll<=a.options.slidesToShow?a.options.slidesToScroll:a.options.slidesToShow;else d=1+Math.ceil((a.slideCount-a.options.slidesToShow)/a.options.slidesToScroll);return d-1},b.prototype.getLeft=function(a){var c,d,f,b=this,e=0;return b.slideOffset=0,d=b.$slides.first().outerHeight(!0),b.options.infinite===!0?(b.slideCount>b.options.slidesToShow&&(b.slideOffset=b.slideWidth*b.options.slidesToShow*-1,e=d*b.options.slidesToShow*-1),b.slideCount%b.options.slidesToScroll!==0&&a+b.options.slidesToScroll>b.slideCount&&b.slideCount>b.options.slidesToShow&&(a>b.slideCount?(b.slideOffset=(b.options.slidesToShow-(a-b.slideCount))*b.slideWidth*-1,e=(b.options.slidesToShow-(a-b.slideCount))*d*-1):(b.slideOffset=b.slideCount%b.options.slidesToScroll*b.slideWidth*-1,e=b.slideCount%b.options.slidesToScroll*d*-1))):a+b.options.slidesToShow>b.slideCount&&(b.slideOffset=(a+b.options.slidesToShow-b.slideCount)*b.slideWidth,e=(a+b.options.slidesToShow-b.slideCount)*d),b.slideCount<=b.options.slidesToShow&&(b.slideOffset=0,e=0),b.options.centerMode===!0&&b.options.infinite===!0?b.slideOffset+=b.slideWidth*Math.floor(b.options.slidesToShow/2)-b.slideWidth:b.options.centerMode===!0&&(b.slideOffset=0,b.slideOffset+=b.slideWidth*Math.floor(b.options.slidesToShow/2)),c=b.options.vertical===!1?a*b.slideWidth*-1+b.slideOffset:a*d*-1+e,b.options.variableWidth===!0&&(f=b.slideCount<=b.options.slidesToShow||b.options.infinite===!1?b.$slideTrack.children(".slick-slide").eq(a):b.$slideTrack.children(".slick-slide").eq(a+b.options.slidesToShow),c=b.options.rtl===!0?f[0]?-1*(b.$slideTrack.width()-f[0].offsetLeft-f.width()):0:f[0]?-1*f[0].offsetLeft:0,b.options.centerMode===!0&&(f=b.slideCount<=b.options.slidesToShow||b.options.infinite===!1?b.$slideTrack.children(".slick-slide").eq(a):b.$slideTrack.children(".slick-slide").eq(a+b.options.slidesToShow+1),c=b.options.rtl===!0?f[0]?-1*(b.$slideTrack.width()-f[0].offsetLeft-f.width()):0:f[0]?-1*f[0].offsetLeft:0,c+=(b.$list.width()-f.outerWidth())/2)),c},b.prototype.getOption=b.prototype.slickGetOption=function(a){var b=this;return b.options[a]},b.prototype.getNavigableIndexes=function(){var e,a=this,b=0,c=0,d=[];for(a.options.infinite===!1?e=a.slideCount:(b=-1*a.options.slidesToScroll,c=-1*a.options.slidesToScroll,e=2*a.slideCount);e>b;)d.push(b),b=c+a.options.slidesToScroll,c+=a.options.slidesToScroll<=a.options.slidesToShow?a.options.slidesToScroll:a.options.slidesToShow;return d},b.prototype.getSlick=function(){return this},b.prototype.getSlideCount=function(){var c,d,e,b=this;return e=b.options.centerMode===!0?b.slideWidth*Math.floor(b.options.slidesToShow/2):0,b.options.swipeToSlide===!0?(b.$slideTrack.find(".slick-slide").each(function(c,f){return f.offsetLeft-e+a(f).outerWidth()/2>-1*b.swipeLeft?(d=f,!1):void 0}),c=Math.abs(a(d).attr("data-slick-index")-b.currentSlide)||1):b.options.slidesToScroll},b.prototype.goTo=b.prototype.slickGoTo=function(a,b){var c=this;c.changeSlide({data:{message:"index",index:parseInt(a)}},b)},b.prototype.init=function(b){var c=this;a(c.$slider).hasClass("slick-initialized")||(a(c.$slider).addClass("slick-initialized"),c.buildRows(),c.buildOut(),c.setProps(),c.startLoad(),c.loadSlider(),c.initializeEvents(),c.updateArrows(),c.updateDots(),c.checkResponsive(!0),c.focusHandler()),b&&c.$slider.trigger("init",[c]),c.options.accessibility===!0&&c.initADA(),c.options.autoplay&&(c.paused=!1,c.autoPlay())},b.prototype.initADA=function(){var b=this;b.$slides.add(b.$slideTrack.find(".slick-cloned")).attr({"aria-hidden":"true",tabindex:"-1"}).find("a, input, button, select").attr({tabindex:"-1"}),b.$slideTrack.attr("role","listbox"),b.$slides.not(b.$slideTrack.find(".slick-cloned")).each(function(c){a(this).attr({role:"option","aria-describedby":"slick-slide"+b.instanceUid+c})}),null!==b.$dots&&b.$dots.attr("role","tablist").find("li").each(function(c){a(this).attr({role:"presentation","aria-selected":"false","aria-controls":"navigation"+b.instanceUid+c,id:"slick-slide"+b.instanceUid+c})}).first().attr("aria-selected","true").end().find("button").attr("role","button").end().closest("div").attr("role","toolbar"),b.activateADA()},b.prototype.initArrowEvents=function(){var a=this;a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&(a.$prevArrow.off("click.slick").on("click.slick",{message:"previous"},a.changeSlide),a.$nextArrow.off("click.slick").on("click.slick",{message:"next"},a.changeSlide))},b.prototype.initDotEvents=function(){var b=this;b.options.dots===!0&&b.slideCount>b.options.slidesToShow&&a("li",b.$dots).on("click.slick",{message:"index"},b.changeSlide),b.options.dots===!0&&b.options.pauseOnDotsHover===!0&&a("li",b.$dots).on("mouseenter.slick",a.proxy(b.interrupt,b,!0)).on("mouseleave.slick",a.proxy(b.interrupt,b,!1))},b.prototype.initSlideEvents=function(){var b=this;b.options.pauseOnHover&&(b.$list.on("mouseenter.slick",a.proxy(b.interrupt,b,!0)),b.$list.on("mouseleave.slick",a.proxy(b.interrupt,b,!1)))},b.prototype.initializeEvents=function(){var b=this;b.initArrowEvents(),b.initDotEvents(),b.initSlideEvents(),b.$list.on("touchstart.slick mousedown.slick",{action:"start"},b.swipeHandler),b.$list.on("touchmove.slick mousemove.slick",{action:"move"},b.swipeHandler),b.$list.on("touchend.slick mouseup.slick",{action:"end"},b.swipeHandler),b.$list.on("touchcancel.slick mouseleave.slick",{action:"end"},b.swipeHandler),b.$list.on("click.slick",b.clickHandler),a(document).on(b.visibilityChange,a.proxy(b.visibility,b)),b.options.accessibility===!0&&b.$list.on("keydown.slick",b.keyHandler),b.options.focusOnSelect===!0&&a(b.$slideTrack).children().on("click.slick",b.selectHandler),a(window).on("orientationchange.slick.slick-"+b.instanceUid,a.proxy(b.orientationChange,b)),a(window).on("resize.slick.slick-"+b.instanceUid,a.proxy(b.resize,b)),a("[draggable!=true]",b.$slideTrack).on("dragstart",b.preventDefault),a(window).on("load.slick.slick-"+b.instanceUid,b.setPosition),a(document).on("ready.slick.slick-"+b.instanceUid,b.setPosition)},b.prototype.initUI=function(){var a=this;a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&(a.$prevArrow.show(),a.$nextArrow.show()),a.options.dots===!0&&a.slideCount>a.options.slidesToShow&&a.$dots.show()},b.prototype.keyHandler=function(a){var b=this;a.target.tagName.match("TEXTAREA|INPUT|SELECT")||(37===a.keyCode&&b.options.accessibility===!0?b.changeSlide({data:{message:b.options.rtl===!0?"next":"previous"}}):39===a.keyCode&&b.options.accessibility===!0&&b.changeSlide({data:{message:b.options.rtl===!0?"previous":"next"}}))},b.prototype.lazyLoad=function(){function g(c){a("img[data-lazy]",c).each(function(){var c=a(this),d=a(this).attr("data-lazy"),e=document.createElement("img");e.onload=function(){c.animate({opacity:0},100,function(){c.attr("src",d).animate({opacity:1},200,function(){c.removeAttr("data-lazy").removeClass("slick-loading")}),b.$slider.trigger("lazyLoaded",[b,c,d])})},e.onerror=function(){c.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),b.$slider.trigger("lazyLoadError",[b,c,d])},e.src=d})}var c,d,e,f,b=this;b.options.centerMode===!0?b.options.infinite===!0?(e=b.currentSlide+(b.options.slidesToShow/2+1),f=e+b.options.slidesToShow+2):(e=Math.max(0,b.currentSlide-(b.options.slidesToShow/2+1)),f=2+(b.options.slidesToShow/2+1)+b.currentSlide):(e=b.options.infinite?b.options.slidesToShow+b.currentSlide:b.currentSlide,f=Math.ceil(e+b.options.slidesToShow),b.options.fade===!0&&(e>0&&e--,f<=b.slideCount&&f++)),c=b.$slider.find(".slick-slide").slice(e,f),g(c),b.slideCount<=b.options.slidesToShow?(d=b.$slider.find(".slick-slide"),g(d)):b.currentSlide>=b.slideCount-b.options.slidesToShow?(d=b.$slider.find(".slick-cloned").slice(0,b.options.slidesToShow),g(d)):0===b.currentSlide&&(d=b.$slider.find(".slick-cloned").slice(-1*b.options.slidesToShow),g(d))},b.prototype.loadSlider=function(){var a=this;a.setPosition(),a.$slideTrack.css({opacity:1}),a.$slider.removeClass("slick-loading"),a.initUI(),"progressive"===a.options.lazyLoad&&a.progressiveLazyLoad()},b.prototype.next=b.prototype.slickNext=function(){var a=this;a.changeSlide({data:{message:"next"}})},b.prototype.orientationChange=function(){var a=this;a.checkResponsive(),a.setPosition()},b.prototype.pause=b.prototype.slickPause=function(){var a=this;a.autoPlayClear(),a.paused=!0},b.prototype.play=b.prototype.slickPlay=function(){var a=this;a.autoPlay(),a.options.autoplay=!0,a.paused=!1,a.focussed=!1,a.interrupted=!1},b.prototype.postSlide=function(a){var b=this;b.unslicked||(b.$slider.trigger("afterChange",[b,a]),b.animating=!1,b.setPosition(),b.swipeLeft=null,b.options.autoplay&&b.autoPlay(),b.options.accessibility===!0&&b.initADA())},b.prototype.prev=b.prototype.slickPrev=function(){var a=this;a.changeSlide({data:{message:"previous"}})},b.prototype.preventDefault=function(a){a.preventDefault()},b.prototype.progressiveLazyLoad=function(b){b=b||1;var e,f,g,c=this,d=a("img[data-lazy]",c.$slider);d.length?(e=d.first(),f=e.attr("data-lazy"),g=document.createElement("img"),g.onload=function(){e.attr("src",f).removeAttr("data-lazy").removeClass("slick-loading"),c.options.adaptiveHeight===!0&&c.setPosition(),c.$slider.trigger("lazyLoaded",[c,e,f]),c.progressiveLazyLoad()},g.onerror=function(){3>b?setTimeout(function(){c.progressiveLazyLoad(b+1)},500):(e.removeAttr("data-lazy").removeClass("slick-loading").addClass("slick-lazyload-error"),c.$slider.trigger("lazyLoadError",[c,e,f]),c.progressiveLazyLoad())},g.src=f):c.$slider.trigger("allImagesLoaded",[c])},b.prototype.refresh=function(b){var d,e,c=this;e=c.slideCount-c.options.slidesToShow,!c.options.infinite&&c.currentSlide>e&&(c.currentSlide=e),c.slideCount<=c.options.slidesToShow&&(c.currentSlide=0),d=c.currentSlide,c.destroy(!0),a.extend(c,c.initials,{currentSlide:d}),c.init(),b||c.changeSlide({data:{message:"index",index:d}},!1)},b.prototype.registerBreakpoints=function(){var c,d,e,b=this,f=b.options.responsive||null;if("array"===a.type(f)&&f.length){b.respondTo=b.options.respondTo||"window";for(c in f)if(e=b.breakpoints.length-1,d=f[c].breakpoint,f.hasOwnProperty(c)){for(;e>=0;)b.breakpoints[e]&&b.breakpoints[e]===d&&b.breakpoints.splice(e,1),e--;b.breakpoints.push(d),b.breakpointSettings[d]=f[c].settings}b.breakpoints.sort(function(a,c){return b.options.mobileFirst?a-c:c-a})}},b.prototype.reinit=function(){var b=this;b.$slides=b.$slideTrack.children(b.options.slide).addClass("slick-slide"),b.slideCount=b.$slides.length,b.currentSlide>=b.slideCount&&0!==b.currentSlide&&(b.currentSlide=b.currentSlide-b.options.slidesToScroll),b.slideCount<=b.options.slidesToShow&&(b.currentSlide=0),b.registerBreakpoints(),b.setProps(),b.setupInfinite(),b.buildArrows(),b.updateArrows(),b.initArrowEvents(),b.buildDots(),b.updateDots(),b.initDotEvents(),b.cleanUpSlideEvents(),b.initSlideEvents(),b.checkResponsive(!1,!0),b.options.focusOnSelect===!0&&a(b.$slideTrack).children().on("click.slick",b.selectHandler),b.setSlideClasses("number"==typeof b.currentSlide?b.currentSlide:0),b.setPosition(),b.focusHandler(),b.paused=!b.options.autoplay,b.autoPlay(),b.$slider.trigger("reInit",[b])},b.prototype.resize=function(){var b=this;a(window).width()!==b.windowWidth&&(clearTimeout(b.windowDelay),b.windowDelay=window.setTimeout(function(){b.windowWidth=a(window).width(),b.checkResponsive(),b.unslicked||b.setPosition()},50))},b.prototype.removeSlide=b.prototype.slickRemove=function(a,b,c){var d=this;return"boolean"==typeof a?(b=a,a=b===!0?0:d.slideCount-1):a=b===!0?--a:a,d.slideCount<1||0>a||a>d.slideCount-1?!1:(d.unload(),c===!0?d.$slideTrack.children().remove():d.$slideTrack.children(this.options.slide).eq(a).remove(),d.$slides=d.$slideTrack.children(this.options.slide),d.$slideTrack.children(this.options.slide).detach(),d.$slideTrack.append(d.$slides),d.$slidesCache=d.$slides,void d.reinit())},b.prototype.setCSS=function(a){var d,e,b=this,c={};b.options.rtl===!0&&(a=-a),d="left"==b.positionProp?Math.ceil(a)+"px":"0px",e="top"==b.positionProp?Math.ceil(a)+"px":"0px",c[b.positionProp]=a,b.transformsEnabled===!1?b.$slideTrack.css(c):(c={},b.cssTransitions===!1?(c[b.animType]="translate("+d+", "+e+")",b.$slideTrack.css(c)):(c[b.animType]="translate3d("+d+", "+e+", 0px)",b.$slideTrack.css(c)))},b.prototype.setDimensions=function(){var a=this;a.options.vertical===!1?a.options.centerMode===!0&&a.$list.css({padding:"0px "+a.options.centerPadding}):(a.$list.height(a.$slides.first().outerHeight(!0)*a.options.slidesToShow),a.options.centerMode===!0&&a.$list.css({padding:a.options.centerPadding+" 0px"})),a.listWidth=a.$list.width(),a.listHeight=a.$list.height(),a.options.vertical===!1&&a.options.variableWidth===!1?(a.slideWidth=Math.ceil(a.listWidth/a.options.slidesToShow),a.$slideTrack.width(Math.ceil(a.slideWidth*a.$slideTrack.children(".slick-slide").length))):a.options.variableWidth===!0?a.$slideTrack.width(5e3*a.slideCount):(a.slideWidth=Math.ceil(a.listWidth),a.$slideTrack.height(Math.ceil(a.$slides.first().outerHeight(!0)*a.$slideTrack.children(".slick-slide").length)));var b=a.$slides.first().outerWidth(!0)-a.$slides.first().width();a.options.variableWidth===!1&&a.$slideTrack.children(".slick-slide").width(a.slideWidth-b)},b.prototype.setFade=function(){var c,b=this;b.$slides.each(function(d,e){c=b.slideWidth*d*-1,b.options.rtl===!0?a(e).css({position:"relative",right:c,top:0,zIndex:b.options.zIndex-2,opacity:0}):a(e).css({position:"relative",left:c,top:0,zIndex:b.options.zIndex-2,opacity:0})}),b.$slides.eq(b.currentSlide).css({zIndex:b.options.zIndex-1,opacity:1})},b.prototype.setHeight=function(){var a=this;if(1===a.options.slidesToShow&&a.options.adaptiveHeight===!0&&a.options.vertical===!1){var b=a.$slides.eq(a.currentSlide).outerHeight(!0);a.$list.css("height",b)}},b.prototype.setOption=b.prototype.slickSetOption=function(){var c,d,e,f,h,b=this,g=!1;if("object"===a.type(arguments[0])?(e=arguments[0],g=arguments[1],h="multiple"):"string"===a.type(arguments[0])&&(e=arguments[0],f=arguments[1],g=arguments[2],"responsive"===arguments[0]&&"array"===a.type(arguments[1])?h="responsive":"undefined"!=typeof arguments[1]&&(h="single")),"single"===h)b.options[e]=f;else if("multiple"===h)a.each(e,function(a,c){b.options[a]=c});else if("responsive"===h)for(d in f)if("array"!==a.type(b.options.responsive))b.options.responsive=[f[d]];else{for(c=b.options.responsive.length-1;c>=0;)b.options.responsive[c].breakpoint===f[d].breakpoint&&b.options.responsive.splice(c,1),c--;b.options.responsive.push(f[d])}g&&(b.unload(),b.reinit())},b.prototype.setPosition=function(){var a=this;a.setDimensions(),a.setHeight(),a.options.fade===!1?a.setCSS(a.getLeft(a.currentSlide)):a.setFade(),a.$slider.trigger("setPosition",[a])},b.prototype.setProps=function(){var a=this,b=document.body.style;a.positionProp=a.options.vertical===!0?"top":"left","top"===a.positionProp?a.$slider.addClass("slick-vertical"):a.$slider.removeClass("slick-vertical"),(void 0!==b.WebkitTransition||void 0!==b.MozTransition||void 0!==b.msTransition)&&a.options.useCSS===!0&&(a.cssTransitions=!0),a.options.fade&&("number"==typeof a.options.zIndex?a.options.zIndex<3&&(a.options.zIndex=3):a.options.zIndex=a.defaults.zIndex),void 0!==b.OTransform&&(a.animType="OTransform",a.transformType="-o-transform",a.transitionType="OTransition",void 0===b.perspectiveProperty&&void 0===b.webkitPerspective&&(a.animType=!1)),void 0!==b.MozTransform&&(a.animType="MozTransform",a.transformType="-moz-transform",a.transitionType="MozTransition",void 0===b.perspectiveProperty&&void 0===b.MozPerspective&&(a.animType=!1)),void 0!==b.webkitTransform&&(a.animType="webkitTransform",a.transformType="-webkit-transform",a.transitionType="webkitTransition",void 0===b.perspectiveProperty&&void 0===b.webkitPerspective&&(a.animType=!1)),void 0!==b.msTransform&&(a.animType="msTransform",a.transformType="-ms-transform",a.transitionType="msTransition",void 0===b.msTransform&&(a.animType=!1)),void 0!==b.transform&&a.animType!==!1&&(a.animType="transform",a.transformType="transform",a.transitionType="transition"),a.transformsEnabled=a.options.useTransform&&null!==a.animType&&a.animType!==!1},b.prototype.setSlideClasses=function(a){var c,d,e,f,b=this;d=b.$slider.find(".slick-slide").removeClass("slick-active slick-center slick-current").attr("aria-hidden","true"),b.$slides.eq(a).addClass("slick-current"),b.options.centerMode===!0?(c=Math.floor(b.options.slidesToShow/2),b.options.infinite===!0&&(a>=c&&a<=b.slideCount-1-c?b.$slides.slice(a-c,a+c+1).addClass("slick-active").attr("aria-hidden","false"):(e=b.options.slidesToShow+a,
d.slice(e-c+1,e+c+2).addClass("slick-active").attr("aria-hidden","false")),0===a?d.eq(d.length-1-b.options.slidesToShow).addClass("slick-center"):a===b.slideCount-1&&d.eq(b.options.slidesToShow).addClass("slick-center")),b.$slides.eq(a).addClass("slick-center")):a>=0&&a<=b.slideCount-b.options.slidesToShow?b.$slides.slice(a,a+b.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false"):d.length<=b.options.slidesToShow?d.addClass("slick-active").attr("aria-hidden","false"):(f=b.slideCount%b.options.slidesToShow,e=b.options.infinite===!0?b.options.slidesToShow+a:a,b.options.slidesToShow==b.options.slidesToScroll&&b.slideCount-a<b.options.slidesToShow?d.slice(e-(b.options.slidesToShow-f),e+f).addClass("slick-active").attr("aria-hidden","false"):d.slice(e,e+b.options.slidesToShow).addClass("slick-active").attr("aria-hidden","false")),"ondemand"===b.options.lazyLoad&&b.lazyLoad()},b.prototype.setupInfinite=function(){var c,d,e,b=this;if(b.options.fade===!0&&(b.options.centerMode=!1),b.options.infinite===!0&&b.options.fade===!1&&(d=null,b.slideCount>b.options.slidesToShow)){for(e=b.options.centerMode===!0?b.options.slidesToShow+1:b.options.slidesToShow,c=b.slideCount;c>b.slideCount-e;c-=1)d=c-1,a(b.$slides[d]).clone(!0).attr("id","").attr("data-slick-index",d-b.slideCount).prependTo(b.$slideTrack).addClass("slick-cloned");for(c=0;e>c;c+=1)d=c,a(b.$slides[d]).clone(!0).attr("id","").attr("data-slick-index",d+b.slideCount).appendTo(b.$slideTrack).addClass("slick-cloned");b.$slideTrack.find(".slick-cloned").find("[id]").each(function(){a(this).attr("id","")})}},b.prototype.interrupt=function(a){var b=this;a||b.autoPlay(),b.interrupted=a},b.prototype.selectHandler=function(b){var c=this,d=a(b.target).is(".slick-slide")?a(b.target):a(b.target).parents(".slick-slide"),e=parseInt(d.attr("data-slick-index"));return e||(e=0),c.slideCount<=c.options.slidesToShow?(c.setSlideClasses(e),void c.asNavFor(e)):void c.slideHandler(e)},b.prototype.slideHandler=function(a,b,c){var d,e,f,g,j,h=null,i=this;return b=b||!1,i.animating===!0&&i.options.waitForAnimate===!0||i.options.fade===!0&&i.currentSlide===a||i.slideCount<=i.options.slidesToShow?void 0:(b===!1&&i.asNavFor(a),d=a,h=i.getLeft(d),g=i.getLeft(i.currentSlide),i.currentLeft=null===i.swipeLeft?g:i.swipeLeft,i.options.infinite===!1&&i.options.centerMode===!1&&(0>a||a>i.getDotCount()*i.options.slidesToScroll)?void(i.options.fade===!1&&(d=i.currentSlide,c!==!0?i.animateSlide(g,function(){i.postSlide(d)}):i.postSlide(d))):i.options.infinite===!1&&i.options.centerMode===!0&&(0>a||a>i.slideCount-i.options.slidesToScroll)?void(i.options.fade===!1&&(d=i.currentSlide,c!==!0?i.animateSlide(g,function(){i.postSlide(d)}):i.postSlide(d))):(i.options.autoplay&&clearInterval(i.autoPlayTimer),e=0>d?i.slideCount%i.options.slidesToScroll!==0?i.slideCount-i.slideCount%i.options.slidesToScroll:i.slideCount+d:d>=i.slideCount?i.slideCount%i.options.slidesToScroll!==0?0:d-i.slideCount:d,i.animating=!0,i.$slider.trigger("beforeChange",[i,i.currentSlide,e]),f=i.currentSlide,i.currentSlide=e,i.setSlideClasses(i.currentSlide),i.options.asNavFor&&(j=i.getNavTarget(),j=j.slick("getSlick"),j.slideCount<=j.options.slidesToShow&&j.setSlideClasses(i.currentSlide)),i.updateDots(),i.updateArrows(),i.options.fade===!0?(c!==!0?(i.fadeSlideOut(f),i.fadeSlide(e,function(){i.postSlide(e)})):i.postSlide(e),void i.animateHeight()):void(c!==!0?i.animateSlide(h,function(){i.postSlide(e)}):i.postSlide(e))))},b.prototype.startLoad=function(){var a=this;a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&(a.$prevArrow.hide(),a.$nextArrow.hide()),a.options.dots===!0&&a.slideCount>a.options.slidesToShow&&a.$dots.hide(),a.$slider.addClass("slick-loading")},b.prototype.swipeDirection=function(){var a,b,c,d,e=this;return a=e.touchObject.startX-e.touchObject.curX,b=e.touchObject.startY-e.touchObject.curY,c=Math.atan2(b,a),d=Math.round(180*c/Math.PI),0>d&&(d=360-Math.abs(d)),45>=d&&d>=0?e.options.rtl===!1?"left":"right":360>=d&&d>=315?e.options.rtl===!1?"left":"right":d>=135&&225>=d?e.options.rtl===!1?"right":"left":e.options.verticalSwiping===!0?d>=35&&135>=d?"down":"up":"vertical"},b.prototype.swipeEnd=function(a){var c,d,b=this;if(b.dragging=!1,b.interrupted=!1,b.shouldClick=b.touchObject.swipeLength>10?!1:!0,void 0===b.touchObject.curX)return!1;if(b.touchObject.edgeHit===!0&&b.$slider.trigger("edge",[b,b.swipeDirection()]),b.touchObject.swipeLength>=b.touchObject.minSwipe){switch(d=b.swipeDirection()){case"left":case"down":c=b.options.swipeToSlide?b.checkNavigable(b.currentSlide+b.getSlideCount()):b.currentSlide+b.getSlideCount(),b.currentDirection=0;break;case"right":case"up":c=b.options.swipeToSlide?b.checkNavigable(b.currentSlide-b.getSlideCount()):b.currentSlide-b.getSlideCount(),b.currentDirection=1}"vertical"!=d&&(b.slideHandler(c),b.touchObject={},b.$slider.trigger("swipe",[b,d]))}else b.touchObject.startX!==b.touchObject.curX&&(b.slideHandler(b.currentSlide),b.touchObject={})},b.prototype.swipeHandler=function(a){var b=this;if(!(b.options.swipe===!1||"ontouchend"in document&&b.options.swipe===!1||b.options.draggable===!1&&-1!==a.type.indexOf("mouse")))switch(b.touchObject.fingerCount=a.originalEvent&&void 0!==a.originalEvent.touches?a.originalEvent.touches.length:1,b.touchObject.minSwipe=b.listWidth/b.options.touchThreshold,b.options.verticalSwiping===!0&&(b.touchObject.minSwipe=b.listHeight/b.options.touchThreshold),a.data.action){case"start":b.swipeStart(a);break;case"move":b.swipeMove(a);break;case"end":b.swipeEnd(a)}},b.prototype.swipeMove=function(a){var d,e,f,g,h,b=this;return h=void 0!==a.originalEvent?a.originalEvent.touches:null,!b.dragging||h&&1!==h.length?!1:(d=b.getLeft(b.currentSlide),b.touchObject.curX=void 0!==h?h[0].pageX:a.clientX,b.touchObject.curY=void 0!==h?h[0].pageY:a.clientY,b.touchObject.swipeLength=Math.round(Math.sqrt(Math.pow(b.touchObject.curX-b.touchObject.startX,2))),b.options.verticalSwiping===!0&&(b.touchObject.swipeLength=Math.round(Math.sqrt(Math.pow(b.touchObject.curY-b.touchObject.startY,2)))),e=b.swipeDirection(),"vertical"!==e?(void 0!==a.originalEvent&&b.touchObject.swipeLength>4&&a.preventDefault(),g=(b.options.rtl===!1?1:-1)*(b.touchObject.curX>b.touchObject.startX?1:-1),b.options.verticalSwiping===!0&&(g=b.touchObject.curY>b.touchObject.startY?1:-1),f=b.touchObject.swipeLength,b.touchObject.edgeHit=!1,b.options.infinite===!1&&(0===b.currentSlide&&"right"===e||b.currentSlide>=b.getDotCount()&&"left"===e)&&(f=b.touchObject.swipeLength*b.options.edgeFriction,b.touchObject.edgeHit=!0),b.options.vertical===!1?b.swipeLeft=d+f*g:b.swipeLeft=d+f*(b.$list.height()/b.listWidth)*g,b.options.verticalSwiping===!0&&(b.swipeLeft=d+f*g),b.options.fade===!0||b.options.touchMove===!1?!1:b.animating===!0?(b.swipeLeft=null,!1):void b.setCSS(b.swipeLeft)):void 0)},b.prototype.swipeStart=function(a){var c,b=this;return b.interrupted=!0,1!==b.touchObject.fingerCount||b.slideCount<=b.options.slidesToShow?(b.touchObject={},!1):(void 0!==a.originalEvent&&void 0!==a.originalEvent.touches&&(c=a.originalEvent.touches[0]),b.touchObject.startX=b.touchObject.curX=void 0!==c?c.pageX:a.clientX,b.touchObject.startY=b.touchObject.curY=void 0!==c?c.pageY:a.clientY,void(b.dragging=!0))},b.prototype.unfilterSlides=b.prototype.slickUnfilter=function(){var a=this;null!==a.$slidesCache&&(a.unload(),a.$slideTrack.children(this.options.slide).detach(),a.$slidesCache.appendTo(a.$slideTrack),a.reinit())},b.prototype.unload=function(){var b=this;a(".slick-cloned",b.$slider).remove(),b.$dots&&b.$dots.remove(),b.$prevArrow&&b.htmlExpr.test(b.options.prevArrow)&&b.$prevArrow.remove(),b.$nextArrow&&b.htmlExpr.test(b.options.nextArrow)&&b.$nextArrow.remove(),b.$slides.removeClass("slick-slide slick-active slick-visible slick-current").attr("aria-hidden","true").css("width","")},b.prototype.unslick=function(a){var b=this;b.$slider.trigger("unslick",[b,a]),b.destroy()},b.prototype.updateArrows=function(){var b,a=this;b=Math.floor(a.options.slidesToShow/2),a.options.arrows===!0&&a.slideCount>a.options.slidesToShow&&!a.options.infinite&&(a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false"),a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false"),0===a.currentSlide?(a.$prevArrow.addClass("slick-disabled").attr("aria-disabled","true"),a.$nextArrow.removeClass("slick-disabled").attr("aria-disabled","false")):a.currentSlide>=a.slideCount-a.options.slidesToShow&&a.options.centerMode===!1?(a.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")):a.currentSlide>=a.slideCount-1&&a.options.centerMode===!0&&(a.$nextArrow.addClass("slick-disabled").attr("aria-disabled","true"),a.$prevArrow.removeClass("slick-disabled").attr("aria-disabled","false")))},b.prototype.updateDots=function(){var a=this;null!==a.$dots&&(a.$dots.find("li").removeClass("slick-active").attr("aria-hidden","true"),a.$dots.find("li").eq(Math.floor(a.currentSlide/a.options.slidesToScroll)).addClass("slick-active").attr("aria-hidden","false"))},b.prototype.visibility=function(){var a=this;a.options.autoplay&&(document[a.hidden]?a.interrupted=!0:a.interrupted=!1)},a.fn.slick=function(){var f,g,a=this,c=arguments[0],d=Array.prototype.slice.call(arguments,1),e=a.length;for(f=0;e>f;f++)if("object"==typeof c||"undefined"==typeof c?a[f].slick=new b(a[f],c):g=a[f].slick[c].apply(a[f].slick,d),"undefined"!=typeof g)return g;return a}});
/**
 * Init Hero sliders.
 *
 * This just takes all the sliders places on the page
 * and initiates Slick JS to animate and slide them.
 *
 * @param  {Object} $ jQuery
 */
( function( $ ) {
	// Anything with data attached to it, slick it!
	$( '.hero .sliders' ).each( function( i, v ) {
		var speed = $( this ).attr( 'data-slider-speed' );

		$( this ).slick( {
			slidesToShow:    1,
			slidesToScroll:  1,
			autoplay:        true,
			autoplaySpeed:   speed * 1000,
			dots:				true,
			prevArrow: '',
			nextArrow: '',
		} );
	} );
} )( jQuery );

/**
 * File window-ready.js
 *
 * Add a "ready" class to <body> when window is ready.
 */
window.Window_Ready = {};
( function( window, $, app ) {

	// Constructor.
	app.init = function() {
		app.cache();
		app.bindEvents();
	};

	// Cache document elements.
	app.cache = function() {
		app.$c = {
			window: $( window ),
			body: $( document.body ),
		};
	};

	// Combine all events.
	app.bindEvents = function() {
		app.$c.window.load( app.addBodyClass );
	};

	// Add a class to <body>.
	app.addBodyClass = function() {
		app.$c.body.addClass( 'ready' );
	};

	// Engage!
	$( app.init );

})( window, jQuery, window.Window_Ready );
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImNtYjItcmFkaW8taW1hZ2UtZmllbGQuanMiLCJqcXVlcnkuZm9ybS5qcyIsImpxdWVyeS5sYXp5bG9hZC1hbnkubWluLmpzIiwianF1ZXJ5Lm1hZ25pZmljcG9wdXAubWluLmpzIiwianMtZW5hYmxlZC5qcyIsIm1vZGFsLmpzIiwic2NyaXB0cy5qcyIsInNlYXJjaC5qcyIsInNraXAtbGluay1mb2N1cy1maXguanMiLCJzbGljay5taW4uanMiLCJ3ZHMtaGVyby13aWRnZXQuanMiLCJ3aW5kb3ctcmVhZHkuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUM3dkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2RBO0FBQ0E7QUFDQTtBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ0xBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUNwR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQzVIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUMzREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FDaENBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQ3hCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EiLCJmaWxlIjoicHJvamVjdC5qcyIsInNvdXJjZXNDb250ZW50IjpbIiggZnVuY3Rpb24oICQgKSB7XHJcbiAgICAgICQoZG9jdW1lbnQpLm9uKFwiY2xpY2tcIiwgXCIuY21iLXJhZGlvLWltYWdlXCIsIGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICQodGhpcykuY2xvc2VzdChcIi5jbWItdHlwZS1yYWRpby1pbWFnZVwiKS5maW5kKFwiLmNtYi1yYWRpby1pbWFnZVwiKS5yZW1vdmVDbGFzcyhcImNtYi1yYWRpby1pbWFnZS1zZWxlY3RlZFwiKTtcclxuICAgICAgICAkKHRoaXMpLnRvZ2dsZUNsYXNzKFwiY21iLXJhZGlvLWltYWdlLXNlbGVjdGVkXCIpO1xyXG4gICAgICB9KTtcclxufSApKCBqUXVlcnkgKTtcclxuIiwiLyohXG4gKiBqUXVlcnkgRm9ybSBQbHVnaW5cbiAqIHZlcnNpb246IDMuNTEuMC0yMDE0LjA2LjIwXG4gKiBSZXF1aXJlcyBqUXVlcnkgdjEuNSBvciBsYXRlclxuICogQ29weXJpZ2h0IChjKSAyMDE0IE0uIEFsc3VwXG4gKiBFeGFtcGxlcyBhbmQgZG9jdW1lbnRhdGlvbiBhdDogaHR0cDovL21hbHN1cC5jb20vanF1ZXJ5L2Zvcm0vXG4gKiBQcm9qZWN0IHJlcG9zaXRvcnk6IGh0dHBzOi8vZ2l0aHViLmNvbS9tYWxzdXAvZm9ybVxuICogRHVhbCBsaWNlbnNlZCB1bmRlciB0aGUgTUlUIGFuZCBHUEwgbGljZW5zZXMuXG4gKiBodHRwczovL2dpdGh1Yi5jb20vbWFsc3VwL2Zvcm0jY29weXJpZ2h0LWFuZC1saWNlbnNlXG4gKi9cbi8qZ2xvYmFsIEFjdGl2ZVhPYmplY3QgKi9cblxuLy8gQU1EIHN1cHBvcnRcbihmdW5jdGlvbiAoZmFjdG9yeSkge1xuICAgIFwidXNlIHN0cmljdFwiO1xuICAgIGlmICh0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIGRlZmluZS5hbWQpIHtcbiAgICAgICAgLy8gdXNpbmcgQU1EOyByZWdpc3RlciBhcyBhbm9uIG1vZHVsZVxuICAgICAgICBkZWZpbmUoWydqcXVlcnknXSwgZmFjdG9yeSk7XG4gICAgfSBlbHNlIHtcbiAgICAgICAgLy8gbm8gQU1EOyBpbnZva2UgZGlyZWN0bHlcbiAgICAgICAgZmFjdG9yeSggKHR5cGVvZihqUXVlcnkpICE9ICd1bmRlZmluZWQnKSA/IGpRdWVyeSA6IHdpbmRvdy5aZXB0byApO1xuICAgIH1cbn1cblxuKGZ1bmN0aW9uKCQpIHtcblwidXNlIHN0cmljdFwiO1xuXG4vKlxuICAgIFVzYWdlIE5vdGU6XG4gICAgLS0tLS0tLS0tLS1cbiAgICBEbyBub3QgdXNlIGJvdGggYWpheFN1Ym1pdCBhbmQgYWpheEZvcm0gb24gdGhlIHNhbWUgZm9ybS4gIFRoZXNlXG4gICAgZnVuY3Rpb25zIGFyZSBtdXR1YWxseSBleGNsdXNpdmUuICBVc2UgYWpheFN1Ym1pdCBpZiB5b3Ugd2FudFxuICAgIHRvIGJpbmQgeW91ciBvd24gc3VibWl0IGhhbmRsZXIgdG8gdGhlIGZvcm0uICBGb3IgZXhhbXBsZSxcblxuICAgICQoZG9jdW1lbnQpLnJlYWR5KGZ1bmN0aW9uKCkge1xuICAgICAgICAkKCcjbXlGb3JtJykub24oJ3N1Ym1pdCcsIGZ1bmN0aW9uKGUpIHtcbiAgICAgICAgICAgIGUucHJldmVudERlZmF1bHQoKTsgLy8gPC0tIGltcG9ydGFudFxuICAgICAgICAgICAgJCh0aGlzKS5hamF4U3VibWl0KHtcbiAgICAgICAgICAgICAgICB0YXJnZXQ6ICcjb3V0cHV0J1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgVXNlIGFqYXhGb3JtIHdoZW4geW91IHdhbnQgdGhlIHBsdWdpbiB0byBtYW5hZ2UgYWxsIHRoZSBldmVudCBiaW5kaW5nXG4gICAgZm9yIHlvdS4gIEZvciBleGFtcGxlLFxuXG4gICAgJChkb2N1bWVudCkucmVhZHkoZnVuY3Rpb24oKSB7XG4gICAgICAgICQoJyNteUZvcm0nKS5hamF4Rm9ybSh7XG4gICAgICAgICAgICB0YXJnZXQ6ICcjb3V0cHV0J1xuICAgICAgICB9KTtcbiAgICB9KTtcblxuICAgIFlvdSBjYW4gYWxzbyB1c2UgYWpheEZvcm0gd2l0aCBkZWxlZ2F0aW9uIChyZXF1aXJlcyBqUXVlcnkgdjEuNyspLCBzbyB0aGVcbiAgICBmb3JtIGRvZXMgbm90IGhhdmUgdG8gZXhpc3Qgd2hlbiB5b3UgaW52b2tlIGFqYXhGb3JtOlxuXG4gICAgJCgnI215Rm9ybScpLmFqYXhGb3JtKHtcbiAgICAgICAgZGVsZWdhdGlvbjogdHJ1ZSxcbiAgICAgICAgdGFyZ2V0OiAnI291dHB1dCdcbiAgICB9KTtcblxuICAgIFdoZW4gdXNpbmcgYWpheEZvcm0sIHRoZSBhamF4U3VibWl0IGZ1bmN0aW9uIHdpbGwgYmUgaW52b2tlZCBmb3IgeW91XG4gICAgYXQgdGhlIGFwcHJvcHJpYXRlIHRpbWUuXG4qL1xuXG4vKipcbiAqIEZlYXR1cmUgZGV0ZWN0aW9uXG4gKi9cbnZhciBmZWF0dXJlID0ge307XG5mZWF0dXJlLmZpbGVhcGkgPSAkKFwiPGlucHV0IHR5cGU9J2ZpbGUnLz5cIikuZ2V0KDApLmZpbGVzICE9PSB1bmRlZmluZWQ7XG5mZWF0dXJlLmZvcm1kYXRhID0gd2luZG93LkZvcm1EYXRhICE9PSB1bmRlZmluZWQ7XG5cbnZhciBoYXNQcm9wID0gISEkLmZuLnByb3A7XG5cbi8vIGF0dHIyIHVzZXMgcHJvcCB3aGVuIGl0IGNhbiBidXQgY2hlY2tzIHRoZSByZXR1cm4gdHlwZSBmb3Jcbi8vIGFuIGV4cGVjdGVkIHN0cmluZy4gIHRoaXMgYWNjb3VudHMgZm9yIHRoZSBjYXNlIHdoZXJlIGEgZm9ybSBcbi8vIGNvbnRhaW5zIGlucHV0cyB3aXRoIG5hbWVzIGxpa2UgXCJhY3Rpb25cIiBvciBcIm1ldGhvZFwiOyBpbiB0aG9zZVxuLy8gY2FzZXMgXCJwcm9wXCIgcmV0dXJucyB0aGUgZWxlbWVudFxuJC5mbi5hdHRyMiA9IGZ1bmN0aW9uKCkge1xuICAgIGlmICggISBoYXNQcm9wICkge1xuICAgICAgICByZXR1cm4gdGhpcy5hdHRyLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgfVxuICAgIHZhciB2YWwgPSB0aGlzLnByb3AuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICBpZiAoICggdmFsICYmIHZhbC5qcXVlcnkgKSB8fCB0eXBlb2YgdmFsID09PSAnc3RyaW5nJyApIHtcbiAgICAgICAgcmV0dXJuIHZhbDtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuYXR0ci5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufTtcblxuLyoqXG4gKiBhamF4U3VibWl0KCkgcHJvdmlkZXMgYSBtZWNoYW5pc20gZm9yIGltbWVkaWF0ZWx5IHN1Ym1pdHRpbmdcbiAqIGFuIEhUTUwgZm9ybSB1c2luZyBBSkFYLlxuICovXG4kLmZuLmFqYXhTdWJtaXQgPSBmdW5jdGlvbihvcHRpb25zKSB7XG4gICAgLypqc2hpbnQgc2NyaXB0dXJsOnRydWUgKi9cblxuICAgIC8vIGZhc3QgZmFpbCBpZiBub3RoaW5nIHNlbGVjdGVkIChodHRwOi8vZGV2LmpxdWVyeS5jb20vdGlja2V0LzI3NTIpXG4gICAgaWYgKCF0aGlzLmxlbmd0aCkge1xuICAgICAgICBsb2coJ2FqYXhTdWJtaXQ6IHNraXBwaW5nIHN1Ym1pdCBwcm9jZXNzIC0gbm8gZWxlbWVudCBzZWxlY3RlZCcpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB2YXIgbWV0aG9kLCBhY3Rpb24sIHVybCwgJGZvcm0gPSB0aGlzO1xuXG4gICAgaWYgKHR5cGVvZiBvcHRpb25zID09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgb3B0aW9ucyA9IHsgc3VjY2Vzczogb3B0aW9ucyB9O1xuICAgIH1cbiAgICBlbHNlIGlmICggb3B0aW9ucyA9PT0gdW5kZWZpbmVkICkge1xuICAgICAgICBvcHRpb25zID0ge307XG4gICAgfVxuXG4gICAgbWV0aG9kID0gb3B0aW9ucy50eXBlIHx8IHRoaXMuYXR0cjIoJ21ldGhvZCcpO1xuICAgIGFjdGlvbiA9IG9wdGlvbnMudXJsICB8fCB0aGlzLmF0dHIyKCdhY3Rpb24nKTtcblxuICAgIHVybCA9ICh0eXBlb2YgYWN0aW9uID09PSAnc3RyaW5nJykgPyAkLnRyaW0oYWN0aW9uKSA6ICcnO1xuICAgIHVybCA9IHVybCB8fCB3aW5kb3cubG9jYXRpb24uaHJlZiB8fCAnJztcbiAgICBpZiAodXJsKSB7XG4gICAgICAgIC8vIGNsZWFuIHVybCAoZG9uJ3QgaW5jbHVkZSBoYXNoIHZhdWUpXG4gICAgICAgIHVybCA9ICh1cmwubWF0Y2goL14oW14jXSspLyl8fFtdKVsxXTtcbiAgICB9XG5cbiAgICBvcHRpb25zID0gJC5leHRlbmQodHJ1ZSwge1xuICAgICAgICB1cmw6ICB1cmwsXG4gICAgICAgIHN1Y2Nlc3M6ICQuYWpheFNldHRpbmdzLnN1Y2Nlc3MsXG4gICAgICAgIHR5cGU6IG1ldGhvZCB8fCAkLmFqYXhTZXR0aW5ncy50eXBlLFxuICAgICAgICBpZnJhbWVTcmM6IC9eaHR0cHMvaS50ZXN0KHdpbmRvdy5sb2NhdGlvbi5ocmVmIHx8ICcnKSA/ICdqYXZhc2NyaXB0OmZhbHNlJyA6ICdhYm91dDpibGFuaydcbiAgICB9LCBvcHRpb25zKTtcblxuICAgIC8vIGhvb2sgZm9yIG1hbmlwdWxhdGluZyB0aGUgZm9ybSBkYXRhIGJlZm9yZSBpdCBpcyBleHRyYWN0ZWQ7XG4gICAgLy8gY29udmVuaWVudCBmb3IgdXNlIHdpdGggcmljaCBlZGl0b3JzIGxpa2UgdGlueU1DRSBvciBGQ0tFZGl0b3JcbiAgICB2YXIgdmV0byA9IHt9O1xuICAgIHRoaXMudHJpZ2dlcignZm9ybS1wcmUtc2VyaWFsaXplJywgW3RoaXMsIG9wdGlvbnMsIHZldG9dKTtcbiAgICBpZiAodmV0by52ZXRvKSB7XG4gICAgICAgIGxvZygnYWpheFN1Ym1pdDogc3VibWl0IHZldG9lZCB2aWEgZm9ybS1wcmUtc2VyaWFsaXplIHRyaWdnZXInKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgLy8gcHJvdmlkZSBvcHBvcnR1bml0eSB0byBhbHRlciBmb3JtIGRhdGEgYmVmb3JlIGl0IGlzIHNlcmlhbGl6ZWRcbiAgICBpZiAob3B0aW9ucy5iZWZvcmVTZXJpYWxpemUgJiYgb3B0aW9ucy5iZWZvcmVTZXJpYWxpemUodGhpcywgb3B0aW9ucykgPT09IGZhbHNlKSB7XG4gICAgICAgIGxvZygnYWpheFN1Ym1pdDogc3VibWl0IGFib3J0ZWQgdmlhIGJlZm9yZVNlcmlhbGl6ZSBjYWxsYmFjaycpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB2YXIgdHJhZGl0aW9uYWwgPSBvcHRpb25zLnRyYWRpdGlvbmFsO1xuICAgIGlmICggdHJhZGl0aW9uYWwgPT09IHVuZGVmaW5lZCApIHtcbiAgICAgICAgdHJhZGl0aW9uYWwgPSAkLmFqYXhTZXR0aW5ncy50cmFkaXRpb25hbDtcbiAgICB9XG5cbiAgICB2YXIgZWxlbWVudHMgPSBbXTtcbiAgICB2YXIgcXgsIGEgPSB0aGlzLmZvcm1Ub0FycmF5KG9wdGlvbnMuc2VtYW50aWMsIGVsZW1lbnRzKTtcbiAgICBpZiAob3B0aW9ucy5kYXRhKSB7XG4gICAgICAgIG9wdGlvbnMuZXh0cmFEYXRhID0gb3B0aW9ucy5kYXRhO1xuICAgICAgICBxeCA9ICQucGFyYW0ob3B0aW9ucy5kYXRhLCB0cmFkaXRpb25hbCk7XG4gICAgfVxuXG4gICAgLy8gZ2l2ZSBwcmUtc3VibWl0IGNhbGxiYWNrIGFuIG9wcG9ydHVuaXR5IHRvIGFib3J0IHRoZSBzdWJtaXRcbiAgICBpZiAob3B0aW9ucy5iZWZvcmVTdWJtaXQgJiYgb3B0aW9ucy5iZWZvcmVTdWJtaXQoYSwgdGhpcywgb3B0aW9ucykgPT09IGZhbHNlKSB7XG4gICAgICAgIGxvZygnYWpheFN1Ym1pdDogc3VibWl0IGFib3J0ZWQgdmlhIGJlZm9yZVN1Ym1pdCBjYWxsYmFjaycpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICAvLyBmaXJlIHZldG9hYmxlICd2YWxpZGF0ZScgZXZlbnRcbiAgICB0aGlzLnRyaWdnZXIoJ2Zvcm0tc3VibWl0LXZhbGlkYXRlJywgW2EsIHRoaXMsIG9wdGlvbnMsIHZldG9dKTtcbiAgICBpZiAodmV0by52ZXRvKSB7XG4gICAgICAgIGxvZygnYWpheFN1Ym1pdDogc3VibWl0IHZldG9lZCB2aWEgZm9ybS1zdWJtaXQtdmFsaWRhdGUgdHJpZ2dlcicpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG5cbiAgICB2YXIgcSA9ICQucGFyYW0oYSwgdHJhZGl0aW9uYWwpO1xuICAgIGlmIChxeCkge1xuICAgICAgICBxID0gKCBxID8gKHEgKyAnJicgKyBxeCkgOiBxeCApO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy50eXBlLnRvVXBwZXJDYXNlKCkgPT0gJ0dFVCcpIHtcbiAgICAgICAgb3B0aW9ucy51cmwgKz0gKG9wdGlvbnMudXJsLmluZGV4T2YoJz8nKSA+PSAwID8gJyYnIDogJz8nKSArIHE7XG4gICAgICAgIG9wdGlvbnMuZGF0YSA9IG51bGw7ICAvLyBkYXRhIGlzIG51bGwgZm9yICdnZXQnXG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBvcHRpb25zLmRhdGEgPSBxOyAvLyBkYXRhIGlzIHRoZSBxdWVyeSBzdHJpbmcgZm9yICdwb3N0J1xuICAgIH1cblxuICAgIHZhciBjYWxsYmFja3MgPSBbXTtcbiAgICBpZiAob3B0aW9ucy5yZXNldEZvcm0pIHtcbiAgICAgICAgY2FsbGJhY2tzLnB1c2goZnVuY3Rpb24oKSB7ICRmb3JtLnJlc2V0Rm9ybSgpOyB9KTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuY2xlYXJGb3JtKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wdXNoKGZ1bmN0aW9uKCkgeyAkZm9ybS5jbGVhckZvcm0ob3B0aW9ucy5pbmNsdWRlSGlkZGVuKTsgfSk7XG4gICAgfVxuXG4gICAgLy8gcGVyZm9ybSBhIGxvYWQgb24gdGhlIHRhcmdldCBvbmx5IGlmIGRhdGFUeXBlIGlzIG5vdCBwcm92aWRlZFxuICAgIGlmICghb3B0aW9ucy5kYXRhVHlwZSAmJiBvcHRpb25zLnRhcmdldCkge1xuICAgICAgICB2YXIgb2xkU3VjY2VzcyA9IG9wdGlvbnMuc3VjY2VzcyB8fCBmdW5jdGlvbigpe307XG4gICAgICAgIGNhbGxiYWNrcy5wdXNoKGZ1bmN0aW9uKGRhdGEpIHtcbiAgICAgICAgICAgIHZhciBmbiA9IG9wdGlvbnMucmVwbGFjZVRhcmdldCA/ICdyZXBsYWNlV2l0aCcgOiAnaHRtbCc7XG4gICAgICAgICAgICAkKG9wdGlvbnMudGFyZ2V0KVtmbl0oZGF0YSkuZWFjaChvbGRTdWNjZXNzLCBhcmd1bWVudHMpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSBpZiAob3B0aW9ucy5zdWNjZXNzKSB7XG4gICAgICAgIGNhbGxiYWNrcy5wdXNoKG9wdGlvbnMuc3VjY2Vzcyk7XG4gICAgfVxuXG4gICAgb3B0aW9ucy5zdWNjZXNzID0gZnVuY3Rpb24oZGF0YSwgc3RhdHVzLCB4aHIpIHsgLy8galF1ZXJ5IDEuNCsgcGFzc2VzIHhociBhcyAzcmQgYXJnXG4gICAgICAgIHZhciBjb250ZXh0ID0gb3B0aW9ucy5jb250ZXh0IHx8IHRoaXMgOyAgICAvLyBqUXVlcnkgMS40KyBzdXBwb3J0cyBzY29wZSBjb250ZXh0XG4gICAgICAgIGZvciAodmFyIGk9MCwgbWF4PWNhbGxiYWNrcy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgY2FsbGJhY2tzW2ldLmFwcGx5KGNvbnRleHQsIFtkYXRhLCBzdGF0dXMsIHhociB8fCAkZm9ybSwgJGZvcm1dKTtcbiAgICAgICAgfVxuICAgIH07XG5cbiAgICBpZiAob3B0aW9ucy5lcnJvcikge1xuICAgICAgICB2YXIgb2xkRXJyb3IgPSBvcHRpb25zLmVycm9yO1xuICAgICAgICBvcHRpb25zLmVycm9yID0gZnVuY3Rpb24oeGhyLCBzdGF0dXMsIGVycm9yKSB7XG4gICAgICAgICAgICB2YXIgY29udGV4dCA9IG9wdGlvbnMuY29udGV4dCB8fCB0aGlzO1xuICAgICAgICAgICAgb2xkRXJyb3IuYXBwbHkoY29udGV4dCwgW3hociwgc3RhdHVzLCBlcnJvciwgJGZvcm1dKTtcbiAgICAgICAgfTtcbiAgICB9XG5cbiAgICAgaWYgKG9wdGlvbnMuY29tcGxldGUpIHtcbiAgICAgICAgdmFyIG9sZENvbXBsZXRlID0gb3B0aW9ucy5jb21wbGV0ZTtcbiAgICAgICAgb3B0aW9ucy5jb21wbGV0ZSA9IGZ1bmN0aW9uKHhociwgc3RhdHVzKSB7XG4gICAgICAgICAgICB2YXIgY29udGV4dCA9IG9wdGlvbnMuY29udGV4dCB8fCB0aGlzO1xuICAgICAgICAgICAgb2xkQ29tcGxldGUuYXBwbHkoY29udGV4dCwgW3hociwgc3RhdHVzLCAkZm9ybV0pO1xuICAgICAgICB9O1xuICAgIH1cblxuICAgIC8vIGFyZSB0aGVyZSBmaWxlcyB0byB1cGxvYWQ/XG5cbiAgICAvLyBbdmFsdWVdIChpc3N1ZSAjMTEzKSwgYWxzbyBzZWUgY29tbWVudDpcbiAgICAvLyBodHRwczovL2dpdGh1Yi5jb20vbWFsc3VwL2Zvcm0vY29tbWl0LzU4ODMwNmFlZGJhMWRlMDEzODgwMzJkNWY0MmE2MDE1OWVlYTkyMjgjY29tbWl0Y29tbWVudC0yMTgwMjE5XG4gICAgdmFyIGZpbGVJbnB1dHMgPSAkKCdpbnB1dFt0eXBlPWZpbGVdOmVuYWJsZWQnLCB0aGlzKS5maWx0ZXIoZnVuY3Rpb24oKSB7IHJldHVybiAkKHRoaXMpLnZhbCgpICE9PSAnJzsgfSk7XG5cbiAgICB2YXIgaGFzRmlsZUlucHV0cyA9IGZpbGVJbnB1dHMubGVuZ3RoID4gMDtcbiAgICB2YXIgbXAgPSAnbXVsdGlwYXJ0L2Zvcm0tZGF0YSc7XG4gICAgdmFyIG11bHRpcGFydCA9ICgkZm9ybS5hdHRyKCdlbmN0eXBlJykgPT0gbXAgfHwgJGZvcm0uYXR0cignZW5jb2RpbmcnKSA9PSBtcCk7XG5cbiAgICB2YXIgZmlsZUFQSSA9IGZlYXR1cmUuZmlsZWFwaSAmJiBmZWF0dXJlLmZvcm1kYXRhO1xuICAgIGxvZyhcImZpbGVBUEkgOlwiICsgZmlsZUFQSSk7XG4gICAgdmFyIHNob3VsZFVzZUZyYW1lID0gKGhhc0ZpbGVJbnB1dHMgfHwgbXVsdGlwYXJ0KSAmJiAhZmlsZUFQSTtcblxuICAgIHZhciBqcXhocjtcblxuICAgIC8vIG9wdGlvbnMuaWZyYW1lIGFsbG93cyB1c2VyIHRvIGZvcmNlIGlmcmFtZSBtb2RlXG4gICAgLy8gMDYtTk9WLTA5OiBub3cgZGVmYXVsdGluZyB0byBpZnJhbWUgbW9kZSBpZiBmaWxlIGlucHV0IGlzIGRldGVjdGVkXG4gICAgaWYgKG9wdGlvbnMuaWZyYW1lICE9PSBmYWxzZSAmJiAob3B0aW9ucy5pZnJhbWUgfHwgc2hvdWxkVXNlRnJhbWUpKSB7XG4gICAgICAgIC8vIGhhY2sgdG8gZml4IFNhZmFyaSBoYW5nICh0aGFua3MgdG8gVGltIE1vbGVuZGlqayBmb3IgdGhpcylcbiAgICAgICAgLy8gc2VlOiAgaHR0cDovL2dyb3Vwcy5nb29nbGUuY29tL2dyb3VwL2pxdWVyeS1kZXYvYnJvd3NlX3RocmVhZC90aHJlYWQvMzYzOTViN2FiNTEwZGQ1ZFxuICAgICAgICBpZiAob3B0aW9ucy5jbG9zZUtlZXBBbGl2ZSkge1xuICAgICAgICAgICAgJC5nZXQob3B0aW9ucy5jbG9zZUtlZXBBbGl2ZSwgZnVuY3Rpb24oKSB7XG4gICAgICAgICAgICAgICAganF4aHIgPSBmaWxlVXBsb2FkSWZyYW1lKGEpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBqcXhociA9IGZpbGVVcGxvYWRJZnJhbWUoYSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSBpZiAoKGhhc0ZpbGVJbnB1dHMgfHwgbXVsdGlwYXJ0KSAmJiBmaWxlQVBJKSB7XG4gICAgICAgIGpxeGhyID0gZmlsZVVwbG9hZFhocihhKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGpxeGhyID0gJC5hamF4KG9wdGlvbnMpO1xuICAgIH1cblxuICAgICRmb3JtLnJlbW92ZURhdGEoJ2pxeGhyJykuZGF0YSgnanF4aHInLCBqcXhocik7XG5cbiAgICAvLyBjbGVhciBlbGVtZW50IGFycmF5XG4gICAgZm9yICh2YXIgaz0wOyBrIDwgZWxlbWVudHMubGVuZ3RoOyBrKyspIHtcbiAgICAgICAgZWxlbWVudHNba10gPSBudWxsO1xuICAgIH1cblxuICAgIC8vIGZpcmUgJ25vdGlmeScgZXZlbnRcbiAgICB0aGlzLnRyaWdnZXIoJ2Zvcm0tc3VibWl0LW5vdGlmeScsIFt0aGlzLCBvcHRpb25zXSk7XG4gICAgcmV0dXJuIHRoaXM7XG5cbiAgICAvLyB1dGlsaXR5IGZuIGZvciBkZWVwIHNlcmlhbGl6YXRpb25cbiAgICBmdW5jdGlvbiBkZWVwU2VyaWFsaXplKGV4dHJhRGF0YSl7XG4gICAgICAgIHZhciBzZXJpYWxpemVkID0gJC5wYXJhbShleHRyYURhdGEsIG9wdGlvbnMudHJhZGl0aW9uYWwpLnNwbGl0KCcmJyk7XG4gICAgICAgIHZhciBsZW4gPSBzZXJpYWxpemVkLmxlbmd0aDtcbiAgICAgICAgdmFyIHJlc3VsdCA9IFtdO1xuICAgICAgICB2YXIgaSwgcGFydDtcbiAgICAgICAgZm9yIChpPTA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICAgICAgLy8gIzI1MjsgdW5kbyBwYXJhbSBzcGFjZSByZXBsYWNlbWVudFxuICAgICAgICAgICAgc2VyaWFsaXplZFtpXSA9IHNlcmlhbGl6ZWRbaV0ucmVwbGFjZSgvXFwrL2csJyAnKTtcbiAgICAgICAgICAgIHBhcnQgPSBzZXJpYWxpemVkW2ldLnNwbGl0KCc9Jyk7XG4gICAgICAgICAgICAvLyAjMjc4OyB1c2UgYXJyYXkgaW5zdGVhZCBvZiBvYmplY3Qgc3RvcmFnZSwgZmF2b3JpbmcgYXJyYXkgc2VyaWFsaXphdGlvbnNcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKFtkZWNvZGVVUklDb21wb25lbnQocGFydFswXSksIGRlY29kZVVSSUNvbXBvbmVudChwYXJ0WzFdKV0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuXG4gICAgIC8vIFhNTEh0dHBSZXF1ZXN0IExldmVsIDIgZmlsZSB1cGxvYWRzIChiaWcgaGF0IHRpcCB0byBmcmFuY29pczJtZXR6KVxuICAgIGZ1bmN0aW9uIGZpbGVVcGxvYWRYaHIoYSkge1xuICAgICAgICB2YXIgZm9ybWRhdGEgPSBuZXcgRm9ybURhdGEoKTtcblxuICAgICAgICBmb3IgKHZhciBpPTA7IGkgPCBhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICBmb3JtZGF0YS5hcHBlbmQoYVtpXS5uYW1lLCBhW2ldLnZhbHVlKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChvcHRpb25zLmV4dHJhRGF0YSkge1xuICAgICAgICAgICAgdmFyIHNlcmlhbGl6ZWREYXRhID0gZGVlcFNlcmlhbGl6ZShvcHRpb25zLmV4dHJhRGF0YSk7XG4gICAgICAgICAgICBmb3IgKGk9MDsgaSA8IHNlcmlhbGl6ZWREYXRhLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHNlcmlhbGl6ZWREYXRhW2ldKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvcm1kYXRhLmFwcGVuZChzZXJpYWxpemVkRGF0YVtpXVswXSwgc2VyaWFsaXplZERhdGFbaV1bMV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIG9wdGlvbnMuZGF0YSA9IG51bGw7XG5cbiAgICAgICAgdmFyIHMgPSAkLmV4dGVuZCh0cnVlLCB7fSwgJC5hamF4U2V0dGluZ3MsIG9wdGlvbnMsIHtcbiAgICAgICAgICAgIGNvbnRlbnRUeXBlOiBmYWxzZSxcbiAgICAgICAgICAgIHByb2Nlc3NEYXRhOiBmYWxzZSxcbiAgICAgICAgICAgIGNhY2hlOiBmYWxzZSxcbiAgICAgICAgICAgIHR5cGU6IG1ldGhvZCB8fCAnUE9TVCdcbiAgICAgICAgfSk7XG5cbiAgICAgICAgaWYgKG9wdGlvbnMudXBsb2FkUHJvZ3Jlc3MpIHtcbiAgICAgICAgICAgIC8vIHdvcmthcm91bmQgYmVjYXVzZSBqcVhIUiBkb2VzIG5vdCBleHBvc2UgdXBsb2FkIHByb3BlcnR5XG4gICAgICAgICAgICBzLnhociA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAgICAgICAgIHZhciB4aHIgPSAkLmFqYXhTZXR0aW5ncy54aHIoKTtcbiAgICAgICAgICAgICAgICBpZiAoeGhyLnVwbG9hZCkge1xuICAgICAgICAgICAgICAgICAgICB4aHIudXBsb2FkLmFkZEV2ZW50TGlzdGVuZXIoJ3Byb2dyZXNzJywgZnVuY3Rpb24oZXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwZXJjZW50ID0gMDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwb3NpdGlvbiA9IGV2ZW50LmxvYWRlZCB8fCBldmVudC5wb3NpdGlvbjsgLypldmVudC5wb3NpdGlvbiBpcyBkZXByZWNhdGVkKi9cbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0b3RhbCA9IGV2ZW50LnRvdGFsO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGV2ZW50Lmxlbmd0aENvbXB1dGFibGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZXJjZW50ID0gTWF0aC5jZWlsKHBvc2l0aW9uIC8gdG90YWwgKiAxMDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgb3B0aW9ucy51cGxvYWRQcm9ncmVzcyhldmVudCwgcG9zaXRpb24sIHRvdGFsLCBwZXJjZW50KTtcbiAgICAgICAgICAgICAgICAgICAgfSwgZmFsc2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4geGhyO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuXG4gICAgICAgIHMuZGF0YSA9IG51bGw7XG4gICAgICAgIHZhciBiZWZvcmVTZW5kID0gcy5iZWZvcmVTZW5kO1xuICAgICAgICBzLmJlZm9yZVNlbmQgPSBmdW5jdGlvbih4aHIsIG8pIHtcbiAgICAgICAgICAgIC8vU2VuZCBGb3JtRGF0YSgpIHByb3ZpZGVkIGJ5IHVzZXJcbiAgICAgICAgICAgIGlmIChvcHRpb25zLmZvcm1EYXRhKSB7XG4gICAgICAgICAgICAgICAgby5kYXRhID0gb3B0aW9ucy5mb3JtRGF0YTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIG8uZGF0YSA9IGZvcm1kYXRhO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYoYmVmb3JlU2VuZCkge1xuICAgICAgICAgICAgICAgIGJlZm9yZVNlbmQuY2FsbCh0aGlzLCB4aHIsIG8pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICByZXR1cm4gJC5hamF4KHMpO1xuICAgIH1cblxuICAgIC8vIHByaXZhdGUgZnVuY3Rpb24gZm9yIGhhbmRsaW5nIGZpbGUgdXBsb2FkcyAoaGF0IHRpcCB0byBZQUhPTyEpXG4gICAgZnVuY3Rpb24gZmlsZVVwbG9hZElmcmFtZShhKSB7XG4gICAgICAgIHZhciBmb3JtID0gJGZvcm1bMF0sIGVsLCBpLCBzLCBnLCBpZCwgJGlvLCBpbywgeGhyLCBzdWIsIG4sIHRpbWVkT3V0LCB0aW1lb3V0SGFuZGxlO1xuICAgICAgICB2YXIgZGVmZXJyZWQgPSAkLkRlZmVycmVkKCk7XG5cbiAgICAgICAgLy8gIzM0MVxuICAgICAgICBkZWZlcnJlZC5hYm9ydCA9IGZ1bmN0aW9uKHN0YXR1cykge1xuICAgICAgICAgICAgeGhyLmFib3J0KHN0YXR1cyk7XG4gICAgICAgIH07XG5cbiAgICAgICAgaWYgKGEpIHtcbiAgICAgICAgICAgIC8vIGVuc3VyZSB0aGF0IGV2ZXJ5IHNlcmlhbGl6ZWQgaW5wdXQgaXMgc3RpbGwgZW5hYmxlZFxuICAgICAgICAgICAgZm9yIChpPTA7IGkgPCBlbGVtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgICAgIGVsID0gJChlbGVtZW50c1tpXSk7XG4gICAgICAgICAgICAgICAgaWYgKCBoYXNQcm9wICkge1xuICAgICAgICAgICAgICAgICAgICBlbC5wcm9wKCdkaXNhYmxlZCcsIGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGVsLnJlbW92ZUF0dHIoJ2Rpc2FibGVkJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgcyA9ICQuZXh0ZW5kKHRydWUsIHt9LCAkLmFqYXhTZXR0aW5ncywgb3B0aW9ucyk7XG4gICAgICAgIHMuY29udGV4dCA9IHMuY29udGV4dCB8fCBzO1xuICAgICAgICBpZCA9ICdqcUZvcm1JTycgKyAobmV3IERhdGUoKS5nZXRUaW1lKCkpO1xuICAgICAgICBpZiAocy5pZnJhbWVUYXJnZXQpIHtcbiAgICAgICAgICAgICRpbyA9ICQocy5pZnJhbWVUYXJnZXQpO1xuICAgICAgICAgICAgbiA9ICRpby5hdHRyMignbmFtZScpO1xuICAgICAgICAgICAgaWYgKCFuKSB7XG4gICAgICAgICAgICAgICAgJGlvLmF0dHIyKCduYW1lJywgaWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgaWQgPSBuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgJGlvID0gJCgnPGlmcmFtZSBuYW1lPVwiJyArIGlkICsgJ1wiIHNyYz1cIicrIHMuaWZyYW1lU3JjICsnXCIgLz4nKTtcbiAgICAgICAgICAgICRpby5jc3MoeyBwb3NpdGlvbjogJ2Fic29sdXRlJywgdG9wOiAnLTEwMDBweCcsIGxlZnQ6ICctMTAwMHB4JyB9KTtcbiAgICAgICAgfVxuICAgICAgICBpbyA9ICRpb1swXTtcblxuXG4gICAgICAgIHhociA9IHsgLy8gbW9jayBvYmplY3RcbiAgICAgICAgICAgIGFib3J0ZWQ6IDAsXG4gICAgICAgICAgICByZXNwb25zZVRleHQ6IG51bGwsXG4gICAgICAgICAgICByZXNwb25zZVhNTDogbnVsbCxcbiAgICAgICAgICAgIHN0YXR1czogMCxcbiAgICAgICAgICAgIHN0YXR1c1RleHQ6ICduL2EnLFxuICAgICAgICAgICAgZ2V0QWxsUmVzcG9uc2VIZWFkZXJzOiBmdW5jdGlvbigpIHt9LFxuICAgICAgICAgICAgZ2V0UmVzcG9uc2VIZWFkZXI6IGZ1bmN0aW9uKCkge30sXG4gICAgICAgICAgICBzZXRSZXF1ZXN0SGVhZGVyOiBmdW5jdGlvbigpIHt9LFxuICAgICAgICAgICAgYWJvcnQ6IGZ1bmN0aW9uKHN0YXR1cykge1xuICAgICAgICAgICAgICAgIHZhciBlID0gKHN0YXR1cyA9PT0gJ3RpbWVvdXQnID8gJ3RpbWVvdXQnIDogJ2Fib3J0ZWQnKTtcbiAgICAgICAgICAgICAgICBsb2coJ2Fib3J0aW5nIHVwbG9hZC4uLiAnICsgZSk7XG4gICAgICAgICAgICAgICAgdGhpcy5hYm9ydGVkID0gMTtcblxuICAgICAgICAgICAgICAgIHRyeSB7IC8vICMyMTQsICMyNTdcbiAgICAgICAgICAgICAgICAgICAgaWYgKGlvLmNvbnRlbnRXaW5kb3cuZG9jdW1lbnQuZXhlY0NvbW1hbmQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlvLmNvbnRlbnRXaW5kb3cuZG9jdW1lbnQuZXhlY0NvbW1hbmQoJ1N0b3AnKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChpZ25vcmUpIHt9XG5cbiAgICAgICAgICAgICAgICAkaW8uYXR0cignc3JjJywgcy5pZnJhbWVTcmMpOyAvLyBhYm9ydCBvcCBpbiBwcm9ncmVzc1xuICAgICAgICAgICAgICAgIHhoci5lcnJvciA9IGU7XG4gICAgICAgICAgICAgICAgaWYgKHMuZXJyb3IpIHtcbiAgICAgICAgICAgICAgICAgICAgcy5lcnJvci5jYWxsKHMuY29udGV4dCwgeGhyLCBlLCBzdGF0dXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoZykge1xuICAgICAgICAgICAgICAgICAgICAkLmV2ZW50LnRyaWdnZXIoXCJhamF4RXJyb3JcIiwgW3hociwgcywgZV0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAocy5jb21wbGV0ZSkge1xuICAgICAgICAgICAgICAgICAgICBzLmNvbXBsZXRlLmNhbGwocy5jb250ZXh0LCB4aHIsIGUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfTtcblxuICAgICAgICBnID0gcy5nbG9iYWw7XG4gICAgICAgIC8vIHRyaWdnZXIgYWpheCBnbG9iYWwgZXZlbnRzIHNvIHRoYXQgYWN0aXZpdHkvYmxvY2sgaW5kaWNhdG9ycyB3b3JrIGxpa2Ugbm9ybWFsXG4gICAgICAgIGlmIChnICYmIDAgPT09ICQuYWN0aXZlKyspIHtcbiAgICAgICAgICAgICQuZXZlbnQudHJpZ2dlcihcImFqYXhTdGFydFwiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoZykge1xuICAgICAgICAgICAgJC5ldmVudC50cmlnZ2VyKFwiYWpheFNlbmRcIiwgW3hociwgc10pO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHMuYmVmb3JlU2VuZCAmJiBzLmJlZm9yZVNlbmQuY2FsbChzLmNvbnRleHQsIHhociwgcykgPT09IGZhbHNlKSB7XG4gICAgICAgICAgICBpZiAocy5nbG9iYWwpIHtcbiAgICAgICAgICAgICAgICAkLmFjdGl2ZS0tO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZGVmZXJyZWQucmVqZWN0KCk7XG4gICAgICAgICAgICByZXR1cm4gZGVmZXJyZWQ7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHhoci5hYm9ydGVkKSB7XG4gICAgICAgICAgICBkZWZlcnJlZC5yZWplY3QoKTtcbiAgICAgICAgICAgIHJldHVybiBkZWZlcnJlZDtcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIGFkZCBzdWJtaXR0aW5nIGVsZW1lbnQgdG8gZGF0YSBpZiB3ZSBrbm93IGl0XG4gICAgICAgIHN1YiA9IGZvcm0uY2xrO1xuICAgICAgICBpZiAoc3ViKSB7XG4gICAgICAgICAgICBuID0gc3ViLm5hbWU7XG4gICAgICAgICAgICBpZiAobiAmJiAhc3ViLmRpc2FibGVkKSB7XG4gICAgICAgICAgICAgICAgcy5leHRyYURhdGEgPSBzLmV4dHJhRGF0YSB8fCB7fTtcbiAgICAgICAgICAgICAgICBzLmV4dHJhRGF0YVtuXSA9IHN1Yi52YWx1ZTtcbiAgICAgICAgICAgICAgICBpZiAoc3ViLnR5cGUgPT0gXCJpbWFnZVwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHMuZXh0cmFEYXRhW24rJy54J10gPSBmb3JtLmNsa194O1xuICAgICAgICAgICAgICAgICAgICBzLmV4dHJhRGF0YVtuKycueSddID0gZm9ybS5jbGtfeTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cblxuICAgICAgICB2YXIgQ0xJRU5UX1RJTUVPVVRfQUJPUlQgPSAxO1xuICAgICAgICB2YXIgU0VSVkVSX0FCT1JUID0gMjtcbiAgICAgICAgICAgICAgICBcbiAgICAgICAgZnVuY3Rpb24gZ2V0RG9jKGZyYW1lKSB7XG4gICAgICAgICAgICAvKiBpdCBsb29rcyBsaWtlIGNvbnRlbnRXaW5kb3cgb3IgY29udGVudERvY3VtZW50IGRvIG5vdFxuICAgICAgICAgICAgICogY2FycnkgdGhlIHByb3RvY29sIHByb3BlcnR5IGluIGllOCwgd2hlbiBydW5uaW5nIHVuZGVyIHNzbFxuICAgICAgICAgICAgICogZnJhbWUuZG9jdW1lbnQgaXMgdGhlIG9ubHkgdmFsaWQgcmVzcG9uc2UgZG9jdW1lbnQsIHNpbmNlXG4gICAgICAgICAgICAgKiB0aGUgcHJvdG9jb2wgaXMga25vdyBidXQgbm90IG9uIHRoZSBvdGhlciB0d28gb2JqZWN0cy4gc3RyYW5nZT9cbiAgICAgICAgICAgICAqIFwiU2FtZSBvcmlnaW4gcG9saWN5XCIgaHR0cDovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9TYW1lX29yaWdpbl9wb2xpY3lcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgXG4gICAgICAgICAgICB2YXIgZG9jID0gbnVsbDtcbiAgICAgICAgICAgIFxuICAgICAgICAgICAgLy8gSUU4IGNhc2NhZGluZyBhY2Nlc3MgY2hlY2tcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKGZyYW1lLmNvbnRlbnRXaW5kb3cpIHtcbiAgICAgICAgICAgICAgICAgICAgZG9jID0gZnJhbWUuY29udGVudFdpbmRvdy5kb2N1bWVudDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGNhdGNoKGVycikge1xuICAgICAgICAgICAgICAgIC8vIElFOCBhY2Nlc3MgZGVuaWVkIHVuZGVyIHNzbCAmIG1pc3NpbmcgcHJvdG9jb2xcbiAgICAgICAgICAgICAgICBsb2coJ2Nhbm5vdCBnZXQgaWZyYW1lLmNvbnRlbnRXaW5kb3cgZG9jdW1lbnQ6ICcgKyBlcnIpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoZG9jKSB7IC8vIHN1Y2Nlc3NmdWwgZ2V0dGluZyBjb250ZW50XG4gICAgICAgICAgICAgICAgcmV0dXJuIGRvYztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgdHJ5IHsgLy8gc2ltcGx5IGNoZWNraW5nIG1heSB0aHJvdyBpbiBpZTggdW5kZXIgc3NsIG9yIG1pc21hdGNoZWQgcHJvdG9jb2xcbiAgICAgICAgICAgICAgICBkb2MgPSBmcmFtZS5jb250ZW50RG9jdW1lbnQgPyBmcmFtZS5jb250ZW50RG9jdW1lbnQgOiBmcmFtZS5kb2N1bWVudDtcbiAgICAgICAgICAgIH0gY2F0Y2goZXJyKSB7XG4gICAgICAgICAgICAgICAgLy8gbGFzdCBhdHRlbXB0XG4gICAgICAgICAgICAgICAgbG9nKCdjYW5ub3QgZ2V0IGlmcmFtZS5jb250ZW50RG9jdW1lbnQ6ICcgKyBlcnIpO1xuICAgICAgICAgICAgICAgIGRvYyA9IGZyYW1lLmRvY3VtZW50O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGRvYztcbiAgICAgICAgfVxuXG4gICAgICAgIC8vIFJhaWxzIENTUkYgaGFjayAodGhhbmtzIHRvIFl2YW4gQmFydGhlbGVteSlcbiAgICAgICAgdmFyIGNzcmZfdG9rZW4gPSAkKCdtZXRhW25hbWU9Y3NyZi10b2tlbl0nKS5hdHRyKCdjb250ZW50Jyk7XG4gICAgICAgIHZhciBjc3JmX3BhcmFtID0gJCgnbWV0YVtuYW1lPWNzcmYtcGFyYW1dJykuYXR0cignY29udGVudCcpO1xuICAgICAgICBpZiAoY3NyZl9wYXJhbSAmJiBjc3JmX3Rva2VuKSB7XG4gICAgICAgICAgICBzLmV4dHJhRGF0YSA9IHMuZXh0cmFEYXRhIHx8IHt9O1xuICAgICAgICAgICAgcy5leHRyYURhdGFbY3NyZl9wYXJhbV0gPSBjc3JmX3Rva2VuO1xuICAgICAgICB9XG5cbiAgICAgICAgLy8gdGFrZSBhIGJyZWF0aCBzbyB0aGF0IHBlbmRpbmcgcmVwYWludHMgZ2V0IHNvbWUgY3B1IHRpbWUgYmVmb3JlIHRoZSB1cGxvYWQgc3RhcnRzXG4gICAgICAgIGZ1bmN0aW9uIGRvU3VibWl0KCkge1xuICAgICAgICAgICAgLy8gbWFrZSBzdXJlIGZvcm0gYXR0cnMgYXJlIHNldFxuICAgICAgICAgICAgdmFyIHQgPSAkZm9ybS5hdHRyMigndGFyZ2V0JyksIFxuICAgICAgICAgICAgICAgIGEgPSAkZm9ybS5hdHRyMignYWN0aW9uJyksIFxuICAgICAgICAgICAgICAgIG1wID0gJ211bHRpcGFydC9mb3JtLWRhdGEnLFxuICAgICAgICAgICAgICAgIGV0ID0gJGZvcm0uYXR0cignZW5jdHlwZScpIHx8ICRmb3JtLmF0dHIoJ2VuY29kaW5nJykgfHwgbXA7XG5cbiAgICAgICAgICAgIC8vIHVwZGF0ZSBmb3JtIGF0dHJzIGluIElFIGZyaWVuZGx5IHdheVxuICAgICAgICAgICAgZm9ybS5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsaWQpO1xuICAgICAgICAgICAgaWYgKCFtZXRob2QgfHwgL3Bvc3QvaS50ZXN0KG1ldGhvZCkgKSB7XG4gICAgICAgICAgICAgICAgZm9ybS5zZXRBdHRyaWJ1dGUoJ21ldGhvZCcsICdQT1NUJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYSAhPSBzLnVybCkge1xuICAgICAgICAgICAgICAgIGZvcm0uc2V0QXR0cmlidXRlKCdhY3Rpb24nLCBzLnVybCk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIGllIGJvcmtzIGluIHNvbWUgY2FzZXMgd2hlbiBzZXR0aW5nIGVuY29kaW5nXG4gICAgICAgICAgICBpZiAoISBzLnNraXBFbmNvZGluZ092ZXJyaWRlICYmICghbWV0aG9kIHx8IC9wb3N0L2kudGVzdChtZXRob2QpKSkge1xuICAgICAgICAgICAgICAgICRmb3JtLmF0dHIoe1xuICAgICAgICAgICAgICAgICAgICBlbmNvZGluZzogJ211bHRpcGFydC9mb3JtLWRhdGEnLFxuICAgICAgICAgICAgICAgICAgICBlbmN0eXBlOiAgJ211bHRpcGFydC9mb3JtLWRhdGEnXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIC8vIHN1cHBvcnQgdGltb3V0XG4gICAgICAgICAgICBpZiAocy50aW1lb3V0KSB7XG4gICAgICAgICAgICAgICAgdGltZW91dEhhbmRsZSA9IHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7IHRpbWVkT3V0ID0gdHJ1ZTsgY2IoQ0xJRU5UX1RJTUVPVVRfQUJPUlQpOyB9LCBzLnRpbWVvdXQpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBsb29rIGZvciBzZXJ2ZXIgYWJvcnRzXG4gICAgICAgICAgICBmdW5jdGlvbiBjaGVja1N0YXRlKCkge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBzdGF0ZSA9IGdldERvYyhpbykucmVhZHlTdGF0ZTtcbiAgICAgICAgICAgICAgICAgICAgbG9nKCdzdGF0ZSA9ICcgKyBzdGF0ZSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChzdGF0ZSAmJiBzdGF0ZS50b0xvd2VyQ2FzZSgpID09ICd1bmluaXRpYWxpemVkJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChjaGVja1N0YXRlLDUwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBjYXRjaChlKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZygnU2VydmVyIGFib3J0OiAnICwgZSwgJyAoJywgZS5uYW1lLCAnKScpO1xuICAgICAgICAgICAgICAgICAgICBjYihTRVJWRVJfQUJPUlQpO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGltZW91dEhhbmRsZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRIYW5kbGUpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRpbWVvdXRIYW5kbGUgPSB1bmRlZmluZWQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBhZGQgXCJleHRyYVwiIGRhdGEgdG8gZm9ybSBpZiBwcm92aWRlZCBpbiBvcHRpb25zXG4gICAgICAgICAgICB2YXIgZXh0cmFJbnB1dHMgPSBbXTtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgaWYgKHMuZXh0cmFEYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIG4gaW4gcy5leHRyYURhdGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChzLmV4dHJhRGF0YS5oYXNPd25Qcm9wZXJ0eShuKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gaWYgdXNpbmcgdGhlICQucGFyYW0gZm9ybWF0IHRoYXQgYWxsb3dzIGZvciBtdWx0aXBsZSB2YWx1ZXMgd2l0aCB0aGUgc2FtZSBuYW1lXG4gICAgICAgICAgICAgICAgICAgICAgICAgICBpZigkLmlzUGxhaW5PYmplY3Qocy5leHRyYURhdGFbbl0pICYmIHMuZXh0cmFEYXRhW25dLmhhc093blByb3BlcnR5KCduYW1lJykgJiYgcy5leHRyYURhdGFbbl0uaGFzT3duUHJvcGVydHkoJ3ZhbHVlJykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHRyYUlucHV0cy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICQoJzxpbnB1dCB0eXBlPVwiaGlkZGVuXCIgbmFtZT1cIicrcy5leHRyYURhdGFbbl0ubmFtZSsnXCI+JykudmFsKHMuZXh0cmFEYXRhW25dLnZhbHVlKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuYXBwZW5kVG8oZm9ybSlbMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBleHRyYUlucHV0cy5wdXNoKFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICQoJzxpbnB1dCB0eXBlPVwiaGlkZGVuXCIgbmFtZT1cIicrbisnXCI+JykudmFsKHMuZXh0cmFEYXRhW25dKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuYXBwZW5kVG8oZm9ybSlbMF0pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgaWYgKCFzLmlmcmFtZVRhcmdldCkge1xuICAgICAgICAgICAgICAgICAgICAvLyBhZGQgaWZyYW1lIHRvIGRvYyBhbmQgc3VibWl0IHRoZSBmb3JtXG4gICAgICAgICAgICAgICAgICAgICRpby5hcHBlbmRUbygnYm9keScpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoaW8uYXR0YWNoRXZlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgaW8uYXR0YWNoRXZlbnQoJ29ubG9hZCcsIGNiKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlvLmFkZEV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBjYiwgZmFsc2UpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzZXRUaW1lb3V0KGNoZWNrU3RhdGUsMTUpO1xuXG4gICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgZm9ybS5zdWJtaXQoKTtcbiAgICAgICAgICAgICAgICB9IGNhdGNoKGVycikge1xuICAgICAgICAgICAgICAgICAgICAvLyBqdXN0IGluIGNhc2UgZm9ybSBoYXMgZWxlbWVudCB3aXRoIG5hbWUvaWQgb2YgJ3N1Ym1pdCdcbiAgICAgICAgICAgICAgICAgICAgdmFyIHN1Ym1pdEZuID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZm9ybScpLnN1Ym1pdDtcbiAgICAgICAgICAgICAgICAgICAgc3VibWl0Rm4uYXBwbHkoZm9ybSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICAgICAgLy8gcmVzZXQgYXR0cnMgYW5kIHJlbW92ZSBcImV4dHJhXCIgaW5wdXQgZWxlbWVudHNcbiAgICAgICAgICAgICAgICBmb3JtLnNldEF0dHJpYnV0ZSgnYWN0aW9uJyxhKTtcbiAgICAgICAgICAgICAgICBmb3JtLnNldEF0dHJpYnV0ZSgnZW5jdHlwZScsIGV0KTsgLy8gIzM4MFxuICAgICAgICAgICAgICAgIGlmKHQpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9ybS5zZXRBdHRyaWJ1dGUoJ3RhcmdldCcsIHQpO1xuICAgICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICRmb3JtLnJlbW92ZUF0dHIoJ3RhcmdldCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAkKGV4dHJhSW5wdXRzKS5yZW1vdmUoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChzLmZvcmNlU3luYykge1xuICAgICAgICAgICAgZG9TdWJtaXQoKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZG9TdWJtaXQsIDEwKTsgLy8gdGhpcyBsZXRzIGRvbSB1cGRhdGVzIHJlbmRlclxuICAgICAgICB9XG5cbiAgICAgICAgdmFyIGRhdGEsIGRvYywgZG9tQ2hlY2tDb3VudCA9IDUwLCBjYWxsYmFja1Byb2Nlc3NlZDtcblxuICAgICAgICBmdW5jdGlvbiBjYihlKSB7XG4gICAgICAgICAgICBpZiAoeGhyLmFib3J0ZWQgfHwgY2FsbGJhY2tQcm9jZXNzZWQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBcbiAgICAgICAgICAgIGRvYyA9IGdldERvYyhpbyk7XG4gICAgICAgICAgICBpZighZG9jKSB7XG4gICAgICAgICAgICAgICAgbG9nKCdjYW5ub3QgYWNjZXNzIHJlc3BvbnNlIGRvY3VtZW50Jyk7XG4gICAgICAgICAgICAgICAgZSA9IFNFUlZFUl9BQk9SVDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChlID09PSBDTElFTlRfVElNRU9VVF9BQk9SVCAmJiB4aHIpIHtcbiAgICAgICAgICAgICAgICB4aHIuYWJvcnQoJ3RpbWVvdXQnKTtcbiAgICAgICAgICAgICAgICBkZWZlcnJlZC5yZWplY3QoeGhyLCAndGltZW91dCcpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGUgPT0gU0VSVkVSX0FCT1JUICYmIHhocikge1xuICAgICAgICAgICAgICAgIHhoci5hYm9ydCgnc2VydmVyIGFib3J0Jyk7XG4gICAgICAgICAgICAgICAgZGVmZXJyZWQucmVqZWN0KHhociwgJ2Vycm9yJywgJ3NlcnZlciBhYm9ydCcpO1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCFkb2MgfHwgZG9jLmxvY2F0aW9uLmhyZWYgPT0gcy5pZnJhbWVTcmMpIHtcbiAgICAgICAgICAgICAgICAvLyByZXNwb25zZSBub3QgcmVjZWl2ZWQgeWV0XG4gICAgICAgICAgICAgICAgaWYgKCF0aW1lZE91dCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGlvLmRldGFjaEV2ZW50KSB7XG4gICAgICAgICAgICAgICAgaW8uZGV0YWNoRXZlbnQoJ29ubG9hZCcsIGNiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGlvLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2xvYWQnLCBjYiwgZmFsc2UpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB2YXIgc3RhdHVzID0gJ3N1Y2Nlc3MnLCBlcnJNc2c7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIGlmICh0aW1lZE91dCkge1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyAndGltZW91dCc7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgICAgdmFyIGlzWG1sID0gcy5kYXRhVHlwZSA9PSAneG1sJyB8fCBkb2MuWE1MRG9jdW1lbnQgfHwgJC5pc1hNTERvYyhkb2MpO1xuICAgICAgICAgICAgICAgIGxvZygnaXNYbWw9Jytpc1htbCk7XG4gICAgICAgICAgICAgICAgaWYgKCFpc1htbCAmJiB3aW5kb3cub3BlcmEgJiYgKGRvYy5ib2R5ID09PSBudWxsIHx8ICFkb2MuYm9keS5pbm5lckhUTUwpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICgtLWRvbUNoZWNrQ291bnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGluIHNvbWUgYnJvd3NlcnMgKE9wZXJhKSB0aGUgaWZyYW1lIERPTSBpcyBub3QgYWx3YXlzIHRyYXZlcnNhYmxlIHdoZW5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRoZSBvbmxvYWQgY2FsbGJhY2sgZmlyZXMsIHNvIHdlIGxvb3AgYSBiaXQgdG8gYWNjb21tb2RhdGVcbiAgICAgICAgICAgICAgICAgICAgICAgIGxvZygncmVxdWVpbmcgb25Mb2FkIGNhbGxiYWNrLCBET00gbm90IGF2YWlsYWJsZScpO1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChjYiwgMjUwKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBsZXQgdGhpcyBmYWxsIHRocm91Z2ggYmVjYXVzZSBzZXJ2ZXIgcmVzcG9uc2UgY291bGQgYmUgYW4gZW1wdHkgZG9jdW1lbnRcbiAgICAgICAgICAgICAgICAgICAgLy9sb2coJ0NvdWxkIG5vdCBhY2Nlc3MgaWZyYW1lIERPTSBhZnRlciBtdXRpcGxlIHRyaWVzLicpO1xuICAgICAgICAgICAgICAgICAgICAvL3Rocm93ICdET01FeGNlcHRpb246IG5vdCBhdmFpbGFibGUnO1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIC8vbG9nKCdyZXNwb25zZSBkZXRlY3RlZCcpO1xuICAgICAgICAgICAgICAgIHZhciBkb2NSb290ID0gZG9jLmJvZHkgPyBkb2MuYm9keSA6IGRvYy5kb2N1bWVudEVsZW1lbnQ7XG4gICAgICAgICAgICAgICAgeGhyLnJlc3BvbnNlVGV4dCA9IGRvY1Jvb3QgPyBkb2NSb290LmlubmVySFRNTCA6IG51bGw7XG4gICAgICAgICAgICAgICAgeGhyLnJlc3BvbnNlWE1MID0gZG9jLlhNTERvY3VtZW50ID8gZG9jLlhNTERvY3VtZW50IDogZG9jO1xuICAgICAgICAgICAgICAgIGlmIChpc1htbCkge1xuICAgICAgICAgICAgICAgICAgICBzLmRhdGFUeXBlID0gJ3htbCc7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHhoci5nZXRSZXNwb25zZUhlYWRlciA9IGZ1bmN0aW9uKGhlYWRlcil7XG4gICAgICAgICAgICAgICAgICAgIHZhciBoZWFkZXJzID0geydjb250ZW50LXR5cGUnOiBzLmRhdGFUeXBlfTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGhlYWRlcnNbaGVhZGVyLnRvTG93ZXJDYXNlKCldO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgLy8gc3VwcG9ydCBmb3IgWEhSICdzdGF0dXMnICYgJ3N0YXR1c1RleHQnIGVtdWxhdGlvbiA6XG4gICAgICAgICAgICAgICAgaWYgKGRvY1Jvb3QpIHtcbiAgICAgICAgICAgICAgICAgICAgeGhyLnN0YXR1cyA9IE51bWJlciggZG9jUm9vdC5nZXRBdHRyaWJ1dGUoJ3N0YXR1cycpICkgfHwgeGhyLnN0YXR1cztcbiAgICAgICAgICAgICAgICAgICAgeGhyLnN0YXR1c1RleHQgPSBkb2NSb290LmdldEF0dHJpYnV0ZSgnc3RhdHVzVGV4dCcpIHx8IHhoci5zdGF0dXNUZXh0O1xuICAgICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICAgIHZhciBkdCA9IChzLmRhdGFUeXBlIHx8ICcnKS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICAgICAgICAgIHZhciBzY3IgPSAvKGpzb258c2NyaXB0fHRleHQpLy50ZXN0KGR0KTtcbiAgICAgICAgICAgICAgICBpZiAoc2NyIHx8IHMudGV4dGFyZWEpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gc2VlIGlmIHVzZXIgZW1iZWRkZWQgcmVzcG9uc2UgaW4gdGV4dGFyZWFcbiAgICAgICAgICAgICAgICAgICAgdmFyIHRhID0gZG9jLmdldEVsZW1lbnRzQnlUYWdOYW1lKCd0ZXh0YXJlYScpWzBdO1xuICAgICAgICAgICAgICAgICAgICBpZiAodGEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHhoci5yZXNwb25zZVRleHQgPSB0YS52YWx1ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHN1cHBvcnQgZm9yIFhIUiAnc3RhdHVzJyAmICdzdGF0dXNUZXh0JyBlbXVsYXRpb24gOlxuICAgICAgICAgICAgICAgICAgICAgICAgeGhyLnN0YXR1cyA9IE51bWJlciggdGEuZ2V0QXR0cmlidXRlKCdzdGF0dXMnKSApIHx8IHhoci5zdGF0dXM7XG4gICAgICAgICAgICAgICAgICAgICAgICB4aHIuc3RhdHVzVGV4dCA9IHRhLmdldEF0dHJpYnV0ZSgnc3RhdHVzVGV4dCcpIHx8IHhoci5zdGF0dXNUZXh0O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKHNjcikge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWNjb3VudCBmb3IgYnJvd3NlcnMgaW5qZWN0aW5nIHByZSBhcm91bmQganNvbiByZXNwb25zZVxuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHByZSA9IGRvYy5nZXRFbGVtZW50c0J5VGFnTmFtZSgncHJlJylbMF07XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgYiA9IGRvYy5nZXRFbGVtZW50c0J5VGFnTmFtZSgnYm9keScpWzBdO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHByZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhoci5yZXNwb25zZVRleHQgPSBwcmUudGV4dENvbnRlbnQgPyBwcmUudGV4dENvbnRlbnQgOiBwcmUuaW5uZXJUZXh0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoYikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHhoci5yZXNwb25zZVRleHQgPSBiLnRleHRDb250ZW50ID8gYi50ZXh0Q29udGVudCA6IGIuaW5uZXJUZXh0O1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGR0ID09ICd4bWwnICYmICF4aHIucmVzcG9uc2VYTUwgJiYgeGhyLnJlc3BvbnNlVGV4dCkge1xuICAgICAgICAgICAgICAgICAgICB4aHIucmVzcG9uc2VYTUwgPSB0b1htbCh4aHIucmVzcG9uc2VUZXh0KTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICBkYXRhID0gaHR0cERhdGEoeGhyLCBkdCwgcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzID0gJ3BhcnNlcmVycm9yJztcbiAgICAgICAgICAgICAgICAgICAgeGhyLmVycm9yID0gZXJyTXNnID0gKGVyciB8fCBzdGF0dXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlcnIpIHtcbiAgICAgICAgICAgICAgICBsb2coJ2Vycm9yIGNhdWdodDogJyxlcnIpO1xuICAgICAgICAgICAgICAgIHN0YXR1cyA9ICdlcnJvcic7XG4gICAgICAgICAgICAgICAgeGhyLmVycm9yID0gZXJyTXNnID0gKGVyciB8fCBzdGF0dXMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBpZiAoeGhyLmFib3J0ZWQpIHtcbiAgICAgICAgICAgICAgICBsb2coJ3VwbG9hZCBhYm9ydGVkJyk7XG4gICAgICAgICAgICAgICAgc3RhdHVzID0gbnVsbDtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKHhoci5zdGF0dXMpIHsgLy8gd2UndmUgc2V0IHhoci5zdGF0dXNcbiAgICAgICAgICAgICAgICBzdGF0dXMgPSAoeGhyLnN0YXR1cyA+PSAyMDAgJiYgeGhyLnN0YXR1cyA8IDMwMCB8fCB4aHIuc3RhdHVzID09PSAzMDQpID8gJ3N1Y2Nlc3MnIDogJ2Vycm9yJztcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgLy8gb3JkZXJpbmcgb2YgdGhlc2UgY2FsbGJhY2tzL3RyaWdnZXJzIGlzIG9kZCwgYnV0IHRoYXQncyBob3cgJC5hamF4IGRvZXMgaXRcbiAgICAgICAgICAgIGlmIChzdGF0dXMgPT09ICdzdWNjZXNzJykge1xuICAgICAgICAgICAgICAgIGlmIChzLnN1Y2Nlc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgcy5zdWNjZXNzLmNhbGwocy5jb250ZXh0LCBkYXRhLCAnc3VjY2VzcycsIHhocik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGRlZmVycmVkLnJlc29sdmUoeGhyLnJlc3BvbnNlVGV4dCwgJ3N1Y2Nlc3MnLCB4aHIpO1xuICAgICAgICAgICAgICAgIGlmIChnKSB7XG4gICAgICAgICAgICAgICAgICAgICQuZXZlbnQudHJpZ2dlcihcImFqYXhTdWNjZXNzXCIsIFt4aHIsIHNdKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChzdGF0dXMpIHtcbiAgICAgICAgICAgICAgICBpZiAoZXJyTXNnID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgZXJyTXNnID0geGhyLnN0YXR1c1RleHQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChzLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgIHMuZXJyb3IuY2FsbChzLmNvbnRleHQsIHhociwgc3RhdHVzLCBlcnJNc2cpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBkZWZlcnJlZC5yZWplY3QoeGhyLCAnZXJyb3InLCBlcnJNc2cpO1xuICAgICAgICAgICAgICAgIGlmIChnKSB7XG4gICAgICAgICAgICAgICAgICAgICQuZXZlbnQudHJpZ2dlcihcImFqYXhFcnJvclwiLCBbeGhyLCBzLCBlcnJNc2ddKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChnKSB7XG4gICAgICAgICAgICAgICAgJC5ldmVudC50cmlnZ2VyKFwiYWpheENvbXBsZXRlXCIsIFt4aHIsIHNdKTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKGcgJiYgISAtLSQuYWN0aXZlKSB7XG4gICAgICAgICAgICAgICAgJC5ldmVudC50cmlnZ2VyKFwiYWpheFN0b3BcIik7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmIChzLmNvbXBsZXRlKSB7XG4gICAgICAgICAgICAgICAgcy5jb21wbGV0ZS5jYWxsKHMuY29udGV4dCwgeGhyLCBzdGF0dXMpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBjYWxsYmFja1Byb2Nlc3NlZCA9IHRydWU7XG4gICAgICAgICAgICBpZiAocy50aW1lb3V0KSB7XG4gICAgICAgICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXRIYW5kbGUpO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAvLyBjbGVhbiB1cFxuICAgICAgICAgICAgc2V0VGltZW91dChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICBpZiAoIXMuaWZyYW1lVGFyZ2V0KSB7XG4gICAgICAgICAgICAgICAgICAgICRpby5yZW1vdmUoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7IC8vYWRkaW5nIGVsc2UgdG8gY2xlYW4gdXAgZXhpc3RpbmcgaWZyYW1lIHJlc3BvbnNlLlxuICAgICAgICAgICAgICAgICAgICAkaW8uYXR0cignc3JjJywgcy5pZnJhbWVTcmMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB4aHIucmVzcG9uc2VYTUwgPSBudWxsO1xuICAgICAgICAgICAgfSwgMTAwKTtcbiAgICAgICAgfVxuXG4gICAgICAgIHZhciB0b1htbCA9ICQucGFyc2VYTUwgfHwgZnVuY3Rpb24ocywgZG9jKSB7IC8vIHVzZSBwYXJzZVhNTCBpZiBhdmFpbGFibGUgKGpRdWVyeSAxLjUrKVxuICAgICAgICAgICAgaWYgKHdpbmRvdy5BY3RpdmVYT2JqZWN0KSB7XG4gICAgICAgICAgICAgICAgZG9jID0gbmV3IEFjdGl2ZVhPYmplY3QoJ01pY3Jvc29mdC5YTUxET00nKTtcbiAgICAgICAgICAgICAgICBkb2MuYXN5bmMgPSAnZmFsc2UnO1xuICAgICAgICAgICAgICAgIGRvYy5sb2FkWE1MKHMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZG9jID0gKG5ldyBET01QYXJzZXIoKSkucGFyc2VGcm9tU3RyaW5nKHMsICd0ZXh0L3htbCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIChkb2MgJiYgZG9jLmRvY3VtZW50RWxlbWVudCAmJiBkb2MuZG9jdW1lbnRFbGVtZW50Lm5vZGVOYW1lICE9ICdwYXJzZXJlcnJvcicpID8gZG9jIDogbnVsbDtcbiAgICAgICAgfTtcbiAgICAgICAgdmFyIHBhcnNlSlNPTiA9ICQucGFyc2VKU09OIHx8IGZ1bmN0aW9uKHMpIHtcbiAgICAgICAgICAgIC8qanNsaW50IGV2aWw6dHJ1ZSAqL1xuICAgICAgICAgICAgcmV0dXJuIHdpbmRvd1snZXZhbCddKCcoJyArIHMgKyAnKScpO1xuICAgICAgICB9O1xuXG4gICAgICAgIHZhciBodHRwRGF0YSA9IGZ1bmN0aW9uKCB4aHIsIHR5cGUsIHMgKSB7IC8vIG1vc3RseSBsaWZ0ZWQgZnJvbSBqcTEuNC40XG5cbiAgICAgICAgICAgIHZhciBjdCA9IHhoci5nZXRSZXNwb25zZUhlYWRlcignY29udGVudC10eXBlJykgfHwgJycsXG4gICAgICAgICAgICAgICAgeG1sID0gdHlwZSA9PT0gJ3htbCcgfHwgIXR5cGUgJiYgY3QuaW5kZXhPZigneG1sJykgPj0gMCxcbiAgICAgICAgICAgICAgICBkYXRhID0geG1sID8geGhyLnJlc3BvbnNlWE1MIDogeGhyLnJlc3BvbnNlVGV4dDtcblxuICAgICAgICAgICAgaWYgKHhtbCAmJiBkYXRhLmRvY3VtZW50RWxlbWVudC5ub2RlTmFtZSA9PT0gJ3BhcnNlcmVycm9yJykge1xuICAgICAgICAgICAgICAgIGlmICgkLmVycm9yKSB7XG4gICAgICAgICAgICAgICAgICAgICQuZXJyb3IoJ3BhcnNlcmVycm9yJyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHMgJiYgcy5kYXRhRmlsdGVyKSB7XG4gICAgICAgICAgICAgICAgZGF0YSA9IHMuZGF0YUZpbHRlcihkYXRhLCB0eXBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICh0eXBlb2YgZGF0YSA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICBpZiAodHlwZSA9PT0gJ2pzb24nIHx8ICF0eXBlICYmIGN0LmluZGV4T2YoJ2pzb24nKSA+PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgIGRhdGEgPSBwYXJzZUpTT04oZGF0YSk7XG4gICAgICAgICAgICAgICAgfSBlbHNlIGlmICh0eXBlID09PSBcInNjcmlwdFwiIHx8ICF0eXBlICYmIGN0LmluZGV4T2YoXCJqYXZhc2NyaXB0XCIpID49IDApIHtcbiAgICAgICAgICAgICAgICAgICAgJC5nbG9iYWxFdmFsKGRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkYXRhO1xuICAgICAgICB9O1xuXG4gICAgICAgIHJldHVybiBkZWZlcnJlZDtcbiAgICB9XG59O1xuXG4vKipcbiAqIGFqYXhGb3JtKCkgcHJvdmlkZXMgYSBtZWNoYW5pc20gZm9yIGZ1bGx5IGF1dG9tYXRpbmcgZm9ybSBzdWJtaXNzaW9uLlxuICpcbiAqIFRoZSBhZHZhbnRhZ2VzIG9mIHVzaW5nIHRoaXMgbWV0aG9kIGluc3RlYWQgb2YgYWpheFN1Ym1pdCgpIGFyZTpcbiAqXG4gKiAxOiBUaGlzIG1ldGhvZCB3aWxsIGluY2x1ZGUgY29vcmRpbmF0ZXMgZm9yIDxpbnB1dCB0eXBlPVwiaW1hZ2VcIiAvPiBlbGVtZW50cyAoaWYgdGhlIGVsZW1lbnRcbiAqICAgIGlzIHVzZWQgdG8gc3VibWl0IHRoZSBmb3JtKS5cbiAqIDIuIFRoaXMgbWV0aG9kIHdpbGwgaW5jbHVkZSB0aGUgc3VibWl0IGVsZW1lbnQncyBuYW1lL3ZhbHVlIGRhdGEgKGZvciB0aGUgZWxlbWVudCB0aGF0IHdhc1xuICogICAgdXNlZCB0byBzdWJtaXQgdGhlIGZvcm0pLlxuICogMy4gVGhpcyBtZXRob2QgYmluZHMgdGhlIHN1Ym1pdCgpIG1ldGhvZCB0byB0aGUgZm9ybSBmb3IgeW91LlxuICpcbiAqIFRoZSBvcHRpb25zIGFyZ3VtZW50IGZvciBhamF4Rm9ybSB3b3JrcyBleGFjdGx5IGFzIGl0IGRvZXMgZm9yIGFqYXhTdWJtaXQuICBhamF4Rm9ybSBtZXJlbHlcbiAqIHBhc3NlcyB0aGUgb3B0aW9ucyBhcmd1bWVudCBhbG9uZyBhZnRlciBwcm9wZXJseSBiaW5kaW5nIGV2ZW50cyBmb3Igc3VibWl0IGVsZW1lbnRzIGFuZFxuICogdGhlIGZvcm0gaXRzZWxmLlxuICovXG4kLmZuLmFqYXhGb3JtID0gZnVuY3Rpb24ob3B0aW9ucykge1xuICAgIG9wdGlvbnMgPSBvcHRpb25zIHx8IHt9O1xuICAgIG9wdGlvbnMuZGVsZWdhdGlvbiA9IG9wdGlvbnMuZGVsZWdhdGlvbiAmJiAkLmlzRnVuY3Rpb24oJC5mbi5vbik7XG5cbiAgICAvLyBpbiBqUXVlcnkgMS4zKyB3ZSBjYW4gZml4IG1pc3Rha2VzIHdpdGggdGhlIHJlYWR5IHN0YXRlXG4gICAgaWYgKCFvcHRpb25zLmRlbGVnYXRpb24gJiYgdGhpcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdmFyIG8gPSB7IHM6IHRoaXMuc2VsZWN0b3IsIGM6IHRoaXMuY29udGV4dCB9O1xuICAgICAgICBpZiAoISQuaXNSZWFkeSAmJiBvLnMpIHtcbiAgICAgICAgICAgIGxvZygnRE9NIG5vdCByZWFkeSwgcXVldWluZyBhamF4Rm9ybScpO1xuICAgICAgICAgICAgJChmdW5jdGlvbigpIHtcbiAgICAgICAgICAgICAgICAkKG8ucyxvLmMpLmFqYXhGb3JtKG9wdGlvbnMpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgICAgICAvLyBpcyB5b3VyIERPTSByZWFkeT8gIGh0dHA6Ly9kb2NzLmpxdWVyeS5jb20vVHV0b3JpYWxzOkludHJvZHVjaW5nXyQoZG9jdW1lbnQpLnJlYWR5KClcbiAgICAgICAgbG9nKCd0ZXJtaW5hdGluZzsgemVybyBlbGVtZW50cyBmb3VuZCBieSBzZWxlY3RvcicgKyAoJC5pc1JlYWR5ID8gJycgOiAnIChET00gbm90IHJlYWR5KScpKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuXG4gICAgaWYgKCBvcHRpb25zLmRlbGVnYXRpb24gKSB7XG4gICAgICAgICQoZG9jdW1lbnQpXG4gICAgICAgICAgICAub2ZmKCdzdWJtaXQuZm9ybS1wbHVnaW4nLCB0aGlzLnNlbGVjdG9yLCBkb0FqYXhTdWJtaXQpXG4gICAgICAgICAgICAub2ZmKCdjbGljay5mb3JtLXBsdWdpbicsIHRoaXMuc2VsZWN0b3IsIGNhcHR1cmVTdWJtaXR0aW5nRWxlbWVudClcbiAgICAgICAgICAgIC5vbignc3VibWl0LmZvcm0tcGx1Z2luJywgdGhpcy5zZWxlY3Rvciwgb3B0aW9ucywgZG9BamF4U3VibWl0KVxuICAgICAgICAgICAgLm9uKCdjbGljay5mb3JtLXBsdWdpbicsIHRoaXMuc2VsZWN0b3IsIG9wdGlvbnMsIGNhcHR1cmVTdWJtaXR0aW5nRWxlbWVudCk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cblxuICAgIHJldHVybiB0aGlzLmFqYXhGb3JtVW5iaW5kKClcbiAgICAgICAgLmJpbmQoJ3N1Ym1pdC5mb3JtLXBsdWdpbicsIG9wdGlvbnMsIGRvQWpheFN1Ym1pdClcbiAgICAgICAgLmJpbmQoJ2NsaWNrLmZvcm0tcGx1Z2luJywgb3B0aW9ucywgY2FwdHVyZVN1Ym1pdHRpbmdFbGVtZW50KTtcbn07XG5cbi8vIHByaXZhdGUgZXZlbnQgaGFuZGxlcnNcbmZ1bmN0aW9uIGRvQWpheFN1Ym1pdChlKSB7XG4gICAgLypqc2hpbnQgdmFsaWR0aGlzOnRydWUgKi9cbiAgICB2YXIgb3B0aW9ucyA9IGUuZGF0YTtcbiAgICBpZiAoIWUuaXNEZWZhdWx0UHJldmVudGVkKCkpIHsgLy8gaWYgZXZlbnQgaGFzIGJlZW4gY2FuY2VsZWQsIGRvbid0IHByb2NlZWRcbiAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAkKGUudGFyZ2V0KS5hamF4U3VibWl0KG9wdGlvbnMpOyAvLyAjMzY1XG4gICAgfVxufVxuXG5mdW5jdGlvbiBjYXB0dXJlU3VibWl0dGluZ0VsZW1lbnQoZSkge1xuICAgIC8qanNoaW50IHZhbGlkdGhpczp0cnVlICovXG4gICAgdmFyIHRhcmdldCA9IGUudGFyZ2V0O1xuICAgIHZhciAkZWwgPSAkKHRhcmdldCk7XG4gICAgaWYgKCEoJGVsLmlzKFwiW3R5cGU9c3VibWl0XSxbdHlwZT1pbWFnZV1cIikpKSB7XG4gICAgICAgIC8vIGlzIHRoaXMgYSBjaGlsZCBlbGVtZW50IG9mIHRoZSBzdWJtaXQgZWw/ICAoZXg6IGEgc3BhbiB3aXRoaW4gYSBidXR0b24pXG4gICAgICAgIHZhciB0ID0gJGVsLmNsb3Nlc3QoJ1t0eXBlPXN1Ym1pdF0nKTtcbiAgICAgICAgaWYgKHQubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdGFyZ2V0ID0gdFswXTtcbiAgICB9XG4gICAgdmFyIGZvcm0gPSB0aGlzO1xuICAgIGZvcm0uY2xrID0gdGFyZ2V0O1xuICAgIGlmICh0YXJnZXQudHlwZSA9PSAnaW1hZ2UnKSB7XG4gICAgICAgIGlmIChlLm9mZnNldFggIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgZm9ybS5jbGtfeCA9IGUub2Zmc2V0WDtcbiAgICAgICAgICAgIGZvcm0uY2xrX3kgPSBlLm9mZnNldFk7XG4gICAgICAgIH0gZWxzZSBpZiAodHlwZW9mICQuZm4ub2Zmc2V0ID09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHZhciBvZmZzZXQgPSAkZWwub2Zmc2V0KCk7XG4gICAgICAgICAgICBmb3JtLmNsa194ID0gZS5wYWdlWCAtIG9mZnNldC5sZWZ0O1xuICAgICAgICAgICAgZm9ybS5jbGtfeSA9IGUucGFnZVkgLSBvZmZzZXQudG9wO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgZm9ybS5jbGtfeCA9IGUucGFnZVggLSB0YXJnZXQub2Zmc2V0TGVmdDtcbiAgICAgICAgICAgIGZvcm0uY2xrX3kgPSBlLnBhZ2VZIC0gdGFyZ2V0Lm9mZnNldFRvcDtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBjbGVhciBmb3JtIHZhcnNcbiAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkgeyBmb3JtLmNsayA9IGZvcm0uY2xrX3ggPSBmb3JtLmNsa195ID0gbnVsbDsgfSwgMTAwKTtcbn1cblxuXG4vLyBhamF4Rm9ybVVuYmluZCB1bmJpbmRzIHRoZSBldmVudCBoYW5kbGVycyB0aGF0IHdlcmUgYm91bmQgYnkgYWpheEZvcm1cbiQuZm4uYWpheEZvcm1VbmJpbmQgPSBmdW5jdGlvbigpIHtcbiAgICByZXR1cm4gdGhpcy51bmJpbmQoJ3N1Ym1pdC5mb3JtLXBsdWdpbiBjbGljay5mb3JtLXBsdWdpbicpO1xufTtcblxuLyoqXG4gKiBmb3JtVG9BcnJheSgpIGdhdGhlcnMgZm9ybSBlbGVtZW50IGRhdGEgaW50byBhbiBhcnJheSBvZiBvYmplY3RzIHRoYXQgY2FuXG4gKiBiZSBwYXNzZWQgdG8gYW55IG9mIHRoZSBmb2xsb3dpbmcgYWpheCBmdW5jdGlvbnM6ICQuZ2V0LCAkLnBvc3QsIG9yIGxvYWQuXG4gKiBFYWNoIG9iamVjdCBpbiB0aGUgYXJyYXkgaGFzIGJvdGggYSAnbmFtZScgYW5kICd2YWx1ZScgcHJvcGVydHkuICBBbiBleGFtcGxlIG9mXG4gKiBhbiBhcnJheSBmb3IgYSBzaW1wbGUgbG9naW4gZm9ybSBtaWdodCBiZTpcbiAqXG4gKiBbIHsgbmFtZTogJ3VzZXJuYW1lJywgdmFsdWU6ICdqcmVzaWcnIH0sIHsgbmFtZTogJ3Bhc3N3b3JkJywgdmFsdWU6ICdzZWNyZXQnIH0gXVxuICpcbiAqIEl0IGlzIHRoaXMgYXJyYXkgdGhhdCBpcyBwYXNzZWQgdG8gcHJlLXN1Ym1pdCBjYWxsYmFjayBmdW5jdGlvbnMgcHJvdmlkZWQgdG8gdGhlXG4gKiBhamF4U3VibWl0KCkgYW5kIGFqYXhGb3JtKCkgbWV0aG9kcy5cbiAqL1xuJC5mbi5mb3JtVG9BcnJheSA9IGZ1bmN0aW9uKHNlbWFudGljLCBlbGVtZW50cykge1xuICAgIHZhciBhID0gW107XG4gICAgaWYgKHRoaXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cblxuICAgIHZhciBmb3JtID0gdGhpc1swXTtcbiAgICB2YXIgZm9ybUlkID0gdGhpcy5hdHRyKCdpZCcpO1xuICAgIHZhciBlbHMgPSBzZW1hbnRpYyA/IGZvcm0uZ2V0RWxlbWVudHNCeVRhZ05hbWUoJyonKSA6IGZvcm0uZWxlbWVudHM7XG4gICAgdmFyIGVsczI7XG5cbiAgICBpZiAoZWxzICYmICEvTVNJRSBbNjc4XS8udGVzdChuYXZpZ2F0b3IudXNlckFnZW50KSkgeyAvLyAjMzkwXG4gICAgICAgIGVscyA9ICQoZWxzKS5nZXQoKTsgIC8vIGNvbnZlcnQgdG8gc3RhbmRhcmQgYXJyYXlcbiAgICB9XG5cbiAgICAvLyAjMzg2OyBhY2NvdW50IGZvciBpbnB1dHMgb3V0c2lkZSB0aGUgZm9ybSB3aGljaCB1c2UgdGhlICdmb3JtJyBhdHRyaWJ1dGVcbiAgICBpZiAoIGZvcm1JZCApIHtcbiAgICAgICAgZWxzMiA9ICQoJzppbnB1dFtmb3JtPVwiJyArIGZvcm1JZCArICdcIl0nKS5nZXQoKTsgLy8gaGF0IHRpcCBAdGhldFxuICAgICAgICBpZiAoIGVsczIubGVuZ3RoICkge1xuICAgICAgICAgICAgZWxzID0gKGVscyB8fCBbXSkuY29uY2F0KGVsczIpO1xuICAgICAgICB9XG4gICAgfVxuXG4gICAgaWYgKCFlbHMgfHwgIWVscy5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIGE7XG4gICAgfVxuXG4gICAgdmFyIGksaixuLHYsZWwsbWF4LGptYXg7XG4gICAgZm9yKGk9MCwgbWF4PWVscy5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICBlbCA9IGVsc1tpXTtcbiAgICAgICAgbiA9IGVsLm5hbWU7XG4gICAgICAgIGlmICghbiB8fCBlbC5kaXNhYmxlZCkge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoc2VtYW50aWMgJiYgZm9ybS5jbGsgJiYgZWwudHlwZSA9PSBcImltYWdlXCIpIHtcbiAgICAgICAgICAgIC8vIGhhbmRsZSBpbWFnZSBpbnB1dHMgb24gdGhlIGZseSB3aGVuIHNlbWFudGljID09IHRydWVcbiAgICAgICAgICAgIGlmKGZvcm0uY2xrID09IGVsKSB7XG4gICAgICAgICAgICAgICAgYS5wdXNoKHtuYW1lOiBuLCB2YWx1ZTogJChlbCkudmFsKCksIHR5cGU6IGVsLnR5cGUgfSk7XG4gICAgICAgICAgICAgICAgYS5wdXNoKHtuYW1lOiBuKycueCcsIHZhbHVlOiBmb3JtLmNsa194fSwge25hbWU6IG4rJy55JywgdmFsdWU6IGZvcm0uY2xrX3l9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICB9XG5cbiAgICAgICAgdiA9ICQuZmllbGRWYWx1ZShlbCwgdHJ1ZSk7XG4gICAgICAgIGlmICh2ICYmIHYuY29uc3RydWN0b3IgPT0gQXJyYXkpIHtcbiAgICAgICAgICAgIGlmIChlbGVtZW50cykge1xuICAgICAgICAgICAgICAgIGVsZW1lbnRzLnB1c2goZWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZm9yKGo9MCwgam1heD12Lmxlbmd0aDsgaiA8IGptYXg7IGorKykge1xuICAgICAgICAgICAgICAgIGEucHVzaCh7bmFtZTogbiwgdmFsdWU6IHZbal19KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChmZWF0dXJlLmZpbGVhcGkgJiYgZWwudHlwZSA9PSAnZmlsZScpIHtcbiAgICAgICAgICAgIGlmIChlbGVtZW50cykge1xuICAgICAgICAgICAgICAgIGVsZW1lbnRzLnB1c2goZWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdmFyIGZpbGVzID0gZWwuZmlsZXM7XG4gICAgICAgICAgICBpZiAoZmlsZXMubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgZm9yIChqPTA7IGogPCBmaWxlcy5sZW5ndGg7IGorKykge1xuICAgICAgICAgICAgICAgICAgICBhLnB1c2goe25hbWU6IG4sIHZhbHVlOiBmaWxlc1tqXSwgdHlwZTogZWwudHlwZX0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIC8vICMxODBcbiAgICAgICAgICAgICAgICBhLnB1c2goeyBuYW1lOiBuLCB2YWx1ZTogJycsIHR5cGU6IGVsLnR5cGUgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodiAhPT0gbnVsbCAmJiB0eXBlb2YgdiAhPSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgaWYgKGVsZW1lbnRzKSB7XG4gICAgICAgICAgICAgICAgZWxlbWVudHMucHVzaChlbCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBhLnB1c2goe25hbWU6IG4sIHZhbHVlOiB2LCB0eXBlOiBlbC50eXBlLCByZXF1aXJlZDogZWwucmVxdWlyZWR9KTtcbiAgICAgICAgfVxuICAgIH1cblxuICAgIGlmICghc2VtYW50aWMgJiYgZm9ybS5jbGspIHtcbiAgICAgICAgLy8gaW5wdXQgdHlwZT09J2ltYWdlJyBhcmUgbm90IGZvdW5kIGluIGVsZW1lbnRzIGFycmF5ISBoYW5kbGUgaXQgaGVyZVxuICAgICAgICB2YXIgJGlucHV0ID0gJChmb3JtLmNsayksIGlucHV0ID0gJGlucHV0WzBdO1xuICAgICAgICBuID0gaW5wdXQubmFtZTtcbiAgICAgICAgaWYgKG4gJiYgIWlucHV0LmRpc2FibGVkICYmIGlucHV0LnR5cGUgPT0gJ2ltYWdlJykge1xuICAgICAgICAgICAgYS5wdXNoKHtuYW1lOiBuLCB2YWx1ZTogJGlucHV0LnZhbCgpfSk7XG4gICAgICAgICAgICBhLnB1c2goe25hbWU6IG4rJy54JywgdmFsdWU6IGZvcm0uY2xrX3h9LCB7bmFtZTogbisnLnknLCB2YWx1ZTogZm9ybS5jbGtfeX0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBhO1xufTtcblxuLyoqXG4gKiBTZXJpYWxpemVzIGZvcm0gZGF0YSBpbnRvIGEgJ3N1Ym1pdHRhYmxlJyBzdHJpbmcuIFRoaXMgbWV0aG9kIHdpbGwgcmV0dXJuIGEgc3RyaW5nXG4gKiBpbiB0aGUgZm9ybWF0OiBuYW1lMT12YWx1ZTEmYW1wO25hbWUyPXZhbHVlMlxuICovXG4kLmZuLmZvcm1TZXJpYWxpemUgPSBmdW5jdGlvbihzZW1hbnRpYykge1xuICAgIC8vaGFuZCBvZmYgdG8galF1ZXJ5LnBhcmFtIGZvciBwcm9wZXIgZW5jb2RpbmdcbiAgICByZXR1cm4gJC5wYXJhbSh0aGlzLmZvcm1Ub0FycmF5KHNlbWFudGljKSk7XG59O1xuXG4vKipcbiAqIFNlcmlhbGl6ZXMgYWxsIGZpZWxkIGVsZW1lbnRzIGluIHRoZSBqUXVlcnkgb2JqZWN0IGludG8gYSBxdWVyeSBzdHJpbmcuXG4gKiBUaGlzIG1ldGhvZCB3aWxsIHJldHVybiBhIHN0cmluZyBpbiB0aGUgZm9ybWF0OiBuYW1lMT12YWx1ZTEmYW1wO25hbWUyPXZhbHVlMlxuICovXG4kLmZuLmZpZWxkU2VyaWFsaXplID0gZnVuY3Rpb24oc3VjY2Vzc2Z1bCkge1xuICAgIHZhciBhID0gW107XG4gICAgdGhpcy5lYWNoKGZ1bmN0aW9uKCkge1xuICAgICAgICB2YXIgbiA9IHRoaXMubmFtZTtcbiAgICAgICAgaWYgKCFuKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHYgPSAkLmZpZWxkVmFsdWUodGhpcywgc3VjY2Vzc2Z1bCk7XG4gICAgICAgIGlmICh2ICYmIHYuY29uc3RydWN0b3IgPT0gQXJyYXkpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGk9MCxtYXg9di5sZW5ndGg7IGkgPCBtYXg7IGkrKykge1xuICAgICAgICAgICAgICAgIGEucHVzaCh7bmFtZTogbiwgdmFsdWU6IHZbaV19KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh2ICE9PSBudWxsICYmIHR5cGVvZiB2ICE9ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBhLnB1c2goe25hbWU6IHRoaXMubmFtZSwgdmFsdWU6IHZ9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIC8vaGFuZCBvZmYgdG8galF1ZXJ5LnBhcmFtIGZvciBwcm9wZXIgZW5jb2RpbmdcbiAgICByZXR1cm4gJC5wYXJhbShhKTtcbn07XG5cbi8qKlxuICogUmV0dXJucyB0aGUgdmFsdWUocykgb2YgdGhlIGVsZW1lbnQgaW4gdGhlIG1hdGNoZWQgc2V0LiAgRm9yIGV4YW1wbGUsIGNvbnNpZGVyIHRoZSBmb2xsb3dpbmcgZm9ybTpcbiAqXG4gKiAgPGZvcm0+PGZpZWxkc2V0PlxuICogICAgICA8aW5wdXQgbmFtZT1cIkFcIiB0eXBlPVwidGV4dFwiIC8+XG4gKiAgICAgIDxpbnB1dCBuYW1lPVwiQVwiIHR5cGU9XCJ0ZXh0XCIgLz5cbiAqICAgICAgPGlucHV0IG5hbWU9XCJCXCIgdHlwZT1cImNoZWNrYm94XCIgdmFsdWU9XCJCMVwiIC8+XG4gKiAgICAgIDxpbnB1dCBuYW1lPVwiQlwiIHR5cGU9XCJjaGVja2JveFwiIHZhbHVlPVwiQjJcIi8+XG4gKiAgICAgIDxpbnB1dCBuYW1lPVwiQ1wiIHR5cGU9XCJyYWRpb1wiIHZhbHVlPVwiQzFcIiAvPlxuICogICAgICA8aW5wdXQgbmFtZT1cIkNcIiB0eXBlPVwicmFkaW9cIiB2YWx1ZT1cIkMyXCIgLz5cbiAqICA8L2ZpZWxkc2V0PjwvZm9ybT5cbiAqXG4gKiAgdmFyIHYgPSAkKCdpbnB1dFt0eXBlPXRleHRdJykuZmllbGRWYWx1ZSgpO1xuICogIC8vIGlmIG5vIHZhbHVlcyBhcmUgZW50ZXJlZCBpbnRvIHRoZSB0ZXh0IGlucHV0c1xuICogIHYgPT0gWycnLCcnXVxuICogIC8vIGlmIHZhbHVlcyBlbnRlcmVkIGludG8gdGhlIHRleHQgaW5wdXRzIGFyZSAnZm9vJyBhbmQgJ2JhcidcbiAqICB2ID09IFsnZm9vJywnYmFyJ11cbiAqXG4gKiAgdmFyIHYgPSAkKCdpbnB1dFt0eXBlPWNoZWNrYm94XScpLmZpZWxkVmFsdWUoKTtcbiAqICAvLyBpZiBuZWl0aGVyIGNoZWNrYm94IGlzIGNoZWNrZWRcbiAqICB2ID09PSB1bmRlZmluZWRcbiAqICAvLyBpZiBib3RoIGNoZWNrYm94ZXMgYXJlIGNoZWNrZWRcbiAqICB2ID09IFsnQjEnLCAnQjInXVxuICpcbiAqICB2YXIgdiA9ICQoJ2lucHV0W3R5cGU9cmFkaW9dJykuZmllbGRWYWx1ZSgpO1xuICogIC8vIGlmIG5laXRoZXIgcmFkaW8gaXMgY2hlY2tlZFxuICogIHYgPT09IHVuZGVmaW5lZFxuICogIC8vIGlmIGZpcnN0IHJhZGlvIGlzIGNoZWNrZWRcbiAqICB2ID09IFsnQzEnXVxuICpcbiAqIFRoZSBzdWNjZXNzZnVsIGFyZ3VtZW50IGNvbnRyb2xzIHdoZXRoZXIgb3Igbm90IHRoZSBmaWVsZCBlbGVtZW50IG11c3QgYmUgJ3N1Y2Nlc3NmdWwnXG4gKiAocGVyIGh0dHA6Ly93d3cudzMub3JnL1RSL2h0bWw0L2ludGVyYWN0L2Zvcm1zLmh0bWwjc3VjY2Vzc2Z1bC1jb250cm9scykuXG4gKiBUaGUgZGVmYXVsdCB2YWx1ZSBvZiB0aGUgc3VjY2Vzc2Z1bCBhcmd1bWVudCBpcyB0cnVlLiAgSWYgdGhpcyB2YWx1ZSBpcyBmYWxzZSB0aGUgdmFsdWUocylcbiAqIGZvciBlYWNoIGVsZW1lbnQgaXMgcmV0dXJuZWQuXG4gKlxuICogTm90ZTogVGhpcyBtZXRob2QgKmFsd2F5cyogcmV0dXJucyBhbiBhcnJheS4gIElmIG5vIHZhbGlkIHZhbHVlIGNhbiBiZSBkZXRlcm1pbmVkIHRoZVxuICogICAgYXJyYXkgd2lsbCBiZSBlbXB0eSwgb3RoZXJ3aXNlIGl0IHdpbGwgY29udGFpbiBvbmUgb3IgbW9yZSB2YWx1ZXMuXG4gKi9cbiQuZm4uZmllbGRWYWx1ZSA9IGZ1bmN0aW9uKHN1Y2Nlc3NmdWwpIHtcbiAgICBmb3IgKHZhciB2YWw9W10sIGk9MCwgbWF4PXRoaXMubGVuZ3RoOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgdmFyIGVsID0gdGhpc1tpXTtcbiAgICAgICAgdmFyIHYgPSAkLmZpZWxkVmFsdWUoZWwsIHN1Y2Nlc3NmdWwpO1xuICAgICAgICBpZiAodiA9PT0gbnVsbCB8fCB0eXBlb2YgdiA9PSAndW5kZWZpbmVkJyB8fCAodi5jb25zdHJ1Y3RvciA9PSBBcnJheSAmJiAhdi5sZW5ndGgpKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodi5jb25zdHJ1Y3RvciA9PSBBcnJheSkge1xuICAgICAgICAgICAgJC5tZXJnZSh2YWwsIHYpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdmFsLnB1c2godik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHZhbDtcbn07XG5cbi8qKlxuICogUmV0dXJucyB0aGUgdmFsdWUgb2YgdGhlIGZpZWxkIGVsZW1lbnQuXG4gKi9cbiQuZmllbGRWYWx1ZSA9IGZ1bmN0aW9uKGVsLCBzdWNjZXNzZnVsKSB7XG4gICAgdmFyIG4gPSBlbC5uYW1lLCB0ID0gZWwudHlwZSwgdGFnID0gZWwudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgIGlmIChzdWNjZXNzZnVsID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgc3VjY2Vzc2Z1bCA9IHRydWU7XG4gICAgfVxuXG4gICAgaWYgKHN1Y2Nlc3NmdWwgJiYgKCFuIHx8IGVsLmRpc2FibGVkIHx8IHQgPT0gJ3Jlc2V0JyB8fCB0ID09ICdidXR0b24nIHx8XG4gICAgICAgICh0ID09ICdjaGVja2JveCcgfHwgdCA9PSAncmFkaW8nKSAmJiAhZWwuY2hlY2tlZCB8fFxuICAgICAgICAodCA9PSAnc3VibWl0JyB8fCB0ID09ICdpbWFnZScpICYmIGVsLmZvcm0gJiYgZWwuZm9ybS5jbGsgIT0gZWwgfHxcbiAgICAgICAgdGFnID09ICdzZWxlY3QnICYmIGVsLnNlbGVjdGVkSW5kZXggPT0gLTEpKSB7XG4gICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG5cbiAgICBpZiAodGFnID09ICdzZWxlY3QnKSB7XG4gICAgICAgIHZhciBpbmRleCA9IGVsLnNlbGVjdGVkSW5kZXg7XG4gICAgICAgIGlmIChpbmRleCA8IDApIHtcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICB9XG4gICAgICAgIHZhciBhID0gW10sIG9wcyA9IGVsLm9wdGlvbnM7XG4gICAgICAgIHZhciBvbmUgPSAodCA9PSAnc2VsZWN0LW9uZScpO1xuICAgICAgICB2YXIgbWF4ID0gKG9uZSA/IGluZGV4KzEgOiBvcHMubGVuZ3RoKTtcbiAgICAgICAgZm9yKHZhciBpPShvbmUgPyBpbmRleCA6IDApOyBpIDwgbWF4OyBpKyspIHtcbiAgICAgICAgICAgIHZhciBvcCA9IG9wc1tpXTtcbiAgICAgICAgICAgIGlmIChvcC5zZWxlY3RlZCkge1xuICAgICAgICAgICAgICAgIHZhciB2ID0gb3AudmFsdWU7XG4gICAgICAgICAgICAgICAgaWYgKCF2KSB7IC8vIGV4dHJhIHBhaW4gZm9yIElFLi4uXG4gICAgICAgICAgICAgICAgICAgIHYgPSAob3AuYXR0cmlidXRlcyAmJiBvcC5hdHRyaWJ1dGVzLnZhbHVlICYmICEob3AuYXR0cmlidXRlcy52YWx1ZS5zcGVjaWZpZWQpKSA/IG9wLnRleHQgOiBvcC52YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKG9uZSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgYS5wdXNoKHYpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhO1xuICAgIH1cbiAgICByZXR1cm4gJChlbCkudmFsKCk7XG59O1xuXG4vKipcbiAqIENsZWFycyB0aGUgZm9ybSBkYXRhLiAgVGFrZXMgdGhlIGZvbGxvd2luZyBhY3Rpb25zIG9uIHRoZSBmb3JtJ3MgaW5wdXQgZmllbGRzOlxuICogIC0gaW5wdXQgdGV4dCBmaWVsZHMgd2lsbCBoYXZlIHRoZWlyICd2YWx1ZScgcHJvcGVydHkgc2V0IHRvIHRoZSBlbXB0eSBzdHJpbmdcbiAqICAtIHNlbGVjdCBlbGVtZW50cyB3aWxsIGhhdmUgdGhlaXIgJ3NlbGVjdGVkSW5kZXgnIHByb3BlcnR5IHNldCB0byAtMVxuICogIC0gY2hlY2tib3ggYW5kIHJhZGlvIGlucHV0cyB3aWxsIGhhdmUgdGhlaXIgJ2NoZWNrZWQnIHByb3BlcnR5IHNldCB0byBmYWxzZVxuICogIC0gaW5wdXRzIG9mIHR5cGUgc3VibWl0LCBidXR0b24sIHJlc2V0LCBhbmQgaGlkZGVuIHdpbGwgKm5vdCogYmUgZWZmZWN0ZWRcbiAqICAtIGJ1dHRvbiBlbGVtZW50cyB3aWxsICpub3QqIGJlIGVmZmVjdGVkXG4gKi9cbiQuZm4uY2xlYXJGb3JtID0gZnVuY3Rpb24oaW5jbHVkZUhpZGRlbikge1xuICAgIHJldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgICQoJ2lucHV0LHNlbGVjdCx0ZXh0YXJlYScsIHRoaXMpLmNsZWFyRmllbGRzKGluY2x1ZGVIaWRkZW4pO1xuICAgIH0pO1xufTtcblxuLyoqXG4gKiBDbGVhcnMgdGhlIHNlbGVjdGVkIGZvcm0gZWxlbWVudHMuXG4gKi9cbiQuZm4uY2xlYXJGaWVsZHMgPSAkLmZuLmNsZWFySW5wdXRzID0gZnVuY3Rpb24oaW5jbHVkZUhpZGRlbikge1xuICAgIHZhciByZSA9IC9eKD86Y29sb3J8ZGF0ZXxkYXRldGltZXxlbWFpbHxtb250aHxudW1iZXJ8cGFzc3dvcmR8cmFuZ2V8c2VhcmNofHRlbHx0ZXh0fHRpbWV8dXJsfHdlZWspJC9pOyAvLyAnaGlkZGVuJyBpcyBub3QgaW4gdGhpcyBsaXN0XG4gICAgcmV0dXJuIHRoaXMuZWFjaChmdW5jdGlvbigpIHtcbiAgICAgICAgdmFyIHQgPSB0aGlzLnR5cGUsIHRhZyA9IHRoaXMudGFnTmFtZS50b0xvd2VyQ2FzZSgpO1xuICAgICAgICBpZiAocmUudGVzdCh0KSB8fCB0YWcgPT0gJ3RleHRhcmVhJykge1xuICAgICAgICAgICAgdGhpcy52YWx1ZSA9ICcnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHQgPT0gJ2NoZWNrYm94JyB8fCB0ID09ICdyYWRpbycpIHtcbiAgICAgICAgICAgIHRoaXMuY2hlY2tlZCA9IGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRhZyA9PSAnc2VsZWN0Jykge1xuICAgICAgICAgICAgdGhpcy5zZWxlY3RlZEluZGV4ID0gLTE7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodCA9PSBcImZpbGVcIikge1xuICAgICAgICAgICAgaWYgKC9NU0lFLy50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpKSB7XG4gICAgICAgICAgICAgICAgJCh0aGlzKS5yZXBsYWNlV2l0aCgkKHRoaXMpLmNsb25lKHRydWUpKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgJCh0aGlzKS52YWwoJycpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGluY2x1ZGVIaWRkZW4pIHtcbiAgICAgICAgICAgIC8vIGluY2x1ZGVIaWRkZW4gY2FuIGJlIHRoZSB2YWx1ZSB0cnVlLCBvciBpdCBjYW4gYmUgYSBzZWxlY3RvciBzdHJpbmdcbiAgICAgICAgICAgIC8vIGluZGljYXRpbmcgYSBzcGVjaWFsIHRlc3Q7IGZvciBleGFtcGxlOlxuICAgICAgICAgICAgLy8gICQoJyNteUZvcm0nKS5jbGVhckZvcm0oJy5zcGVjaWFsOmhpZGRlbicpXG4gICAgICAgICAgICAvLyB0aGUgYWJvdmUgd291bGQgY2xlYW4gaGlkZGVuIGlucHV0cyB0aGF0IGhhdmUgdGhlIGNsYXNzIG9mICdzcGVjaWFsJ1xuICAgICAgICAgICAgaWYgKCAoaW5jbHVkZUhpZGRlbiA9PT0gdHJ1ZSAmJiAvaGlkZGVuLy50ZXN0KHQpKSB8fFxuICAgICAgICAgICAgICAgICAodHlwZW9mIGluY2x1ZGVIaWRkZW4gPT0gJ3N0cmluZycgJiYgJCh0aGlzKS5pcyhpbmNsdWRlSGlkZGVuKSkgKSB7XG4gICAgICAgICAgICAgICAgdGhpcy52YWx1ZSA9ICcnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSk7XG59O1xuXG4vKipcbiAqIFJlc2V0cyB0aGUgZm9ybSBkYXRhLiAgQ2F1c2VzIGFsbCBmb3JtIGVsZW1lbnRzIHRvIGJlIHJlc2V0IHRvIHRoZWlyIG9yaWdpbmFsIHZhbHVlLlxuICovXG4kLmZuLnJlc2V0Rm9ybSA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgIC8vIGd1YXJkIGFnYWluc3QgYW4gaW5wdXQgd2l0aCB0aGUgbmFtZSBvZiAncmVzZXQnXG4gICAgICAgIC8vIG5vdGUgdGhhdCBJRSByZXBvcnRzIHRoZSByZXNldCBmdW5jdGlvbiBhcyBhbiAnb2JqZWN0J1xuICAgICAgICBpZiAodHlwZW9mIHRoaXMucmVzZXQgPT0gJ2Z1bmN0aW9uJyB8fCAodHlwZW9mIHRoaXMucmVzZXQgPT0gJ29iamVjdCcgJiYgIXRoaXMucmVzZXQubm9kZVR5cGUpKSB7XG4gICAgICAgICAgICB0aGlzLnJlc2V0KCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5cbi8qKlxuICogRW5hYmxlcyBvciBkaXNhYmxlcyBhbnkgbWF0Y2hpbmcgZWxlbWVudHMuXG4gKi9cbiQuZm4uZW5hYmxlID0gZnVuY3Rpb24oYikge1xuICAgIGlmIChiID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgYiA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgIHRoaXMuZGlzYWJsZWQgPSAhYjtcbiAgICB9KTtcbn07XG5cbi8qKlxuICogQ2hlY2tzL3VuY2hlY2tzIGFueSBtYXRjaGluZyBjaGVja2JveGVzIG9yIHJhZGlvIGJ1dHRvbnMgYW5kXG4gKiBzZWxlY3RzL2Rlc2VsZWN0cyBhbmQgbWF0Y2hpbmcgb3B0aW9uIGVsZW1lbnRzLlxuICovXG4kLmZuLnNlbGVjdGVkID0gZnVuY3Rpb24oc2VsZWN0KSB7XG4gICAgaWYgKHNlbGVjdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHNlbGVjdCA9IHRydWU7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLmVhY2goZnVuY3Rpb24oKSB7XG4gICAgICAgIHZhciB0ID0gdGhpcy50eXBlO1xuICAgICAgICBpZiAodCA9PSAnY2hlY2tib3gnIHx8IHQgPT0gJ3JhZGlvJykge1xuICAgICAgICAgICAgdGhpcy5jaGVja2VkID0gc2VsZWN0O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMudGFnTmFtZS50b0xvd2VyQ2FzZSgpID09ICdvcHRpb24nKSB7XG4gICAgICAgICAgICB2YXIgJHNlbCA9ICQodGhpcykucGFyZW50KCdzZWxlY3QnKTtcbiAgICAgICAgICAgIGlmIChzZWxlY3QgJiYgJHNlbFswXSAmJiAkc2VsWzBdLnR5cGUgPT0gJ3NlbGVjdC1vbmUnKSB7XG4gICAgICAgICAgICAgICAgLy8gZGVzZWxlY3QgYWxsIG90aGVyIG9wdGlvbnNcbiAgICAgICAgICAgICAgICAkc2VsLmZpbmQoJ29wdGlvbicpLnNlbGVjdGVkKGZhbHNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRoaXMuc2VsZWN0ZWQgPSBzZWxlY3Q7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5cbi8vIGV4cG9zZSBkZWJ1ZyB2YXJcbiQuZm4uYWpheFN1Ym1pdC5kZWJ1ZyA9IGZhbHNlO1xuXG4vLyBoZWxwZXIgZm4gZm9yIGNvbnNvbGUgbG9nZ2luZ1xuZnVuY3Rpb24gbG9nKCkge1xuICAgIGlmICghJC5mbi5hamF4U3VibWl0LmRlYnVnKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIG1zZyA9ICdbanF1ZXJ5LmZvcm1dICcgKyBBcnJheS5wcm90b3R5cGUuam9pbi5jYWxsKGFyZ3VtZW50cywnJyk7XG4gICAgaWYgKHdpbmRvdy5jb25zb2xlICYmIHdpbmRvdy5jb25zb2xlLmxvZykge1xuICAgICAgICB3aW5kb3cuY29uc29sZS5sb2cobXNnKTtcbiAgICB9XG4gICAgZWxzZSBpZiAod2luZG93Lm9wZXJhICYmIHdpbmRvdy5vcGVyYS5wb3N0RXJyb3IpIHtcbiAgICAgICAgd2luZG93Lm9wZXJhLnBvc3RFcnJvcihtc2cpO1xuICAgIH1cbn1cblxufSkpO1xuIiwiLyoqXG4gKiBbalF1ZXJ5LWxhenlsb2FkLWFueV17QGxpbmsgaHR0cHM6Ly9naXRodWIuY29tL2VtbjE3OC9qcXVlcnktbGF6eWxvYWQtYW55fVxuICpcbiAqIEB2ZXJzaW9uIDAuMy4wXG4gKiBAYXV0aG9yIFlpLUN5dWFuIENoZW4gW2VtbjE3OEBnbWFpbC5jb21dXG4gKiBAY29weXJpZ2h0IFlpLUN5dWFuIENoZW4gMjAxNC0yMDE2XG4gKiBAbGljZW5zZSBNSVRcbiAqL1xuKGZ1bmN0aW9uKGQsayxsKXtmdW5jdGlvbiBtKCl7dmFyIGE9ZCh0aGlzKSxjO2lmKGM9YS5pcyhcIjp2aXNpYmxlXCIpKXtjPWFbMF0uZ2V0Qm91bmRpbmdDbGllbnRSZWN0KCk7dmFyIGI9LWEuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnlcIikudGhyZXNob2xkLGU9bi1iLGY9cC1iO2M9KGMudG9wPj1iJiZjLnRvcDw9ZXx8Yy5ib3R0b20+PWImJmMuYm90dG9tPD1lKSYmKGMubGVmdD49YiYmYy5sZWZ0PD1mfHxjLnJpZ2h0Pj1iJiZjLnJpZ2h0PD1mKX1jJiZhLnRyaWdnZXIoXCJhcHBlYXJcIil9ZnVuY3Rpb24gcSgpe249ay5pbm5lckhlaWdodHx8bC5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0O3A9ay5pbm5lcldpZHRofHxsLmRvY3VtZW50RWxlbWVudC5jbGllbnRXaWR0aDtnKCl9ZnVuY3Rpb24gZygpe2g9aC5maWx0ZXIoXCI6anF1ZXJ5LWxhenlsb2FkLWFueS1hcHBlYXJcIik7MT09dGhpcy5ub2RlVHlwZT9kKHRoaXMpLmZpbmQoXCI6anF1ZXJ5LWxhenlsb2FkLWFueS1hcHBlYXJcIikuZWFjaChtKTpcbmguZWFjaChtKX1mdW5jdGlvbiB2KCl7dmFyIGE9ZCh0aGlzKSxjPWEuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnlcIiksYj1hLmRhdGEoXCJsYXp5bG9hZFwiKTtifHwoYj1hLmNoaWxkcmVuKCkuZmlsdGVyKCdzY3JpcHRbdHlwZT1cInRleHQvbGF6eWxvYWRcIl0nKS5nZXQoMCksYj1kKGIpLmh0bWwoKSk7Ynx8KGI9KGI9YS5jb250ZW50cygpLmZpbHRlcihmdW5jdGlvbigpe3JldHVybiA4PT09dGhpcy5ub2RlVHlwZX0pLmdldCgwKSkmJmQudHJpbShiLmRhdGEpKTtiPXcuaHRtbChiKS5jb250ZW50cygpO2EucmVwbGFjZVdpdGgoYik7ZC5pc0Z1bmN0aW9uKGMubG9hZCkmJmMubG9hZC5jYWxsKGIsYil9ZnVuY3Rpb24gcigpe3ZhciBhPWQodGhpcyksYzthLmRhdGEoXCJqcXVlcnktbGF6eWxvYWQtYW55LXNjcm9sbGVyXCIpP2M9ITE6KGM9YS5jc3MoXCJvdmVyZmxvd1wiKSxcInNjcm9sbFwiIT1jJiZcImF1dG9cIiE9Yz9jPSExOihhLmRhdGEoXCJqcXVlcnktbGF6eWxvYWQtYW55LXNjcm9sbGVyXCIsXG4xKSxhLmJpbmQoXCJzY3JvbGxcIixnKSxjPSEwKSk7dmFyIGI7YS5kYXRhKFwianF1ZXJ5LWxhenlsb2FkLWFueS1kaXNwbGF5XCIpP2I9dm9pZCAwOlwibm9uZVwiIT1hLmNzcyhcImRpc3BsYXlcIik/Yj12b2lkIDA6KGEuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktZGlzcGxheVwiLDEpLGEuX2JpbmRTaG93KGcpLGI9ITApO2N8YiYmIWEuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktd2F0Y2hcIikmJihhLmRhdGEoXCJqcXVlcnktbGF6eWxvYWQtYW55LXdhdGNoXCIsMSksYS5iaW5kKFwiYXBwZWFyXCIsdCkpfWZ1bmN0aW9uIHQoKXt2YXIgYT1kKHRoaXMpOzA9PT1hLmZpbmQoXCI6anF1ZXJ5LWxhenlsb2FkLWFueS1hcHBlYXJcIikubGVuZ3RoJiYoYS5yZW1vdmVEYXRhKFwianF1ZXJ5LWxhenlsb2FkLWFueS1zY3JvbGxlclwiKS5yZW1vdmVEYXRhKFwianF1ZXJ5LWxhenlsb2FkLWFueS1kaXNwbGF5XCIpLnJlbW92ZURhdGEoXCJqcXVlcnktbGF6eWxvYWQtYW55LXdhdGNoXCIpLGEudW5iaW5kKFwic2Nyb2xsXCIsXG5nKS51bmJpbmQoXCJhcHBlYXJcIix0KS5fdW5iaW5kU2hvdyhnKSl9dmFyIHc9ZChcIjxkaXYvPlwiKSxuLHAsdT0hMSxoPWQoKTtkLmV4cHJbXCI6XCJdW1wianF1ZXJ5LWxhenlsb2FkLWFueS1hcHBlYXJcIl09ZnVuY3Rpb24oYSl7cmV0dXJuIHZvaWQgMCE9PWQoYSkuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktYXBwZWFyXCIpfTtkLmZuLmxhenlsb2FkPWZ1bmN0aW9uKGEpe3ZhciBjPXt0aHJlc2hvbGQ6MCx0cmlnZ2VyOlwiYXBwZWFyXCJ9O2QuZXh0ZW5kKGMsYSk7YT1jLnRyaWdnZXIuc3BsaXQoXCIgXCIpO3RoaXMuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktYXBwZWFyXCIsLTEhPWQuaW5BcnJheShcImFwcGVhclwiLGEpKS5kYXRhKFwianF1ZXJ5LWxhenlsb2FkLWFueVwiLGMpO3RoaXMuYmluZChjLnRyaWdnZXIsdik7dGhpcy5lYWNoKG0pO3RoaXMucGFyZW50cygpLmVhY2gocik7dGhpcy5lYWNoKGZ1bmN0aW9uKCl7aD1oLmFkZCh0aGlzKX0pO3V8fCh1PSEwLHEoKSxkKGwpLnJlYWR5KGZ1bmN0aW9uKCl7ZChrKS5iaW5kKFwicmVzaXplXCIsXG5xKS5iaW5kKFwic2Nyb2xsXCIsZyl9KSk7cmV0dXJuIHRoaXN9O2QubGF6eWxvYWQ9e2NoZWNrOmcscmVmcmVzaDpmdW5jdGlvbihhKXsodm9pZCAwPT09YT9oOmQoYSkpLmVhY2goZnVuY3Rpb24oKXt2YXIgYT1kKHRoaXMpO2EuaXMoXCI6anF1ZXJ5LWxhenlsb2FkLWFueS1hcHBlYXJcIikmJmEucGFyZW50cygpLmVhY2gocil9KX19OyhmdW5jdGlvbigpe2Z1bmN0aW9uIGEoKXt2YXIgYT1kKHRoaXMpLGI9XCJub25lXCIhPWEuY3NzKFwiZGlzcGxheVwiKTthLmRhdGEoXCJqcXVlcnktbGF6eWxvYWQtYW55LXNob3dcIikhPWImJihhLmRhdGEoXCJqcXVlcnktbGF6eWxvYWQtYW55LXNob3dcIixiKSxiJiZhLnRyaWdnZXIoXCJzaG93XCIpKX1mdW5jdGlvbiBjKCl7Zj1mLmZpbHRlcihcIjpqcXVlcnktbGF6eWxvYWQtYW55LXNob3dcIik7Zi5lYWNoKGEpOzA9PT1mLmxlbmd0aCYmKGU9Y2xlYXJJbnRlcnZhbChlKSl9dmFyIGI9NTAsZSxmPWQoKTtkLmV4cHJbXCI6XCJdW1wianF1ZXJ5LWxhenlsb2FkLWFueS1zaG93XCJdPVxuZnVuY3Rpb24oYSl7cmV0dXJuIHZvaWQgMCE9PWQoYSkuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktc2hvd1wiKX07ZC5mbi5fYmluZFNob3c9ZnVuY3Rpb24oYSl7dGhpcy5iaW5kKFwic2hvd1wiLGEpO3RoaXMuZGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktc2hvd1wiLFwibm9uZVwiIT10aGlzLmNzcyhcImRpc3BsYXlcIikpO2Y9Zi5hZGQodGhpcyk7YiYmIWUmJihlPXNldEludGVydmFsKGMsYikpfTtkLmZuLl91bmJpbmRTaG93PWZ1bmN0aW9uKGEpe3RoaXMudW5iaW5kKFwic2hvd1wiLGEpO3RoaXMucmVtb3ZlRGF0YShcImpxdWVyeS1sYXp5bG9hZC1hbnktc2hvd1wiKX07ZC5sYXp5bG9hZC5zZXRJbnRlcnZhbD1mdW5jdGlvbihhKXthPT1ifHwhZC5pc051bWVyaWMoYSl8fDA+YXx8KGI9YSxlPWNsZWFySW50ZXJ2YWwoZSksMDxiJiYoZT1zZXRJbnRlcnZhbChjLGIpKSl9fSkoKX0pKGpRdWVyeSx3aW5kb3csZG9jdW1lbnQpO1xuIiwiLy8gTWFnbmlmaWMgUG9wdXAgdjEuMS4wIGJ5IERtaXRyeSBTZW1lbm92XHJcbi8vIGh0dHA6Ly9iaXQubHkvbWFnbmlmaWMtcG9wdXAjYnVpbGQ9aW5saW5lK2ltYWdlK2FqYXgraWZyYW1lK2dhbGxlcnkrcmV0aW5hK2ltYWdlem9vbVxyXG4oZnVuY3Rpb24oYSl7dHlwZW9mIGRlZmluZT09XCJmdW5jdGlvblwiJiZkZWZpbmUuYW1kP2RlZmluZShbXCJqcXVlcnlcIl0sYSk6dHlwZW9mIGV4cG9ydHM9PVwib2JqZWN0XCI/YShyZXF1aXJlKFwianF1ZXJ5XCIpKTphKHdpbmRvdy5qUXVlcnl8fHdpbmRvdy5aZXB0byl9KShmdW5jdGlvbihhKXt2YXIgYj1cIkNsb3NlXCIsYz1cIkJlZm9yZUNsb3NlXCIsZD1cIkFmdGVyQ2xvc2VcIixlPVwiQmVmb3JlQXBwZW5kXCIsZj1cIk1hcmt1cFBhcnNlXCIsZz1cIk9wZW5cIixoPVwiQ2hhbmdlXCIsaT1cIm1mcFwiLGo9XCIuXCIraSxrPVwibWZwLXJlYWR5XCIsbD1cIm1mcC1yZW1vdmluZ1wiLG09XCJtZnAtcHJldmVudC1jbG9zZVwiLG4sbz1mdW5jdGlvbigpe30scD0hIXdpbmRvdy5qUXVlcnkscSxyPWEod2luZG93KSxzLHQsdSx2LHc9ZnVuY3Rpb24oYSxiKXtuLmV2Lm9uKGkrYStqLGIpfSx4PWZ1bmN0aW9uKGIsYyxkLGUpe3ZhciBmPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7cmV0dXJuIGYuY2xhc3NOYW1lPVwibWZwLVwiK2IsZCYmKGYuaW5uZXJIVE1MPWQpLGU/YyYmYy5hcHBlbmRDaGlsZChmKTooZj1hKGYpLGMmJmYuYXBwZW5kVG8oYykpLGZ9LHk9ZnVuY3Rpb24oYixjKXtuLmV2LnRyaWdnZXJIYW5kbGVyKGkrYixjKSxuLnN0LmNhbGxiYWNrcyYmKGI9Yi5jaGFyQXQoMCkudG9Mb3dlckNhc2UoKStiLnNsaWNlKDEpLG4uc3QuY2FsbGJhY2tzW2JdJiZuLnN0LmNhbGxiYWNrc1tiXS5hcHBseShuLGEuaXNBcnJheShjKT9jOltjXSkpfSx6PWZ1bmN0aW9uKGIpe2lmKGIhPT12fHwhbi5jdXJyVGVtcGxhdGUuY2xvc2VCdG4pbi5jdXJyVGVtcGxhdGUuY2xvc2VCdG49YShuLnN0LmNsb3NlTWFya3VwLnJlcGxhY2UoXCIldGl0bGUlXCIsbi5zdC50Q2xvc2UpKSx2PWI7cmV0dXJuIG4uY3VyclRlbXBsYXRlLmNsb3NlQnRufSxBPWZ1bmN0aW9uKCl7YS5tYWduaWZpY1BvcHVwLmluc3RhbmNlfHwobj1uZXcgbyxuLmluaXQoKSxhLm1hZ25pZmljUG9wdXAuaW5zdGFuY2U9bil9LEI9ZnVuY3Rpb24oKXt2YXIgYT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwicFwiKS5zdHlsZSxiPVtcIm1zXCIsXCJPXCIsXCJNb3pcIixcIldlYmtpdFwiXTtpZihhLnRyYW5zaXRpb24hPT11bmRlZmluZWQpcmV0dXJuITA7d2hpbGUoYi5sZW5ndGgpaWYoYi5wb3AoKStcIlRyYW5zaXRpb25cImluIGEpcmV0dXJuITA7cmV0dXJuITF9O28ucHJvdG90eXBlPXtjb25zdHJ1Y3RvcjpvLGluaXQ6ZnVuY3Rpb24oKXt2YXIgYj1uYXZpZ2F0b3IuYXBwVmVyc2lvbjtuLmlzTG93SUU9bi5pc0lFOD1kb2N1bWVudC5hbGwmJiFkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyLG4uaXNBbmRyb2lkPS9hbmRyb2lkL2dpLnRlc3QoYiksbi5pc0lPUz0vaXBob25lfGlwYWR8aXBvZC9naS50ZXN0KGIpLG4uc3VwcG9ydHNUcmFuc2l0aW9uPUIoKSxuLnByb2JhYmx5TW9iaWxlPW4uaXNBbmRyb2lkfHxuLmlzSU9TfHwvKE9wZXJhIE1pbmkpfEtpbmRsZXx3ZWJPU3xCbGFja0JlcnJ5fChPcGVyYSBNb2JpKXwoV2luZG93cyBQaG9uZSl8SUVNb2JpbGUvaS50ZXN0KG5hdmlnYXRvci51c2VyQWdlbnQpLHM9YShkb2N1bWVudCksbi5wb3B1cHNDYWNoZT17fX0sb3BlbjpmdW5jdGlvbihiKXt2YXIgYztpZihiLmlzT2JqPT09ITEpe24uaXRlbXM9Yi5pdGVtcy50b0FycmF5KCksbi5pbmRleD0wO3ZhciBkPWIuaXRlbXMsZTtmb3IoYz0wO2M8ZC5sZW5ndGg7YysrKXtlPWRbY10sZS5wYXJzZWQmJihlPWUuZWxbMF0pO2lmKGU9PT1iLmVsWzBdKXtuLmluZGV4PWM7YnJlYWt9fX1lbHNlIG4uaXRlbXM9YS5pc0FycmF5KGIuaXRlbXMpP2IuaXRlbXM6W2IuaXRlbXNdLG4uaW5kZXg9Yi5pbmRleHx8MDtpZihuLmlzT3Blbil7bi51cGRhdGVJdGVtSFRNTCgpO3JldHVybn1uLnR5cGVzPVtdLHU9XCJcIixiLm1haW5FbCYmYi5tYWluRWwubGVuZ3RoP24uZXY9Yi5tYWluRWwuZXEoMCk6bi5ldj1zLGIua2V5PyhuLnBvcHVwc0NhY2hlW2Iua2V5XXx8KG4ucG9wdXBzQ2FjaGVbYi5rZXldPXt9KSxuLmN1cnJUZW1wbGF0ZT1uLnBvcHVwc0NhY2hlW2Iua2V5XSk6bi5jdXJyVGVtcGxhdGU9e30sbi5zdD1hLmV4dGVuZCghMCx7fSxhLm1hZ25pZmljUG9wdXAuZGVmYXVsdHMsYiksbi5maXhlZENvbnRlbnRQb3M9bi5zdC5maXhlZENvbnRlbnRQb3M9PT1cImF1dG9cIj8hbi5wcm9iYWJseU1vYmlsZTpuLnN0LmZpeGVkQ29udGVudFBvcyxuLnN0Lm1vZGFsJiYobi5zdC5jbG9zZU9uQ29udGVudENsaWNrPSExLG4uc3QuY2xvc2VPbkJnQ2xpY2s9ITEsbi5zdC5zaG93Q2xvc2VCdG49ITEsbi5zdC5lbmFibGVFc2NhcGVLZXk9ITEpLG4uYmdPdmVybGF5fHwobi5iZ092ZXJsYXk9eChcImJnXCIpLm9uKFwiY2xpY2tcIitqLGZ1bmN0aW9uKCl7bi5jbG9zZSgpfSksbi53cmFwPXgoXCJ3cmFwXCIpLmF0dHIoXCJ0YWJpbmRleFwiLC0xKS5vbihcImNsaWNrXCIraixmdW5jdGlvbihhKXtuLl9jaGVja0lmQ2xvc2UoYS50YXJnZXQpJiZuLmNsb3NlKCl9KSxuLmNvbnRhaW5lcj14KFwiY29udGFpbmVyXCIsbi53cmFwKSksbi5jb250ZW50Q29udGFpbmVyPXgoXCJjb250ZW50XCIpLG4uc3QucHJlbG9hZGVyJiYobi5wcmVsb2FkZXI9eChcInByZWxvYWRlclwiLG4uY29udGFpbmVyLG4uc3QudExvYWRpbmcpKTt2YXIgaD1hLm1hZ25pZmljUG9wdXAubW9kdWxlcztmb3IoYz0wO2M8aC5sZW5ndGg7YysrKXt2YXIgaT1oW2NdO2k9aS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKStpLnNsaWNlKDEpLG5bXCJpbml0XCIraV0uY2FsbChuKX15KFwiQmVmb3JlT3BlblwiKSxuLnN0LnNob3dDbG9zZUJ0biYmKG4uc3QuY2xvc2VCdG5JbnNpZGU/KHcoZixmdW5jdGlvbihhLGIsYyxkKXtjLmNsb3NlX3JlcGxhY2VXaXRoPXooZC50eXBlKX0pLHUrPVwiIG1mcC1jbG9zZS1idG4taW5cIik6bi53cmFwLmFwcGVuZCh6KCkpKSxuLnN0LmFsaWduVG9wJiYodSs9XCIgbWZwLWFsaWduLXRvcFwiKSxuLmZpeGVkQ29udGVudFBvcz9uLndyYXAuY3NzKHtvdmVyZmxvdzpuLnN0Lm92ZXJmbG93WSxvdmVyZmxvd1g6XCJoaWRkZW5cIixvdmVyZmxvd1k6bi5zdC5vdmVyZmxvd1l9KTpuLndyYXAuY3NzKHt0b3A6ci5zY3JvbGxUb3AoKSxwb3NpdGlvbjpcImFic29sdXRlXCJ9KSwobi5zdC5maXhlZEJnUG9zPT09ITF8fG4uc3QuZml4ZWRCZ1Bvcz09PVwiYXV0b1wiJiYhbi5maXhlZENvbnRlbnRQb3MpJiZuLmJnT3ZlcmxheS5jc3Moe2hlaWdodDpzLmhlaWdodCgpLHBvc2l0aW9uOlwiYWJzb2x1dGVcIn0pLG4uc3QuZW5hYmxlRXNjYXBlS2V5JiZzLm9uKFwia2V5dXBcIitqLGZ1bmN0aW9uKGEpe2Eua2V5Q29kZT09PTI3JiZuLmNsb3NlKCl9KSxyLm9uKFwicmVzaXplXCIraixmdW5jdGlvbigpe24udXBkYXRlU2l6ZSgpfSksbi5zdC5jbG9zZU9uQ29udGVudENsaWNrfHwodSs9XCIgbWZwLWF1dG8tY3Vyc29yXCIpLHUmJm4ud3JhcC5hZGRDbGFzcyh1KTt2YXIgbD1uLndIPXIuaGVpZ2h0KCksbT17fTtpZihuLmZpeGVkQ29udGVudFBvcyYmbi5faGFzU2Nyb2xsQmFyKGwpKXt2YXIgbz1uLl9nZXRTY3JvbGxiYXJTaXplKCk7byYmKG0ubWFyZ2luUmlnaHQ9byl9bi5maXhlZENvbnRlbnRQb3MmJihuLmlzSUU3P2EoXCJib2R5LCBodG1sXCIpLmNzcyhcIm92ZXJmbG93XCIsXCJoaWRkZW5cIik6bS5vdmVyZmxvdz1cImhpZGRlblwiKTt2YXIgcD1uLnN0Lm1haW5DbGFzcztyZXR1cm4gbi5pc0lFNyYmKHArPVwiIG1mcC1pZTdcIikscCYmbi5fYWRkQ2xhc3NUb01GUChwKSxuLnVwZGF0ZUl0ZW1IVE1MKCkseShcIkJ1aWxkQ29udHJvbHNcIiksYShcImh0bWxcIikuY3NzKG0pLG4uYmdPdmVybGF5LmFkZChuLndyYXApLnByZXBlbmRUbyhuLnN0LnByZXBlbmRUb3x8YShkb2N1bWVudC5ib2R5KSksbi5fbGFzdEZvY3VzZWRFbD1kb2N1bWVudC5hY3RpdmVFbGVtZW50LHNldFRpbWVvdXQoZnVuY3Rpb24oKXtuLmNvbnRlbnQ/KG4uX2FkZENsYXNzVG9NRlAoayksbi5fc2V0Rm9jdXMoKSk6bi5iZ092ZXJsYXkuYWRkQ2xhc3Moaykscy5vbihcImZvY3VzaW5cIitqLG4uX29uRm9jdXNJbil9LDE2KSxuLmlzT3Blbj0hMCxuLnVwZGF0ZVNpemUobCkseShnKSxifSxjbG9zZTpmdW5jdGlvbigpe2lmKCFuLmlzT3BlbilyZXR1cm47eShjKSxuLmlzT3Blbj0hMSxuLnN0LnJlbW92YWxEZWxheSYmIW4uaXNMb3dJRSYmbi5zdXBwb3J0c1RyYW5zaXRpb24/KG4uX2FkZENsYXNzVG9NRlAobCksc2V0VGltZW91dChmdW5jdGlvbigpe24uX2Nsb3NlKCl9LG4uc3QucmVtb3ZhbERlbGF5KSk6bi5fY2xvc2UoKX0sX2Nsb3NlOmZ1bmN0aW9uKCl7eShiKTt2YXIgYz1sK1wiIFwiK2srXCIgXCI7bi5iZ092ZXJsYXkuZGV0YWNoKCksbi53cmFwLmRldGFjaCgpLG4uY29udGFpbmVyLmVtcHR5KCksbi5zdC5tYWluQ2xhc3MmJihjKz1uLnN0Lm1haW5DbGFzcytcIiBcIiksbi5fcmVtb3ZlQ2xhc3NGcm9tTUZQKGMpO2lmKG4uZml4ZWRDb250ZW50UG9zKXt2YXIgZT17bWFyZ2luUmlnaHQ6XCJcIn07bi5pc0lFNz9hKFwiYm9keSwgaHRtbFwiKS5jc3MoXCJvdmVyZmxvd1wiLFwiXCIpOmUub3ZlcmZsb3c9XCJcIixhKFwiaHRtbFwiKS5jc3MoZSl9cy5vZmYoXCJrZXl1cFwiK2orXCIgZm9jdXNpblwiK2opLG4uZXYub2ZmKGopLG4ud3JhcC5hdHRyKFwiY2xhc3NcIixcIm1mcC13cmFwXCIpLnJlbW92ZUF0dHIoXCJzdHlsZVwiKSxuLmJnT3ZlcmxheS5hdHRyKFwiY2xhc3NcIixcIm1mcC1iZ1wiKSxuLmNvbnRhaW5lci5hdHRyKFwiY2xhc3NcIixcIm1mcC1jb250YWluZXJcIiksbi5zdC5zaG93Q2xvc2VCdG4mJighbi5zdC5jbG9zZUJ0bkluc2lkZXx8bi5jdXJyVGVtcGxhdGVbbi5jdXJySXRlbS50eXBlXT09PSEwKSYmbi5jdXJyVGVtcGxhdGUuY2xvc2VCdG4mJm4uY3VyclRlbXBsYXRlLmNsb3NlQnRuLmRldGFjaCgpLG4uc3QuYXV0b0ZvY3VzTGFzdCYmbi5fbGFzdEZvY3VzZWRFbCYmYShuLl9sYXN0Rm9jdXNlZEVsKS5mb2N1cygpLG4uY3Vyckl0ZW09bnVsbCxuLmNvbnRlbnQ9bnVsbCxuLmN1cnJUZW1wbGF0ZT1udWxsLG4ucHJldkhlaWdodD0wLHkoZCl9LHVwZGF0ZVNpemU6ZnVuY3Rpb24oYSl7aWYobi5pc0lPUyl7dmFyIGI9ZG9jdW1lbnQuZG9jdW1lbnRFbGVtZW50LmNsaWVudFdpZHRoL3dpbmRvdy5pbm5lcldpZHRoLGM9d2luZG93LmlubmVySGVpZ2h0KmI7bi53cmFwLmNzcyhcImhlaWdodFwiLGMpLG4ud0g9Y31lbHNlIG4ud0g9YXx8ci5oZWlnaHQoKTtuLmZpeGVkQ29udGVudFBvc3x8bi53cmFwLmNzcyhcImhlaWdodFwiLG4ud0gpLHkoXCJSZXNpemVcIil9LHVwZGF0ZUl0ZW1IVE1MOmZ1bmN0aW9uKCl7dmFyIGI9bi5pdGVtc1tuLmluZGV4XTtuLmNvbnRlbnRDb250YWluZXIuZGV0YWNoKCksbi5jb250ZW50JiZuLmNvbnRlbnQuZGV0YWNoKCksYi5wYXJzZWR8fChiPW4ucGFyc2VFbChuLmluZGV4KSk7dmFyIGM9Yi50eXBlO3koXCJCZWZvcmVDaGFuZ2VcIixbbi5jdXJySXRlbT9uLmN1cnJJdGVtLnR5cGU6XCJcIixjXSksbi5jdXJySXRlbT1iO2lmKCFuLmN1cnJUZW1wbGF0ZVtjXSl7dmFyIGQ9bi5zdFtjXT9uLnN0W2NdLm1hcmt1cDohMTt5KFwiRmlyc3RNYXJrdXBQYXJzZVwiLGQpLGQ/bi5jdXJyVGVtcGxhdGVbY109YShkKTpuLmN1cnJUZW1wbGF0ZVtjXT0hMH10JiZ0IT09Yi50eXBlJiZuLmNvbnRhaW5lci5yZW1vdmVDbGFzcyhcIm1mcC1cIit0K1wiLWhvbGRlclwiKTt2YXIgZT1uW1wiZ2V0XCIrYy5jaGFyQXQoMCkudG9VcHBlckNhc2UoKStjLnNsaWNlKDEpXShiLG4uY3VyclRlbXBsYXRlW2NdKTtuLmFwcGVuZENvbnRlbnQoZSxjKSxiLnByZWxvYWRlZD0hMCx5KGgsYiksdD1iLnR5cGUsbi5jb250YWluZXIucHJlcGVuZChuLmNvbnRlbnRDb250YWluZXIpLHkoXCJBZnRlckNoYW5nZVwiKX0sYXBwZW5kQ29udGVudDpmdW5jdGlvbihhLGIpe24uY29udGVudD1hLGE/bi5zdC5zaG93Q2xvc2VCdG4mJm4uc3QuY2xvc2VCdG5JbnNpZGUmJm4uY3VyclRlbXBsYXRlW2JdPT09ITA/bi5jb250ZW50LmZpbmQoXCIubWZwLWNsb3NlXCIpLmxlbmd0aHx8bi5jb250ZW50LmFwcGVuZCh6KCkpOm4uY29udGVudD1hOm4uY29udGVudD1cIlwiLHkoZSksbi5jb250YWluZXIuYWRkQ2xhc3MoXCJtZnAtXCIrYitcIi1ob2xkZXJcIiksbi5jb250ZW50Q29udGFpbmVyLmFwcGVuZChuLmNvbnRlbnQpfSxwYXJzZUVsOmZ1bmN0aW9uKGIpe3ZhciBjPW4uaXRlbXNbYl0sZDtjLnRhZ05hbWU/Yz17ZWw6YShjKX06KGQ9Yy50eXBlLGM9e2RhdGE6YyxzcmM6Yy5zcmN9KTtpZihjLmVsKXt2YXIgZT1uLnR5cGVzO2Zvcih2YXIgZj0wO2Y8ZS5sZW5ndGg7ZisrKWlmKGMuZWwuaGFzQ2xhc3MoXCJtZnAtXCIrZVtmXSkpe2Q9ZVtmXTticmVha31jLnNyYz1jLmVsLmF0dHIoXCJkYXRhLW1mcC1zcmNcIiksYy5zcmN8fChjLnNyYz1jLmVsLmF0dHIoXCJocmVmXCIpKX1yZXR1cm4gYy50eXBlPWR8fG4uc3QudHlwZXx8XCJpbmxpbmVcIixjLmluZGV4PWIsYy5wYXJzZWQ9ITAsbi5pdGVtc1tiXT1jLHkoXCJFbGVtZW50UGFyc2VcIixjKSxuLml0ZW1zW2JdfSxhZGRHcm91cDpmdW5jdGlvbihhLGIpe3ZhciBjPWZ1bmN0aW9uKGMpe2MubWZwRWw9dGhpcyxuLl9vcGVuQ2xpY2soYyxhLGIpfTtifHwoYj17fSk7dmFyIGQ9XCJjbGljay5tYWduaWZpY1BvcHVwXCI7Yi5tYWluRWw9YSxiLml0ZW1zPyhiLmlzT2JqPSEwLGEub2ZmKGQpLm9uKGQsYykpOihiLmlzT2JqPSExLGIuZGVsZWdhdGU/YS5vZmYoZCkub24oZCxiLmRlbGVnYXRlLGMpOihiLml0ZW1zPWEsYS5vZmYoZCkub24oZCxjKSkpfSxfb3BlbkNsaWNrOmZ1bmN0aW9uKGIsYyxkKXt2YXIgZT1kLm1pZENsaWNrIT09dW5kZWZpbmVkP2QubWlkQ2xpY2s6YS5tYWduaWZpY1BvcHVwLmRlZmF1bHRzLm1pZENsaWNrO2lmKCFlJiYoYi53aGljaD09PTJ8fGIuY3RybEtleXx8Yi5tZXRhS2V5fHxiLmFsdEtleXx8Yi5zaGlmdEtleSkpcmV0dXJuO3ZhciBmPWQuZGlzYWJsZU9uIT09dW5kZWZpbmVkP2QuZGlzYWJsZU9uOmEubWFnbmlmaWNQb3B1cC5kZWZhdWx0cy5kaXNhYmxlT247aWYoZilpZihhLmlzRnVuY3Rpb24oZikpe2lmKCFmLmNhbGwobikpcmV0dXJuITB9ZWxzZSBpZihyLndpZHRoKCk8ZilyZXR1cm4hMDtiLnR5cGUmJihiLnByZXZlbnREZWZhdWx0KCksbi5pc09wZW4mJmIuc3RvcFByb3BhZ2F0aW9uKCkpLGQuZWw9YShiLm1mcEVsKSxkLmRlbGVnYXRlJiYoZC5pdGVtcz1jLmZpbmQoZC5kZWxlZ2F0ZSkpLG4ub3BlbihkKX0sdXBkYXRlU3RhdHVzOmZ1bmN0aW9uKGEsYil7aWYobi5wcmVsb2FkZXIpe3EhPT1hJiZuLmNvbnRhaW5lci5yZW1vdmVDbGFzcyhcIm1mcC1zLVwiK3EpLCFiJiZhPT09XCJsb2FkaW5nXCImJihiPW4uc3QudExvYWRpbmcpO3ZhciBjPXtzdGF0dXM6YSx0ZXh0OmJ9O3koXCJVcGRhdGVTdGF0dXNcIixjKSxhPWMuc3RhdHVzLGI9Yy50ZXh0LG4ucHJlbG9hZGVyLmh0bWwoYiksbi5wcmVsb2FkZXIuZmluZChcImFcIikub24oXCJjbGlja1wiLGZ1bmN0aW9uKGEpe2Euc3RvcEltbWVkaWF0ZVByb3BhZ2F0aW9uKCl9KSxuLmNvbnRhaW5lci5hZGRDbGFzcyhcIm1mcC1zLVwiK2EpLHE9YX19LF9jaGVja0lmQ2xvc2U6ZnVuY3Rpb24oYil7aWYoYShiKS5oYXNDbGFzcyhtKSlyZXR1cm47dmFyIGM9bi5zdC5jbG9zZU9uQ29udGVudENsaWNrLGQ9bi5zdC5jbG9zZU9uQmdDbGljaztpZihjJiZkKXJldHVybiEwO2lmKCFuLmNvbnRlbnR8fGEoYikuaGFzQ2xhc3MoXCJtZnAtY2xvc2VcIil8fG4ucHJlbG9hZGVyJiZiPT09bi5wcmVsb2FkZXJbMF0pcmV0dXJuITA7aWYoYiE9PW4uY29udGVudFswXSYmIWEuY29udGFpbnMobi5jb250ZW50WzBdLGIpKXtpZihkJiZhLmNvbnRhaW5zKGRvY3VtZW50LGIpKXJldHVybiEwfWVsc2UgaWYoYylyZXR1cm4hMDtyZXR1cm4hMX0sX2FkZENsYXNzVG9NRlA6ZnVuY3Rpb24oYSl7bi5iZ092ZXJsYXkuYWRkQ2xhc3MoYSksbi53cmFwLmFkZENsYXNzKGEpfSxfcmVtb3ZlQ2xhc3NGcm9tTUZQOmZ1bmN0aW9uKGEpe3RoaXMuYmdPdmVybGF5LnJlbW92ZUNsYXNzKGEpLG4ud3JhcC5yZW1vdmVDbGFzcyhhKX0sX2hhc1Njcm9sbEJhcjpmdW5jdGlvbihhKXtyZXR1cm4obi5pc0lFNz9zLmhlaWdodCgpOmRvY3VtZW50LmJvZHkuc2Nyb2xsSGVpZ2h0KT4oYXx8ci5oZWlnaHQoKSl9LF9zZXRGb2N1czpmdW5jdGlvbigpeyhuLnN0LmZvY3VzP24uY29udGVudC5maW5kKG4uc3QuZm9jdXMpLmVxKDApOm4ud3JhcCkuZm9jdXMoKX0sX29uRm9jdXNJbjpmdW5jdGlvbihiKXtpZihiLnRhcmdldCE9PW4ud3JhcFswXSYmIWEuY29udGFpbnMobi53cmFwWzBdLGIudGFyZ2V0KSlyZXR1cm4gbi5fc2V0Rm9jdXMoKSwhMX0sX3BhcnNlTWFya3VwOmZ1bmN0aW9uKGIsYyxkKXt2YXIgZTtkLmRhdGEmJihjPWEuZXh0ZW5kKGQuZGF0YSxjKSkseShmLFtiLGMsZF0pLGEuZWFjaChjLGZ1bmN0aW9uKGMsZCl7aWYoZD09PXVuZGVmaW5lZHx8ZD09PSExKXJldHVybiEwO2U9Yy5zcGxpdChcIl9cIik7aWYoZS5sZW5ndGg+MSl7dmFyIGY9Yi5maW5kKGorXCItXCIrZVswXSk7aWYoZi5sZW5ndGg+MCl7dmFyIGc9ZVsxXTtnPT09XCJyZXBsYWNlV2l0aFwiP2ZbMF0hPT1kWzBdJiZmLnJlcGxhY2VXaXRoKGQpOmc9PT1cImltZ1wiP2YuaXMoXCJpbWdcIik/Zi5hdHRyKFwic3JjXCIsZCk6Zi5yZXBsYWNlV2l0aChhKFwiPGltZz5cIikuYXR0cihcInNyY1wiLGQpLmF0dHIoXCJjbGFzc1wiLGYuYXR0cihcImNsYXNzXCIpKSk6Zi5hdHRyKGVbMV0sZCl9fWVsc2UgYi5maW5kKGorXCItXCIrYykuaHRtbChkKX0pfSxfZ2V0U2Nyb2xsYmFyU2l6ZTpmdW5jdGlvbigpe2lmKG4uc2Nyb2xsYmFyU2l6ZT09PXVuZGVmaW5lZCl7dmFyIGE9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTthLnN0eWxlLmNzc1RleHQ9XCJ3aWR0aDogOTlweDsgaGVpZ2h0OiA5OXB4OyBvdmVyZmxvdzogc2Nyb2xsOyBwb3NpdGlvbjogYWJzb2x1dGU7IHRvcDogLTk5OTlweDtcIixkb2N1bWVudC5ib2R5LmFwcGVuZENoaWxkKGEpLG4uc2Nyb2xsYmFyU2l6ZT1hLm9mZnNldFdpZHRoLWEuY2xpZW50V2lkdGgsZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChhKX1yZXR1cm4gbi5zY3JvbGxiYXJTaXplfX0sYS5tYWduaWZpY1BvcHVwPXtpbnN0YW5jZTpudWxsLHByb3RvOm8ucHJvdG90eXBlLG1vZHVsZXM6W10sb3BlbjpmdW5jdGlvbihiLGMpe3JldHVybiBBKCksYj9iPWEuZXh0ZW5kKCEwLHt9LGIpOmI9e30sYi5pc09iaj0hMCxiLmluZGV4PWN8fDAsdGhpcy5pbnN0YW5jZS5vcGVuKGIpfSxjbG9zZTpmdW5jdGlvbigpe3JldHVybiBhLm1hZ25pZmljUG9wdXAuaW5zdGFuY2UmJmEubWFnbmlmaWNQb3B1cC5pbnN0YW5jZS5jbG9zZSgpfSxyZWdpc3Rlck1vZHVsZTpmdW5jdGlvbihiLGMpe2Mub3B0aW9ucyYmKGEubWFnbmlmaWNQb3B1cC5kZWZhdWx0c1tiXT1jLm9wdGlvbnMpLGEuZXh0ZW5kKHRoaXMucHJvdG8sYy5wcm90byksdGhpcy5tb2R1bGVzLnB1c2goYil9LGRlZmF1bHRzOntkaXNhYmxlT246MCxrZXk6bnVsbCxtaWRDbGljazohMSxtYWluQ2xhc3M6XCJcIixwcmVsb2FkZXI6ITAsZm9jdXM6XCJcIixjbG9zZU9uQ29udGVudENsaWNrOiExLGNsb3NlT25CZ0NsaWNrOiEwLGNsb3NlQnRuSW5zaWRlOiEwLHNob3dDbG9zZUJ0bjohMCxlbmFibGVFc2NhcGVLZXk6ITAsbW9kYWw6ITEsYWxpZ25Ub3A6ITEscmVtb3ZhbERlbGF5OjAscHJlcGVuZFRvOm51bGwsZml4ZWRDb250ZW50UG9zOlwiYXV0b1wiLGZpeGVkQmdQb3M6XCJhdXRvXCIsb3ZlcmZsb3dZOlwiYXV0b1wiLGNsb3NlTWFya3VwOic8YnV0dG9uIHRpdGxlPVwiJXRpdGxlJVwiIHR5cGU9XCJidXR0b25cIiBjbGFzcz1cIm1mcC1jbG9zZVwiPiYjMjE1OzwvYnV0dG9uPicsdENsb3NlOlwiQ2xvc2UgKEVzYylcIix0TG9hZGluZzpcIkxvYWRpbmcuLi5cIixhdXRvRm9jdXNMYXN0OiEwfX0sYS5mbi5tYWduaWZpY1BvcHVwPWZ1bmN0aW9uKGIpe0EoKTt2YXIgYz1hKHRoaXMpO2lmKHR5cGVvZiBiPT1cInN0cmluZ1wiKWlmKGI9PT1cIm9wZW5cIil7dmFyIGQsZT1wP2MuZGF0YShcIm1hZ25pZmljUG9wdXBcIik6Y1swXS5tYWduaWZpY1BvcHVwLGY9cGFyc2VJbnQoYXJndW1lbnRzWzFdLDEwKXx8MDtlLml0ZW1zP2Q9ZS5pdGVtc1tmXTooZD1jLGUuZGVsZWdhdGUmJihkPWQuZmluZChlLmRlbGVnYXRlKSksZD1kLmVxKGYpKSxuLl9vcGVuQ2xpY2soe21mcEVsOmR9LGMsZSl9ZWxzZSBuLmlzT3BlbiYmbltiXS5hcHBseShuLEFycmF5LnByb3RvdHlwZS5zbGljZS5jYWxsKGFyZ3VtZW50cywxKSk7ZWxzZSBiPWEuZXh0ZW5kKCEwLHt9LGIpLHA/Yy5kYXRhKFwibWFnbmlmaWNQb3B1cFwiLGIpOmNbMF0ubWFnbmlmaWNQb3B1cD1iLG4uYWRkR3JvdXAoYyxiKTtyZXR1cm4gY307dmFyIEM9XCJpbmxpbmVcIixELEUsRixHPWZ1bmN0aW9uKCl7RiYmKEUuYWZ0ZXIoRi5hZGRDbGFzcyhEKSkuZGV0YWNoKCksRj1udWxsKX07YS5tYWduaWZpY1BvcHVwLnJlZ2lzdGVyTW9kdWxlKEMse29wdGlvbnM6e2hpZGRlbkNsYXNzOlwiaGlkZVwiLG1hcmt1cDpcIlwiLHROb3RGb3VuZDpcIkNvbnRlbnQgbm90IGZvdW5kXCJ9LHByb3RvOntpbml0SW5saW5lOmZ1bmN0aW9uKCl7bi50eXBlcy5wdXNoKEMpLHcoYitcIi5cIitDLGZ1bmN0aW9uKCl7RygpfSl9LGdldElubGluZTpmdW5jdGlvbihiLGMpe0coKTtpZihiLnNyYyl7dmFyIGQ9bi5zdC5pbmxpbmUsZT1hKGIuc3JjKTtpZihlLmxlbmd0aCl7dmFyIGY9ZVswXS5wYXJlbnROb2RlO2YmJmYudGFnTmFtZSYmKEV8fChEPWQuaGlkZGVuQ2xhc3MsRT14KEQpLEQ9XCJtZnAtXCIrRCksRj1lLmFmdGVyKEUpLmRldGFjaCgpLnJlbW92ZUNsYXNzKEQpKSxuLnVwZGF0ZVN0YXR1cyhcInJlYWR5XCIpfWVsc2Ugbi51cGRhdGVTdGF0dXMoXCJlcnJvclwiLGQudE5vdEZvdW5kKSxlPWEoXCI8ZGl2PlwiKTtyZXR1cm4gYi5pbmxpbmVFbGVtZW50PWUsZX1yZXR1cm4gbi51cGRhdGVTdGF0dXMoXCJyZWFkeVwiKSxuLl9wYXJzZU1hcmt1cChjLHt9LGIpLGN9fX0pO3ZhciBIPVwiYWpheFwiLEksSj1mdW5jdGlvbigpe0kmJmEoZG9jdW1lbnQuYm9keSkucmVtb3ZlQ2xhc3MoSSl9LEs9ZnVuY3Rpb24oKXtKKCksbi5yZXEmJm4ucmVxLmFib3J0KCl9O2EubWFnbmlmaWNQb3B1cC5yZWdpc3Rlck1vZHVsZShILHtvcHRpb25zOntzZXR0aW5nczpudWxsLGN1cnNvcjpcIm1mcC1hamF4LWN1clwiLHRFcnJvcjonPGEgaHJlZj1cIiV1cmwlXCI+VGhlIGNvbnRlbnQ8L2E+IGNvdWxkIG5vdCBiZSBsb2FkZWQuJ30scHJvdG86e2luaXRBamF4OmZ1bmN0aW9uKCl7bi50eXBlcy5wdXNoKEgpLEk9bi5zdC5hamF4LmN1cnNvcix3KGIrXCIuXCIrSCxLKSx3KFwiQmVmb3JlQ2hhbmdlLlwiK0gsSyl9LGdldEFqYXg6ZnVuY3Rpb24oYil7SSYmYShkb2N1bWVudC5ib2R5KS5hZGRDbGFzcyhJKSxuLnVwZGF0ZVN0YXR1cyhcImxvYWRpbmdcIik7dmFyIGM9YS5leHRlbmQoe3VybDpiLnNyYyxzdWNjZXNzOmZ1bmN0aW9uKGMsZCxlKXt2YXIgZj17ZGF0YTpjLHhocjplfTt5KFwiUGFyc2VBamF4XCIsZiksbi5hcHBlbmRDb250ZW50KGEoZi5kYXRhKSxIKSxiLmZpbmlzaGVkPSEwLEooKSxuLl9zZXRGb2N1cygpLHNldFRpbWVvdXQoZnVuY3Rpb24oKXtuLndyYXAuYWRkQ2xhc3Moayl9LDE2KSxuLnVwZGF0ZVN0YXR1cyhcInJlYWR5XCIpLHkoXCJBamF4Q29udGVudEFkZGVkXCIpfSxlcnJvcjpmdW5jdGlvbigpe0ooKSxiLmZpbmlzaGVkPWIubG9hZEVycm9yPSEwLG4udXBkYXRlU3RhdHVzKFwiZXJyb3JcIixuLnN0LmFqYXgudEVycm9yLnJlcGxhY2UoXCIldXJsJVwiLGIuc3JjKSl9fSxuLnN0LmFqYXguc2V0dGluZ3MpO3JldHVybiBuLnJlcT1hLmFqYXgoYyksXCJcIn19fSk7dmFyIEwsTT1mdW5jdGlvbihiKXtpZihiLmRhdGEmJmIuZGF0YS50aXRsZSE9PXVuZGVmaW5lZClyZXR1cm4gYi5kYXRhLnRpdGxlO3ZhciBjPW4uc3QuaW1hZ2UudGl0bGVTcmM7aWYoYyl7aWYoYS5pc0Z1bmN0aW9uKGMpKXJldHVybiBjLmNhbGwobixiKTtpZihiLmVsKXJldHVybiBiLmVsLmF0dHIoYyl8fFwiXCJ9cmV0dXJuXCJcIn07YS5tYWduaWZpY1BvcHVwLnJlZ2lzdGVyTW9kdWxlKFwiaW1hZ2VcIix7b3B0aW9uczp7bWFya3VwOic8ZGl2IGNsYXNzPVwibWZwLWZpZ3VyZVwiPjxkaXYgY2xhc3M9XCJtZnAtY2xvc2VcIj48L2Rpdj48ZmlndXJlPjxkaXYgY2xhc3M9XCJtZnAtaW1nXCI+PC9kaXY+PGZpZ2NhcHRpb24+PGRpdiBjbGFzcz1cIm1mcC1ib3R0b20tYmFyXCI+PGRpdiBjbGFzcz1cIm1mcC10aXRsZVwiPjwvZGl2PjxkaXYgY2xhc3M9XCJtZnAtY291bnRlclwiPjwvZGl2PjwvZGl2PjwvZmlnY2FwdGlvbj48L2ZpZ3VyZT48L2Rpdj4nLGN1cnNvcjpcIm1mcC16b29tLW91dC1jdXJcIix0aXRsZVNyYzpcInRpdGxlXCIsdmVydGljYWxGaXQ6ITAsdEVycm9yOic8YSBocmVmPVwiJXVybCVcIj5UaGUgaW1hZ2U8L2E+IGNvdWxkIG5vdCBiZSBsb2FkZWQuJ30scHJvdG86e2luaXRJbWFnZTpmdW5jdGlvbigpe3ZhciBjPW4uc3QuaW1hZ2UsZD1cIi5pbWFnZVwiO24udHlwZXMucHVzaChcImltYWdlXCIpLHcoZytkLGZ1bmN0aW9uKCl7bi5jdXJySXRlbS50eXBlPT09XCJpbWFnZVwiJiZjLmN1cnNvciYmYShkb2N1bWVudC5ib2R5KS5hZGRDbGFzcyhjLmN1cnNvcil9KSx3KGIrZCxmdW5jdGlvbigpe2MuY3Vyc29yJiZhKGRvY3VtZW50LmJvZHkpLnJlbW92ZUNsYXNzKGMuY3Vyc29yKSxyLm9mZihcInJlc2l6ZVwiK2opfSksdyhcIlJlc2l6ZVwiK2Qsbi5yZXNpemVJbWFnZSksbi5pc0xvd0lFJiZ3KFwiQWZ0ZXJDaGFuZ2VcIixuLnJlc2l6ZUltYWdlKX0scmVzaXplSW1hZ2U6ZnVuY3Rpb24oKXt2YXIgYT1uLmN1cnJJdGVtO2lmKCFhfHwhYS5pbWcpcmV0dXJuO2lmKG4uc3QuaW1hZ2UudmVydGljYWxGaXQpe3ZhciBiPTA7bi5pc0xvd0lFJiYoYj1wYXJzZUludChhLmltZy5jc3MoXCJwYWRkaW5nLXRvcFwiKSwxMCkrcGFyc2VJbnQoYS5pbWcuY3NzKFwicGFkZGluZy1ib3R0b21cIiksMTApKSxhLmltZy5jc3MoXCJtYXgtaGVpZ2h0XCIsbi53SC1iKX19LF9vbkltYWdlSGFzU2l6ZTpmdW5jdGlvbihhKXthLmltZyYmKGEuaGFzU2l6ZT0hMCxMJiZjbGVhckludGVydmFsKEwpLGEuaXNDaGVja2luZ0ltZ1NpemU9ITEseShcIkltYWdlSGFzU2l6ZVwiLGEpLGEuaW1nSGlkZGVuJiYobi5jb250ZW50JiZuLmNvbnRlbnQucmVtb3ZlQ2xhc3MoXCJtZnAtbG9hZGluZ1wiKSxhLmltZ0hpZGRlbj0hMSkpfSxmaW5kSW1hZ2VTaXplOmZ1bmN0aW9uKGEpe3ZhciBiPTAsYz1hLmltZ1swXSxkPWZ1bmN0aW9uKGUpe0wmJmNsZWFySW50ZXJ2YWwoTCksTD1zZXRJbnRlcnZhbChmdW5jdGlvbigpe2lmKGMubmF0dXJhbFdpZHRoPjApe24uX29uSW1hZ2VIYXNTaXplKGEpO3JldHVybn1iPjIwMCYmY2xlYXJJbnRlcnZhbChMKSxiKyssYj09PTM/ZCgxMCk6Yj09PTQwP2QoNTApOmI9PT0xMDAmJmQoNTAwKX0sZSl9O2QoMSl9LGdldEltYWdlOmZ1bmN0aW9uKGIsYyl7dmFyIGQ9MCxlPWZ1bmN0aW9uKCl7YiYmKGIuaW1nWzBdLmNvbXBsZXRlPyhiLmltZy5vZmYoXCIubWZwbG9hZGVyXCIpLGI9PT1uLmN1cnJJdGVtJiYobi5fb25JbWFnZUhhc1NpemUoYiksbi51cGRhdGVTdGF0dXMoXCJyZWFkeVwiKSksYi5oYXNTaXplPSEwLGIubG9hZGVkPSEwLHkoXCJJbWFnZUxvYWRDb21wbGV0ZVwiKSk6KGQrKyxkPDIwMD9zZXRUaW1lb3V0KGUsMTAwKTpmKCkpKX0sZj1mdW5jdGlvbigpe2ImJihiLmltZy5vZmYoXCIubWZwbG9hZGVyXCIpLGI9PT1uLmN1cnJJdGVtJiYobi5fb25JbWFnZUhhc1NpemUoYiksbi51cGRhdGVTdGF0dXMoXCJlcnJvclwiLGcudEVycm9yLnJlcGxhY2UoXCIldXJsJVwiLGIuc3JjKSkpLGIuaGFzU2l6ZT0hMCxiLmxvYWRlZD0hMCxiLmxvYWRFcnJvcj0hMCl9LGc9bi5zdC5pbWFnZSxoPWMuZmluZChcIi5tZnAtaW1nXCIpO2lmKGgubGVuZ3RoKXt2YXIgaT1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpO2kuY2xhc3NOYW1lPVwibWZwLWltZ1wiLGIuZWwmJmIuZWwuZmluZChcImltZ1wiKS5sZW5ndGgmJihpLmFsdD1iLmVsLmZpbmQoXCJpbWdcIikuYXR0cihcImFsdFwiKSksYi5pbWc9YShpKS5vbihcImxvYWQubWZwbG9hZGVyXCIsZSkub24oXCJlcnJvci5tZnBsb2FkZXJcIixmKSxpLnNyYz1iLnNyYyxoLmlzKFwiaW1nXCIpJiYoYi5pbWc9Yi5pbWcuY2xvbmUoKSksaT1iLmltZ1swXSxpLm5hdHVyYWxXaWR0aD4wP2IuaGFzU2l6ZT0hMDppLndpZHRofHwoYi5oYXNTaXplPSExKX1yZXR1cm4gbi5fcGFyc2VNYXJrdXAoYyx7dGl0bGU6TShiKSxpbWdfcmVwbGFjZVdpdGg6Yi5pbWd9LGIpLG4ucmVzaXplSW1hZ2UoKSxiLmhhc1NpemU/KEwmJmNsZWFySW50ZXJ2YWwoTCksYi5sb2FkRXJyb3I/KGMuYWRkQ2xhc3MoXCJtZnAtbG9hZGluZ1wiKSxuLnVwZGF0ZVN0YXR1cyhcImVycm9yXCIsZy50RXJyb3IucmVwbGFjZShcIiV1cmwlXCIsYi5zcmMpKSk6KGMucmVtb3ZlQ2xhc3MoXCJtZnAtbG9hZGluZ1wiKSxuLnVwZGF0ZVN0YXR1cyhcInJlYWR5XCIpKSxjKToobi51cGRhdGVTdGF0dXMoXCJsb2FkaW5nXCIpLGIubG9hZGluZz0hMCxiLmhhc1NpemV8fChiLmltZ0hpZGRlbj0hMCxjLmFkZENsYXNzKFwibWZwLWxvYWRpbmdcIiksbi5maW5kSW1hZ2VTaXplKGIpKSxjKX19fSk7dmFyIE4sTz1mdW5jdGlvbigpe3JldHVybiBOPT09dW5kZWZpbmVkJiYoTj1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwicFwiKS5zdHlsZS5Nb3pUcmFuc2Zvcm0hPT11bmRlZmluZWQpLE59O2EubWFnbmlmaWNQb3B1cC5yZWdpc3Rlck1vZHVsZShcInpvb21cIix7b3B0aW9uczp7ZW5hYmxlZDohMSxlYXNpbmc6XCJlYXNlLWluLW91dFwiLGR1cmF0aW9uOjMwMCxvcGVuZXI6ZnVuY3Rpb24oYSl7cmV0dXJuIGEuaXMoXCJpbWdcIik/YTphLmZpbmQoXCJpbWdcIil9fSxwcm90bzp7aW5pdFpvb206ZnVuY3Rpb24oKXt2YXIgYT1uLnN0Lnpvb20sZD1cIi56b29tXCIsZTtpZighYS5lbmFibGVkfHwhbi5zdXBwb3J0c1RyYW5zaXRpb24pcmV0dXJuO3ZhciBmPWEuZHVyYXRpb24sZz1mdW5jdGlvbihiKXt2YXIgYz1iLmNsb25lKCkucmVtb3ZlQXR0cihcInN0eWxlXCIpLnJlbW92ZUF0dHIoXCJjbGFzc1wiKS5hZGRDbGFzcyhcIm1mcC1hbmltYXRlZC1pbWFnZVwiKSxkPVwiYWxsIFwiK2EuZHVyYXRpb24vMWUzK1wicyBcIithLmVhc2luZyxlPXtwb3NpdGlvbjpcImZpeGVkXCIsekluZGV4Ojk5OTksbGVmdDowLHRvcDowLFwiLXdlYmtpdC1iYWNrZmFjZS12aXNpYmlsaXR5XCI6XCJoaWRkZW5cIn0sZj1cInRyYW5zaXRpb25cIjtyZXR1cm4gZVtcIi13ZWJraXQtXCIrZl09ZVtcIi1tb3otXCIrZl09ZVtcIi1vLVwiK2ZdPWVbZl09ZCxjLmNzcyhlKSxjfSxoPWZ1bmN0aW9uKCl7bi5jb250ZW50LmNzcyhcInZpc2liaWxpdHlcIixcInZpc2libGVcIil9LGksajt3KFwiQnVpbGRDb250cm9sc1wiK2QsZnVuY3Rpb24oKXtpZihuLl9hbGxvd1pvb20oKSl7Y2xlYXJUaW1lb3V0KGkpLG4uY29udGVudC5jc3MoXCJ2aXNpYmlsaXR5XCIsXCJoaWRkZW5cIiksZT1uLl9nZXRJdGVtVG9ab29tKCk7aWYoIWUpe2goKTtyZXR1cm59aj1nKGUpLGouY3NzKG4uX2dldE9mZnNldCgpKSxuLndyYXAuYXBwZW5kKGopLGk9c2V0VGltZW91dChmdW5jdGlvbigpe2ouY3NzKG4uX2dldE9mZnNldCghMCkpLGk9c2V0VGltZW91dChmdW5jdGlvbigpe2goKSxzZXRUaW1lb3V0KGZ1bmN0aW9uKCl7ai5yZW1vdmUoKSxlPWo9bnVsbCx5KFwiWm9vbUFuaW1hdGlvbkVuZGVkXCIpfSwxNil9LGYpfSwxNil9fSksdyhjK2QsZnVuY3Rpb24oKXtpZihuLl9hbGxvd1pvb20oKSl7Y2xlYXJUaW1lb3V0KGkpLG4uc3QucmVtb3ZhbERlbGF5PWY7aWYoIWUpe2U9bi5fZ2V0SXRlbVRvWm9vbSgpO2lmKCFlKXJldHVybjtqPWcoZSl9ai5jc3Mobi5fZ2V0T2Zmc2V0KCEwKSksbi53cmFwLmFwcGVuZChqKSxuLmNvbnRlbnQuY3NzKFwidmlzaWJpbGl0eVwiLFwiaGlkZGVuXCIpLHNldFRpbWVvdXQoZnVuY3Rpb24oKXtqLmNzcyhuLl9nZXRPZmZzZXQoKSl9LDE2KX19KSx3KGIrZCxmdW5jdGlvbigpe24uX2FsbG93Wm9vbSgpJiYoaCgpLGomJmoucmVtb3ZlKCksZT1udWxsKX0pfSxfYWxsb3dab29tOmZ1bmN0aW9uKCl7cmV0dXJuIG4uY3Vyckl0ZW0udHlwZT09PVwiaW1hZ2VcIn0sX2dldEl0ZW1Ub1pvb206ZnVuY3Rpb24oKXtyZXR1cm4gbi5jdXJySXRlbS5oYXNTaXplP24uY3Vyckl0ZW0uaW1nOiExfSxfZ2V0T2Zmc2V0OmZ1bmN0aW9uKGIpe3ZhciBjO2I/Yz1uLmN1cnJJdGVtLmltZzpjPW4uc3Quem9vbS5vcGVuZXIobi5jdXJySXRlbS5lbHx8bi5jdXJySXRlbSk7dmFyIGQ9Yy5vZmZzZXQoKSxlPXBhcnNlSW50KGMuY3NzKFwicGFkZGluZy10b3BcIiksMTApLGY9cGFyc2VJbnQoYy5jc3MoXCJwYWRkaW5nLWJvdHRvbVwiKSwxMCk7ZC50b3AtPWEod2luZG93KS5zY3JvbGxUb3AoKS1lO3ZhciBnPXt3aWR0aDpjLndpZHRoKCksaGVpZ2h0OihwP2MuaW5uZXJIZWlnaHQoKTpjWzBdLm9mZnNldEhlaWdodCktZi1lfTtyZXR1cm4gTygpP2dbXCItbW96LXRyYW5zZm9ybVwiXT1nLnRyYW5zZm9ybT1cInRyYW5zbGF0ZShcIitkLmxlZnQrXCJweCxcIitkLnRvcCtcInB4KVwiOihnLmxlZnQ9ZC5sZWZ0LGcudG9wPWQudG9wKSxnfX19KTt2YXIgUD1cImlmcmFtZVwiLFE9XCIvL2Fib3V0OmJsYW5rXCIsUj1mdW5jdGlvbihhKXtpZihuLmN1cnJUZW1wbGF0ZVtQXSl7dmFyIGI9bi5jdXJyVGVtcGxhdGVbUF0uZmluZChcImlmcmFtZVwiKTtiLmxlbmd0aCYmKGF8fChiWzBdLnNyYz1RKSxuLmlzSUU4JiZiLmNzcyhcImRpc3BsYXlcIixhP1wiYmxvY2tcIjpcIm5vbmVcIikpfX07YS5tYWduaWZpY1BvcHVwLnJlZ2lzdGVyTW9kdWxlKFAse29wdGlvbnM6e21hcmt1cDonPGRpdiBjbGFzcz1cIm1mcC1pZnJhbWUtc2NhbGVyXCI+PGRpdiBjbGFzcz1cIm1mcC1jbG9zZVwiPjwvZGl2PjxpZnJhbWUgY2xhc3M9XCJtZnAtaWZyYW1lXCIgc3JjPVwiLy9hYm91dDpibGFua1wiIGZyYW1lYm9yZGVyPVwiMFwiIGFsbG93ZnVsbHNjcmVlbj48L2lmcmFtZT48L2Rpdj4nLHNyY0FjdGlvbjpcImlmcmFtZV9zcmNcIixwYXR0ZXJuczp7eW91dHViZTp7aW5kZXg6XCJ5b3V0dWJlLmNvbVwiLGlkOlwidj1cIixzcmM6XCIvL3d3dy55b3V0dWJlLmNvbS9lbWJlZC8laWQlP2F1dG9wbGF5PTFcIn0sdmltZW86e2luZGV4OlwidmltZW8uY29tL1wiLGlkOlwiL1wiLHNyYzpcIi8vcGxheWVyLnZpbWVvLmNvbS92aWRlby8laWQlP2F1dG9wbGF5PTFcIn0sZ21hcHM6e2luZGV4OlwiLy9tYXBzLmdvb2dsZS5cIixzcmM6XCIlaWQlJm91dHB1dD1lbWJlZFwifX19LHByb3RvOntpbml0SWZyYW1lOmZ1bmN0aW9uKCl7bi50eXBlcy5wdXNoKFApLHcoXCJCZWZvcmVDaGFuZ2VcIixmdW5jdGlvbihhLGIsYyl7YiE9PWMmJihiPT09UD9SKCk6Yz09PVAmJlIoITApKX0pLHcoYitcIi5cIitQLGZ1bmN0aW9uKCl7UigpfSl9LGdldElmcmFtZTpmdW5jdGlvbihiLGMpe3ZhciBkPWIuc3JjLGU9bi5zdC5pZnJhbWU7YS5lYWNoKGUucGF0dGVybnMsZnVuY3Rpb24oKXtpZihkLmluZGV4T2YodGhpcy5pbmRleCk+LTEpcmV0dXJuIHRoaXMuaWQmJih0eXBlb2YgdGhpcy5pZD09XCJzdHJpbmdcIj9kPWQuc3Vic3RyKGQubGFzdEluZGV4T2YodGhpcy5pZCkrdGhpcy5pZC5sZW5ndGgsZC5sZW5ndGgpOmQ9dGhpcy5pZC5jYWxsKHRoaXMsZCkpLGQ9dGhpcy5zcmMucmVwbGFjZShcIiVpZCVcIixkKSwhMX0pO3ZhciBmPXt9O3JldHVybiBlLnNyY0FjdGlvbiYmKGZbZS5zcmNBY3Rpb25dPWQpLG4uX3BhcnNlTWFya3VwKGMsZixiKSxuLnVwZGF0ZVN0YXR1cyhcInJlYWR5XCIpLGN9fX0pO3ZhciBTPWZ1bmN0aW9uKGEpe3ZhciBiPW4uaXRlbXMubGVuZ3RoO3JldHVybiBhPmItMT9hLWI6YTwwP2IrYTphfSxUPWZ1bmN0aW9uKGEsYixjKXtyZXR1cm4gYS5yZXBsYWNlKC8lY3VyciUvZ2ksYisxKS5yZXBsYWNlKC8ldG90YWwlL2dpLGMpfTthLm1hZ25pZmljUG9wdXAucmVnaXN0ZXJNb2R1bGUoXCJnYWxsZXJ5XCIse29wdGlvbnM6e2VuYWJsZWQ6ITEsYXJyb3dNYXJrdXA6JzxidXR0b24gdGl0bGU9XCIldGl0bGUlXCIgdHlwZT1cImJ1dHRvblwiIGNsYXNzPVwibWZwLWFycm93IG1mcC1hcnJvdy0lZGlyJVwiPjwvYnV0dG9uPicscHJlbG9hZDpbMCwyXSxuYXZpZ2F0ZUJ5SW1nQ2xpY2s6ITAsYXJyb3dzOiEwLHRQcmV2OlwiUHJldmlvdXMgKExlZnQgYXJyb3cga2V5KVwiLHROZXh0OlwiTmV4dCAoUmlnaHQgYXJyb3cga2V5KVwiLHRDb3VudGVyOlwiJWN1cnIlIG9mICV0b3RhbCVcIn0scHJvdG86e2luaXRHYWxsZXJ5OmZ1bmN0aW9uKCl7dmFyIGM9bi5zdC5nYWxsZXJ5LGQ9XCIubWZwLWdhbGxlcnlcIjtuLmRpcmVjdGlvbj0hMDtpZighY3x8IWMuZW5hYmxlZClyZXR1cm4hMTt1Kz1cIiBtZnAtZ2FsbGVyeVwiLHcoZytkLGZ1bmN0aW9uKCl7Yy5uYXZpZ2F0ZUJ5SW1nQ2xpY2smJm4ud3JhcC5vbihcImNsaWNrXCIrZCxcIi5tZnAtaW1nXCIsZnVuY3Rpb24oKXtpZihuLml0ZW1zLmxlbmd0aD4xKXJldHVybiBuLm5leHQoKSwhMX0pLHMub24oXCJrZXlkb3duXCIrZCxmdW5jdGlvbihhKXthLmtleUNvZGU9PT0zNz9uLnByZXYoKTphLmtleUNvZGU9PT0zOSYmbi5uZXh0KCl9KX0pLHcoXCJVcGRhdGVTdGF0dXNcIitkLGZ1bmN0aW9uKGEsYil7Yi50ZXh0JiYoYi50ZXh0PVQoYi50ZXh0LG4uY3Vyckl0ZW0uaW5kZXgsbi5pdGVtcy5sZW5ndGgpKX0pLHcoZitkLGZ1bmN0aW9uKGEsYixkLGUpe3ZhciBmPW4uaXRlbXMubGVuZ3RoO2QuY291bnRlcj1mPjE/VChjLnRDb3VudGVyLGUuaW5kZXgsZik6XCJcIn0pLHcoXCJCdWlsZENvbnRyb2xzXCIrZCxmdW5jdGlvbigpe2lmKG4uaXRlbXMubGVuZ3RoPjEmJmMuYXJyb3dzJiYhbi5hcnJvd0xlZnQpe3ZhciBiPWMuYXJyb3dNYXJrdXAsZD1uLmFycm93TGVmdD1hKGIucmVwbGFjZSgvJXRpdGxlJS9naSxjLnRQcmV2KS5yZXBsYWNlKC8lZGlyJS9naSxcImxlZnRcIikpLmFkZENsYXNzKG0pLGU9bi5hcnJvd1JpZ2h0PWEoYi5yZXBsYWNlKC8ldGl0bGUlL2dpLGMudE5leHQpLnJlcGxhY2UoLyVkaXIlL2dpLFwicmlnaHRcIikpLmFkZENsYXNzKG0pO2QuY2xpY2soZnVuY3Rpb24oKXtuLnByZXYoKX0pLGUuY2xpY2soZnVuY3Rpb24oKXtuLm5leHQoKX0pLG4uY29udGFpbmVyLmFwcGVuZChkLmFkZChlKSl9fSksdyhoK2QsZnVuY3Rpb24oKXtuLl9wcmVsb2FkVGltZW91dCYmY2xlYXJUaW1lb3V0KG4uX3ByZWxvYWRUaW1lb3V0KSxuLl9wcmVsb2FkVGltZW91dD1zZXRUaW1lb3V0KGZ1bmN0aW9uKCl7bi5wcmVsb2FkTmVhcmJ5SW1hZ2VzKCksbi5fcHJlbG9hZFRpbWVvdXQ9bnVsbH0sMTYpfSksdyhiK2QsZnVuY3Rpb24oKXtzLm9mZihkKSxuLndyYXAub2ZmKFwiY2xpY2tcIitkKSxuLmFycm93UmlnaHQ9bi5hcnJvd0xlZnQ9bnVsbH0pfSxuZXh0OmZ1bmN0aW9uKCl7bi5kaXJlY3Rpb249ITAsbi5pbmRleD1TKG4uaW5kZXgrMSksbi51cGRhdGVJdGVtSFRNTCgpfSxwcmV2OmZ1bmN0aW9uKCl7bi5kaXJlY3Rpb249ITEsbi5pbmRleD1TKG4uaW5kZXgtMSksbi51cGRhdGVJdGVtSFRNTCgpfSxnb1RvOmZ1bmN0aW9uKGEpe24uZGlyZWN0aW9uPWE+PW4uaW5kZXgsbi5pbmRleD1hLG4udXBkYXRlSXRlbUhUTUwoKX0scHJlbG9hZE5lYXJieUltYWdlczpmdW5jdGlvbigpe3ZhciBhPW4uc3QuZ2FsbGVyeS5wcmVsb2FkLGI9TWF0aC5taW4oYVswXSxuLml0ZW1zLmxlbmd0aCksYz1NYXRoLm1pbihhWzFdLG4uaXRlbXMubGVuZ3RoKSxkO2ZvcihkPTE7ZDw9KG4uZGlyZWN0aW9uP2M6Yik7ZCsrKW4uX3ByZWxvYWRJdGVtKG4uaW5kZXgrZCk7Zm9yKGQ9MTtkPD0obi5kaXJlY3Rpb24/YjpjKTtkKyspbi5fcHJlbG9hZEl0ZW0obi5pbmRleC1kKX0sX3ByZWxvYWRJdGVtOmZ1bmN0aW9uKGIpe2I9UyhiKTtpZihuLml0ZW1zW2JdLnByZWxvYWRlZClyZXR1cm47dmFyIGM9bi5pdGVtc1tiXTtjLnBhcnNlZHx8KGM9bi5wYXJzZUVsKGIpKSx5KFwiTGF6eUxvYWRcIixjKSxjLnR5cGU9PT1cImltYWdlXCImJihjLmltZz1hKCc8aW1nIGNsYXNzPVwibWZwLWltZ1wiIC8+Jykub24oXCJsb2FkLm1mcGxvYWRlclwiLGZ1bmN0aW9uKCl7Yy5oYXNTaXplPSEwfSkub24oXCJlcnJvci5tZnBsb2FkZXJcIixmdW5jdGlvbigpe2MuaGFzU2l6ZT0hMCxjLmxvYWRFcnJvcj0hMCx5KFwiTGF6eUxvYWRFcnJvclwiLGMpfSkuYXR0cihcInNyY1wiLGMuc3JjKSksYy5wcmVsb2FkZWQ9ITB9fX0pO3ZhciBVPVwicmV0aW5hXCI7YS5tYWduaWZpY1BvcHVwLnJlZ2lzdGVyTW9kdWxlKFUse29wdGlvbnM6e3JlcGxhY2VTcmM6ZnVuY3Rpb24oYSl7cmV0dXJuIGEuc3JjLnJlcGxhY2UoL1xcLlxcdyskLyxmdW5jdGlvbihhKXtyZXR1cm5cIkAyeFwiK2F9KX0scmF0aW86MX0scHJvdG86e2luaXRSZXRpbmE6ZnVuY3Rpb24oKXtpZih3aW5kb3cuZGV2aWNlUGl4ZWxSYXRpbz4xKXt2YXIgYT1uLnN0LnJldGluYSxiPWEucmF0aW87Yj1pc05hTihiKT9iKCk6YixiPjEmJih3KFwiSW1hZ2VIYXNTaXplLlwiK1UsZnVuY3Rpb24oYSxjKXtjLmltZy5jc3Moe1wibWF4LXdpZHRoXCI6Yy5pbWdbMF0ubmF0dXJhbFdpZHRoL2Isd2lkdGg6XCIxMDAlXCJ9KX0pLHcoXCJFbGVtZW50UGFyc2UuXCIrVSxmdW5jdGlvbihjLGQpe2Quc3JjPWEucmVwbGFjZVNyYyhkLGIpfSkpfX19fSksQSgpfSkiLCIvKipcbiAqIEZpbGUganMtZW5hYmxlZC5qc1xuICpcbiAqIElmIEphdmFzY3JpcHQgaXMgZW5hYmxlZCwgcmVwbGFjZSB0aGUgPGJvZHk+IGNsYXNzIFwibm8tanNcIi5cbiAqL1xuZG9jdW1lbnQuYm9keS5jbGFzc05hbWUgPSBkb2N1bWVudC5ib2R5LmNsYXNzTmFtZS5yZXBsYWNlKCAnbm8tanMnLCAnanMnICk7IiwiLyoqXG4gKiBGaWxlIG1vZGFsLmpzXG4gKlxuICogRGVhbCB3aXRoIG11bHRpcGxlIG1vZGFscyBhbmQgdGhlaXIgbWVkaWEuXG4gKi9cbndpbmRvdy5XRFNfTW9kYWwgPSB7fTtcblxuKCBmdW5jdGlvbiAoIHdpbmRvdywgJCwgYXBwICkge1xuXG5cdC8vIENvbnN0cnVjdG9yLlxuXHRhcHAuaW5pdCA9IGZ1bmN0aW9uKCkge1xuXHRcdGFwcC5jYWNoZSgpO1xuXG5cdFx0aWYgKCBhcHAubWVldHNSZXF1aXJlbWVudHMoKSApIHtcblx0XHRcdGFwcC5iaW5kRXZlbnRzKCk7XG5cdFx0fVxuXHR9O1xuXG5cdC8vIENhY2hlIGFsbCB0aGUgdGhpbmdzLlxuXHRhcHAuY2FjaGUgPSBmdW5jdGlvbigpIHtcblx0XHRhcHAuJGMgPSB7XG5cdFx0XHRib2R5OiAkKCAnYm9keScgKSxcblx0XHR9O1xuXHR9O1xuXG5cdC8vIERvIHdlIG1lZXQgdGhlIHJlcXVpcmVtZW50cz9cblx0YXBwLm1lZXRzUmVxdWlyZW1lbnRzID0gZnVuY3Rpb24oKSB7XG5cdFx0cmV0dXJuICQoICcubW9kYWwtdHJpZ2dlcicgKS5sZW5ndGg7XG5cdH07XG5cblx0Ly8gQ29tYmluZSBhbGwgZXZlbnRzLlxuXHRhcHAuYmluZEV2ZW50cyA9IGZ1bmN0aW9uKCkge1xuXG5cdFx0Ly8gVHJpZ2VyIGEgbW9kYWwgdG8gb3BlblxuXHRcdGFwcC4kYy5ib2R5Lm9uKCAnY2xpY2snLCAnLm1vZGFsLXRyaWdnZXInLCBhcHAub3Blbk1vZGFsICk7XG5cblx0XHQvLyBUcmlnZ2VyIHRoZSBjbG9zZSBidXR0b24gdG8gY2xvc2UgdGhlIG1vZGFsXG5cdFx0YXBwLiRjLmJvZHkub24oICdjbGljaycsICcuY2xvc2UnLCBhcHAuY2xvc2VNb2RhbCApO1xuXG5cdFx0Ly8gQWxsb3cgdGhlIHVzZXIgdG8gY2xvc2UgdGhlIG1vZGFsIGJ5IGhpdHRpbmcgdGhlIGVzYyBrZXlcblx0XHRhcHAuJGMuYm9keS5vbiggJ2tleWRvd24nLCBhcHAuZXNjS2V5Q2xvc2UgKTtcblxuXHRcdC8vIEFsbG93IHRoZSB1c2VyIHRvIGNsb3NlIHRoZSBtb2RhbCBieSBjbGlja2luZyBvdXRzaWRlIG9mIHRoZSBtb2RhbFxuXHRcdGFwcC4kYy5ib2R5Lm9uKCAnY2xpY2snLCAnZGl2Lm1vZGFsLW9wZW4nLCBhcHAuY2xvc2VNb2RhbEJ5Q2xpY2sgKTtcblx0fTtcblxuXHQvLyBPcGVuIHRoZSBtb2RhbC5cblx0YXBwLm9wZW5Nb2RhbCA9IGZ1bmN0aW9uKCkge1xuXG5cdFx0Ly8gRmlndXJlIG91dCB3aGljaCBtb2RhbCB3ZSdyZSBvcGVuaW5nIGFuZCBzdG9yZSB0aGUgb2JqZWN0LlxuXHRcdHZhciAkbW9kYWwgPSAkKCAkKCB0aGlzICkuZGF0YSggJ3RhcmdldCcgKSApO1xuXG5cdFx0Ly8gRGlzcGxheSB0aGUgbW9kYWwuXG5cdFx0JG1vZGFsLmFkZENsYXNzKCAnbW9kYWwtb3BlbicgKTtcblxuXHRcdC8vIEFkZCBib2R5IGNsYXNzLlxuXHRcdGFwcC4kYy5ib2R5LmFkZENsYXNzKCAnbW9kYWwtb3BlbicgKTtcblx0fTtcblxuXHQvLyBDbG9zZSB0aGUgbW9kYWwuXG5cdGFwcC5jbG9zZU1vZGFsID0gZnVuY3Rpb24oKSB7XG5cblx0XHQvLyBGaWd1cmUgdGhlIG9wZW5lZCBtb2RhbCB3ZSdyZSBjbG9zaW5nIGFuZCBzdG9yZSB0aGUgb2JqZWN0LlxuXHRcdHZhciAkbW9kYWwgPSAkKCAkKCAnZGl2Lm1vZGFsLW9wZW4gLmNsb3NlJyApLmRhdGEoICd0YXJnZXQnICkgKTtcblxuXHRcdC8vIEZpbmQgdGhlIGlmcmFtZSBpbiB0aGUgJG1vZGFsIG9iamVjdC5cblx0XHR2YXIgJGlmcmFtZSA9ICRtb2RhbC5maW5kKCAnaWZyYW1lJyApO1xuXG5cdFx0Ly8gR2V0IHRoZSBpZnJhbWUgc3JjIFVSTC5cblx0XHR2YXIgdXJsID0gJGlmcmFtZS5hdHRyKCAnc3JjJyApO1xuXG5cdFx0Ly8gUmVtb3ZlIHRoZSBzb3VyY2UgVVJMLCB0aGVuIGFkZCBpdCBiYWNrLCBzbyB0aGUgdmlkZW8gY2FuIGJlIHBsYXllZCBhZ2FpbiBsYXRlci5cblx0XHQkaWZyYW1lLmF0dHIoICdzcmMnLCAnJyApLmF0dHIoICdzcmMnLCB1cmwgKTtcblxuXHRcdC8vIEZpbmFsbHksIGhpZGUgdGhlIG1vZGFsLlxuXHRcdCRtb2RhbC5yZW1vdmVDbGFzcyggJ21vZGFsLW9wZW4nICk7XG5cblx0XHQvLyBSZW1vdmUgdGhlIGJvZHkgY2xhc3MuXG5cdFx0YXBwLiRjLmJvZHkucmVtb3ZlQ2xhc3MoICdtb2RhbC1vcGVuJyApO1xuXHR9O1xuXG5cdC8vIENsb3NlIGlmIFwiZXNjXCIga2V5IGlzIHByZXNzZWQuXG5cdGFwcC5lc2NLZXlDbG9zZSA9IGZ1bmN0aW9uKGUpIHtcblx0XHRpZiAoIDI3ID09IGUua2V5Q29kZSApIHtcblx0XHRcdGFwcC5jbG9zZU1vZGFsKCk7XG5cdFx0fVxuXHR9O1xuXG5cdC8vIENsb3NlIGlmIHRoZSB1c2VyIGNsaWNrcyBvdXRzaWRlIG9mIHRoZSBtb2RhbFxuXHRhcHAuY2xvc2VNb2RhbEJ5Q2xpY2sgPSBmdW5jdGlvbihlKSB7XG5cblx0XHQvLyBJZiB0aGUgcGFyZW50IGNvbnRhaW5lciBpcyBOT1QgdGhlIG1vZGFsIGRpYWxvZyBjb250YWluZXIsIGNsb3NlIHRoZSBtb2RhbFxuXHRcdGlmICggISAkKCBlLnRhcmdldCApLnBhcmVudHMoICdkaXYnICkuaGFzQ2xhc3MoICdtb2RhbC1kaWFsb2cnICkgKSB7XG5cdFx0XHRhcHAuY2xvc2VNb2RhbCgpO1xuXHRcdH1cblx0fTtcblxuXHQvLyBFbmdhZ2UhXG5cdCQoIGFwcC5pbml0ICk7XG5cbn0gKSggd2luZG93LCBqUXVlcnksIHdpbmRvdy5XRFNfTW9kYWwgKTsiLCIvKlxyXG5cdHNjcmlwdHMuanNcclxuXHJcblx0TGljZW5zZTogR05VIEdlbmVyYWwgUHVibGljIExpY2Vuc2UgdjMuMFxyXG5cdExpY2Vuc2UgVVJJOiBodHRwOi8vd3d3LmdudS5vcmcvbGljZW5zZXMvZ3BsLTMuMC5odG1sXHJcblxyXG5cdENvcHlyaWdodDogKGMpIDIwMTMgQWxleGFuZGVyIFwiQWx4XCIgQWduYXJzb24sIGh0dHA6Ly9hbHhtZWRpYS5zZVxyXG4qL1xyXG5cclxuXCJ1c2Ugc3RyaWN0XCI7XHJcblxyXG5qUXVlcnkoZG9jdW1lbnQpLnJlYWR5KGZ1bmN0aW9uKCQpIHtcclxuXHJcblxyXG4kKCcubGF6eWxvYWQnKS5sYXp5bG9hZCh7XHJcbiAgLy8gU2V0cyB0aGUgcGl4ZWxzIHRvIGxvYWQgZWFybGllci4gU2V0dGluZyB0aHJlc2hvbGQgdG8gMjAwIGNhdXNlcyBpbWFnZSB0byBsb2FkIDIwMCBwaXhlbHNcclxuICAvLyBiZWZvcmUgaXQgYXBwZWFycyBvbiB2aWV3cG9ydC4gSXQgc2hvdWxkIGJlIGdyZWF0ZXIgb3IgZXF1YWwgemVyby5cclxuICB0aHJlc2hvbGQ6IDAsXHJcblxyXG4gIC8vIFNldHMgdGhlIGNhbGxiYWNrIGZ1bmN0aW9uIHdoZW4gdGhlIGxvYWQgZXZlbnQgaXMgZmlyaW5nLlxyXG4gIC8vIGVsZW1lbnQ6IFRoZSBjb250ZW50IGluIGxhenlsb2FkIHRhZyB3aWxsIGJlIHJldHVybmVkIGFzIGEgalF1ZXJ5IG9iamVjdC5cclxuICBsb2FkOiBmdW5jdGlvbihlbGVtZW50KSB7fSxcclxuXHJcbiAgLy8gU2V0cyBldmVudHMgdG8gdHJpZ2dlciBsYXp5bG9hZC4gRGVmYXVsdCBpcyBjdXN0b21pemVkIGV2ZW50IGBhcHBlYXJgLCBpdCB3aWxsIHRyaWdnZXIgd2hlblxyXG4gIC8vIGVsZW1lbnQgYXBwZWFyIGluIHNjcmVlbi4gWW91IGNvdWxkIHNldCBvdGhlciBldmVudHMgaW5jbHVkaW5nIGVhY2ggb25lIHNlcGFyYXRlZCBieSBhIHNwYWNlLlxyXG4gIHRyaWdnZXI6IFwiYXBwZWFyIHRvdWNoc3RhcnRcIlxyXG59KTtcclxuXHJcbi8vICQoJy5saWdodGJveCcpLm1hZ25pZmljUG9wdXAoe3R5cGU6J2ltYWdlJ30pO1xyXG4vLyAkKCcud3BiLW1vZGFsLWltYWdlJykubWFnbmlmaWNQb3B1cCh7dHlwZTonaW1hZ2UnfSk7XHJcblxyXG5qUXVlcnkoICdhcnRpY2xlJyApLm1hZ25pZmljUG9wdXAoe1xyXG4gICAgICAgIHR5cGU6ICdpbWFnZScsXHJcbiAgICAgICAgZGVsZWdhdGU6IFwiLndwYi1tb2RhbC1pbWFnZVwiLFxyXG4gICAgICAgIGdhbGxlcnk6IHtcclxuICAgICAgICAgICAgZW5hYmxlZDogdHJ1ZSxcclxuICAgICAgICAgICAgcHJlbG9hZDogWzAsMl0sXHJcblx0XHRcdG5hdmlnYXRlQnlJbWdDbGljazogdHJ1ZSxcclxuXHRcdFx0YXJyb3dNYXJrdXA6ICc8c3BhbiBjbGFzcz1cIm1mcC1hcnJvdyBtZnAtYXJyb3ctJWRpciVcIiB0aXRsZT1cIiV0aXRsZSVcIj48aSBjbGFzcz1cImZhIGZhLTJ4IGZhLWFuZ2xlLSVkaXIlXCI+PC9pPjwvc3Bhbj4nLFxyXG5cdFx0XHR0UHJldjogJ1ByZXZpb3VzJyxcclxuXHRcdFx0dE5leHQ6ICdOZXh0JyxcclxuXHRcdFx0dENvdW50ZXI6ICc8c3BhbiBjbGFzcz1cIm1mcC1jb3VudGVyXCI+JWN1cnIlIG9mICV0b3RhbCU8L3NwYW4+J1xyXG4gICAgICAgIH0sXHJcbn0pO1xyXG5cclxuLyogIFRvZ2dsZSBoZWFkZXIgc2VhcmNoXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cdCQoJy50b2dnbGUtc2VhcmNoJykuY2xpY2soZnVuY3Rpb24oKXtcclxuXHRcdCQoJy50b2dnbGUtc2VhcmNoJykudG9nZ2xlQ2xhc3MoJ2FjdGl2ZScpO1xyXG5cdFx0JCgnLnNlYXJjaC1leHBhbmQnKS5mYWRlVG9nZ2xlKDI1MCk7XHJcbiAgICAgICAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKXtcclxuICAgICAgICAgICAgICAgICQoJy5zZWFyY2gtZXhwYW5kIGlucHV0JykuZm9jdXMoKTtcclxuICAgICAgICAgICAgfSwgMzAwKTtcclxuXHR9KTtcclxuXHJcbi8qICBTY3JvbGwgdG8gdG9wXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cdCQoJ2EjZ290b3RvcCcpLmNsaWNrKGZ1bmN0aW9uKCkge1xyXG5cdFx0JCgnaHRtbCwgYm9keScpLmFuaW1hdGUoe3Njcm9sbFRvcDowfSwnc2xvdycpO1xyXG5cdFx0cmV0dXJuIGZhbHNlO1xyXG5cdH0pO1xyXG5cclxuLyogIENvbW1lbnRzIC8gcGluZ2JhY2tzIHRhYnNcclxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcbiAgICAkKFwiLnRhYnMgLnRhYnMtdGl0bGVcIikuY2xpY2soZnVuY3Rpb24oKSB7XHJcbiAgICAgICAgJChcIi50YWJzIC50YWJzLXRpdGxlXCIpLnJlbW92ZUNsYXNzKCdpcy1hY3RpdmUnKTtcclxuICAgICAgICAkKHRoaXMpLmFkZENsYXNzKFwiaXMtYWN0aXZlXCIpO1xyXG4gICAgICAgICQoXCIudGFicy1jb250ZW50IC50YWJzLXBhbmVsXCIpLnJlbW92ZUNsYXNzKCdpcy1hY3RpdmUnKS5oaWRlKCk7XHJcbiAgICAgICAgdmFyIHNlbGVjdGVkX3RhYiA9ICQodGhpcykuZmluZChcImFcIikuYXR0cihcImhyZWZcIik7XHJcbiAgICAgICAgJChzZWxlY3RlZF90YWIpLmZhZGVJbigpO1xyXG4gICAgICAgIGNvbnNvbGUubG9nKHNlbGVjdGVkX3RhYik7XHJcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xyXG4gICAgfSk7XHJcblxyXG4vKiAgVGFibGUgb2RkIHJvdyBjbGFzc1xyXG4vKiAtLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0gKi9cclxuXHQkKCd0YWJsZSB0cjpvZGQnKS5hZGRDbGFzcygnYWx0Jyk7XHJcblxyXG5cclxuLyogIERyb3Bkb3duIG1lbnUgYW5pbWF0aW9uXHJcbi8qIC0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLSAqL1xyXG5cdCQoJy5uYXYgdWwuc3ViLW1lbnUnKS5oaWRlKCk7XHJcblx0JCgnLm5hdiBsaScpLmhvdmVyKFxyXG5cdFx0ZnVuY3Rpb24oKSB7XHJcblx0XHRcdCQodGhpcykuY2hpbGRyZW4oJ3VsLnN1Yi1tZW51Jykuc2xpZGVEb3duKCdmYXN0Jyk7XHJcblx0XHR9LFxyXG5cdFx0ZnVuY3Rpb24oKSB7XHJcblx0XHRcdCQodGhpcykuY2hpbGRyZW4oJ3VsLnN1Yi1tZW51JykuaGlkZSgpO1xyXG5cdFx0fVxyXG5cdCk7XHJcblxyXG4vKiAgTW9iaWxlIG1lbnUgc21vb3RoIHRvZ2dsZSBoZWlnaHRcclxuLyogLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tICovXHJcblx0JCgnLm5hdi10b2dnbGUnKS5vbignY2xpY2snLCBmdW5jdGlvbigpIHtcclxuXHRcdHNsaWRlKCQoJy5uYXYtd3JhcCAubmF2JywgJCh0aGlzKS5wYXJlbnQoKSkpO1xyXG5cdH0pO1xyXG5cclxuXHRmdW5jdGlvbiBzbGlkZShjb250ZW50KSB7XHJcblx0XHR2YXIgd3JhcHBlciA9IGNvbnRlbnQucGFyZW50KCk7XHJcblx0XHR2YXIgY29udGVudEhlaWdodCA9IGNvbnRlbnQub3V0ZXJIZWlnaHQodHJ1ZSk7XHJcblx0XHR2YXIgd3JhcHBlckhlaWdodCA9IHdyYXBwZXIuaGVpZ2h0KCk7XHJcblxyXG5cdFx0d3JhcHBlci50b2dnbGVDbGFzcygnZXhwYW5kJyk7XHJcblx0XHRpZiAod3JhcHBlci5oYXNDbGFzcygnZXhwYW5kJykpIHtcclxuXHRcdHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdHdyYXBwZXIuYWRkQ2xhc3MoJ3RyYW5zaXRpb24nKS5jc3MoJ2hlaWdodCcsIGNvbnRlbnRIZWlnaHQpO1xyXG5cdFx0fSwgMTApO1xyXG5cdH1cclxuXHRlbHNlIHtcclxuXHRcdHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XHJcblx0XHRcdHdyYXBwZXIuY3NzKCdoZWlnaHQnLCB3cmFwcGVySGVpZ2h0KTtcclxuXHRcdFx0c2V0VGltZW91dChmdW5jdGlvbigpIHtcclxuXHRcdFx0d3JhcHBlci5hZGRDbGFzcygndHJhbnNpdGlvbicpLmNzcygnaGVpZ2h0JywgMCk7XHJcblx0XHRcdH0sIDEwKTtcclxuXHRcdH0sIDEwKTtcclxuXHR9XHJcblxyXG5cdHdyYXBwZXIub25lKCd0cmFuc2l0aW9uRW5kIHdlYmtpdFRyYW5zaXRpb25FbmQgdHJhbnNpdGlvbmVuZCBvVHJhbnNpdGlvbkVuZCBtc1RyYW5zaXRpb25FbmQnLCBmdW5jdGlvbigpIHtcclxuXHRcdGlmKHdyYXBwZXIuaGFzQ2xhc3MoJ29wZW4nKSkge1xyXG5cdFx0XHR3cmFwcGVyLnJlbW92ZUNsYXNzKCd0cmFuc2l0aW9uJykuY3NzKCdoZWlnaHQnLCAnYXV0bycpO1xyXG5cdFx0fVxyXG5cdH0pO1xyXG5cdH1cclxuXHJcbn0pOyIsIi8qKlxuICogRmlsZSBzZWFyY2guanNcbiAqXG4gKiBEZWFsIHdpdGggdGhlIHNlYXJjaCBmb3JtLlxuICovXG53aW5kb3cuV0RTX1NlYXJjaCA9IHt9O1xuXG4oIGZ1bmN0aW9uICggd2luZG93LCAkLCBhcHAgKSB7XG5cblx0Ly8gQ29uc3RydWN0b3IuXG5cdGFwcC5pbml0ID0gZnVuY3Rpb24oKSB7XG5cdFx0YXBwLmNhY2hlKCk7XG5cblx0XHRpZiAoIGFwcC5tZWV0c1JlcXVpcmVtZW50cygpICkge1xuXHRcdFx0YXBwLmJpbmRFdmVudHMoKTtcblx0XHR9XG5cdH07XG5cblx0Ly8gQ2FjaGUgYWxsIHRoZSB0aGluZ3MuXG5cdGFwcC5jYWNoZSA9IGZ1bmN0aW9uKCkge1xuXHRcdGFwcC4kYyA9IHtcblx0XHRcdGJvZHk6ICQoICdib2R5JyApLFxuXHRcdH07XG5cdH07XG5cblx0Ly8gRG8gd2UgbWVldCB0aGUgcmVxdWlyZW1lbnRzP1xuXHRhcHAubWVldHNSZXF1aXJlbWVudHMgPSBmdW5jdGlvbigpIHtcblx0XHRyZXR1cm4gJCggJy5zZWFyY2gtZmllbGQnICkubGVuZ3RoO1xuXHR9O1xuXG5cdC8vIENvbWJpbmUgYWxsIGV2ZW50cy5cblx0YXBwLmJpbmRFdmVudHMgPSBmdW5jdGlvbigpIHtcblxuXHRcdC8vIFJlbW92ZSBwbGFjZWhvbGRlciB0ZXh0IGZyb20gc2VhcmNoIGZpZWxkIG9uIGZvY3VzLlxuXHRcdGFwcC4kYy5ib2R5Lm9uKCAnZm9jdXMnLCAnLnNlYXJjaC1maWVsZCcsIGFwcC5yZW1vdmVQbGFjZWhvbGRlclRleHQgKTtcblxuXHRcdC8vIEFkZCBwbGFjZWhvbGRlciB0ZXh0IGJhY2sgdG8gc2VhcmNoIGZpZWxkIG9uIGJsdXIuXG5cdFx0YXBwLiRjLmJvZHkub24oICdibHVyJywgJy5zZWFyY2gtZmllbGQnLCBhcHAuYWRkUGxhY2Vob2xkZXJUZXh0ICk7XG5cdH07XG5cblx0Ly8gUmVtb3ZlIHBsYWNlaG9sZGVyIHRleHQgZnJvbSBzZWFyY2ggZmllbGQuXG5cdGFwcC5yZW1vdmVQbGFjZWhvbGRlclRleHQgPSBmdW5jdGlvbigpIHtcblxuXHRcdHZhciAkc2VhcmNoX2ZpZWxkID0gJCggdGhpcyApO1xuXG5cdFx0JHNlYXJjaF9maWVsZC5kYXRhKCAncGxhY2Vob2xkZXInLCAkc2VhcmNoX2ZpZWxkLmF0dHIoICdwbGFjZWhvbGRlcicgKSApLmF0dHIoICdwbGFjZWhvbGRlcicsICcnICk7XG5cdH07XG5cblx0Ly8gUmVwbGFjZSBwbGFjZWhvbGRlciB0ZXh0IGZyb20gc2VhcmNoIGZpZWxkLlxuXHRhcHAuYWRkUGxhY2Vob2xkZXJUZXh0ID0gZnVuY3Rpb24oKSB7XG5cblx0XHR2YXIgJHNlYXJjaF9maWVsZCA9ICQoIHRoaXMgKTtcblxuXHRcdCRzZWFyY2hfZmllbGQuYXR0ciggJ3BsYWNlaG9sZGVyJywgJHNlYXJjaF9maWVsZC5kYXRhKCAncGxhY2Vob2xkZXInICkgKS5kYXRhKCAncGxhY2Vob2xkZXInLCAnJyApO1xuXHR9O1xuXG5cdC8vIEVuZ2FnZSFcblx0JCggYXBwLmluaXQgKTtcblxufSApKCB3aW5kb3csIGpRdWVyeSwgd2luZG93LldEU19TZWFyY2ggKTsiLCIvKipcbiAqIEZpbGUgc2tpcC1saW5rLWZvY3VzLWZpeC5qcy5cbiAqXG4gKiBIZWxwcyB3aXRoIGFjY2Vzc2liaWxpdHkgZm9yIGtleWJvYXJkIG9ubHkgdXNlcnMuXG4gKlxuICogTGVhcm4gbW9yZTogaHR0cHM6Ly9naXQuaW8vdldkcjJcbiAqL1xuKCBmdW5jdGlvbigpIHtcblx0dmFyIGlzV2Via2l0ID0gbmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpLmluZGV4T2YoICd3ZWJraXQnICkgPiAtMSxcblx0ICAgIGlzT3BlcmEgID0gbmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpLmluZGV4T2YoICdvcGVyYScgKSAgPiAtMSxcblx0ICAgIGlzSWUgICAgID0gbmF2aWdhdG9yLnVzZXJBZ2VudC50b0xvd2VyQ2FzZSgpLmluZGV4T2YoICdtc2llJyApICAgPiAtMTtcblxuXHRpZiAoICggaXNXZWJraXQgfHwgaXNPcGVyYSB8fCBpc0llICkgJiYgZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQgJiYgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIgKSB7XG5cdFx0d2luZG93LmFkZEV2ZW50TGlzdGVuZXIoICdoYXNoY2hhbmdlJywgZnVuY3Rpb24oKSB7XG5cdFx0XHR2YXIgaWQgPSBsb2NhdGlvbi5oYXNoLnN1YnN0cmluZyggMSApLFxuXHRcdFx0XHRlbGVtZW50O1xuXG5cdFx0XHRpZiAoICEgKCAvXltBLXowLTlfLV0rJC8udGVzdCggaWQgKSApICkge1xuXHRcdFx0XHRyZXR1cm47XG5cdFx0XHR9XG5cblx0XHRcdGVsZW1lbnQgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZCggaWQgKTtcblxuXHRcdFx0aWYgKCBlbGVtZW50ICkge1xuXHRcdFx0XHRpZiAoICEgKCAvXig/OmF8c2VsZWN0fGlucHV0fGJ1dHRvbnx0ZXh0YXJlYSkkL2kudGVzdCggZWxlbWVudC50YWdOYW1lICkgKSApIHtcblx0XHRcdFx0XHRlbGVtZW50LnRhYkluZGV4ID0gLTE7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRlbGVtZW50LmZvY3VzKCk7XG5cdFx0XHR9XG5cdFx0fSwgZmFsc2UgKTtcblx0fVxufSkoKTsiLCIvKlxuICAgICBfIF8gICAgICBfICAgICAgIF9cbiBfX198IChfKSBfX198IHwgX18gIChfKV9fX1xuLyBfX3wgfCB8LyBfX3wgfC8gLyAgfCAvIF9ffFxuXFxfXyBcXCB8IHwgKF9ffCAgIDwgXyB8IFxcX18gXFxcbnxfX18vX3xffFxcX19ffF98XFxfKF8pLyB8X19fL1xuICAgICAgICAgICAgICAgICAgIHxfXy9cblxuIFZlcnNpb246IDEuNi4wXG4gIEF1dGhvcjogS2VuIFdoZWVsZXJcbiBXZWJzaXRlOiBodHRwOi8va2Vud2hlZWxlci5naXRodWIuaW9cbiAgICBEb2NzOiBodHRwOi8va2Vud2hlZWxlci5naXRodWIuaW8vc2xpY2tcbiAgICBSZXBvOiBodHRwOi8vZ2l0aHViLmNvbS9rZW53aGVlbGVyL3NsaWNrXG4gIElzc3VlczogaHR0cDovL2dpdGh1Yi5jb20va2Vud2hlZWxlci9zbGljay9pc3N1ZXNcblxuICovXG4hZnVuY3Rpb24oYSl7XCJ1c2Ugc3RyaWN0XCI7XCJmdW5jdGlvblwiPT10eXBlb2YgZGVmaW5lJiZkZWZpbmUuYW1kP2RlZmluZShbXCJqcXVlcnlcIl0sYSk6XCJ1bmRlZmluZWRcIiE9dHlwZW9mIGV4cG9ydHM/bW9kdWxlLmV4cG9ydHM9YShyZXF1aXJlKFwianF1ZXJ5XCIpKTphKGpRdWVyeSl9KGZ1bmN0aW9uKGEpe1widXNlIHN0cmljdFwiO3ZhciBiPXdpbmRvdy5TbGlja3x8e307Yj1mdW5jdGlvbigpe2Z1bmN0aW9uIGMoYyxkKXt2YXIgZixlPXRoaXM7ZS5kZWZhdWx0cz17YWNjZXNzaWJpbGl0eTohMCxhZGFwdGl2ZUhlaWdodDohMSxhcHBlbmRBcnJvd3M6YShjKSxhcHBlbmREb3RzOmEoYyksYXJyb3dzOiEwLGFzTmF2Rm9yOm51bGwscHJldkFycm93Oic8YnV0dG9uIHR5cGU9XCJidXR0b25cIiBkYXRhLXJvbGU9XCJub25lXCIgY2xhc3M9XCJzbGljay1wcmV2XCIgYXJpYS1sYWJlbD1cIlByZXZpb3VzXCIgdGFiaW5kZXg9XCIwXCIgcm9sZT1cImJ1dHRvblwiPlByZXZpb3VzPC9idXR0b24+JyxuZXh0QXJyb3c6JzxidXR0b24gdHlwZT1cImJ1dHRvblwiIGRhdGEtcm9sZT1cIm5vbmVcIiBjbGFzcz1cInNsaWNrLW5leHRcIiBhcmlhLWxhYmVsPVwiTmV4dFwiIHRhYmluZGV4PVwiMFwiIHJvbGU9XCJidXR0b25cIj5OZXh0PC9idXR0b24+JyxhdXRvcGxheTohMSxhdXRvcGxheVNwZWVkOjNlMyxjZW50ZXJNb2RlOiExLGNlbnRlclBhZGRpbmc6XCI1MHB4XCIsY3NzRWFzZTpcImVhc2VcIixjdXN0b21QYWdpbmc6ZnVuY3Rpb24oYixjKXtyZXR1cm4gYSgnPGJ1dHRvbiB0eXBlPVwiYnV0dG9uXCIgZGF0YS1yb2xlPVwibm9uZVwiIHJvbGU9XCJidXR0b25cIiB0YWJpbmRleD1cIjBcIiAvPicpLnRleHQoYysxKX0sZG90czohMSxkb3RzQ2xhc3M6XCJzbGljay1kb3RzXCIsZHJhZ2dhYmxlOiEwLGVhc2luZzpcImxpbmVhclwiLGVkZ2VGcmljdGlvbjouMzUsZmFkZTohMSxmb2N1c09uU2VsZWN0OiExLGluZmluaXRlOiEwLGluaXRpYWxTbGlkZTowLGxhenlMb2FkOlwib25kZW1hbmRcIixtb2JpbGVGaXJzdDohMSxwYXVzZU9uSG92ZXI6ITAscGF1c2VPbkZvY3VzOiEwLHBhdXNlT25Eb3RzSG92ZXI6ITEscmVzcG9uZFRvOlwid2luZG93XCIscmVzcG9uc2l2ZTpudWxsLHJvd3M6MSxydGw6ITEsc2xpZGU6XCJcIixzbGlkZXNQZXJSb3c6MSxzbGlkZXNUb1Nob3c6MSxzbGlkZXNUb1Njcm9sbDoxLHNwZWVkOjUwMCxzd2lwZTohMCxzd2lwZVRvU2xpZGU6ITEsdG91Y2hNb3ZlOiEwLHRvdWNoVGhyZXNob2xkOjUsdXNlQ1NTOiEwLHVzZVRyYW5zZm9ybTohMCx2YXJpYWJsZVdpZHRoOiExLHZlcnRpY2FsOiExLHZlcnRpY2FsU3dpcGluZzohMSx3YWl0Rm9yQW5pbWF0ZTohMCx6SW5kZXg6MWUzfSxlLmluaXRpYWxzPXthbmltYXRpbmc6ITEsZHJhZ2dpbmc6ITEsYXV0b1BsYXlUaW1lcjpudWxsLGN1cnJlbnREaXJlY3Rpb246MCxjdXJyZW50TGVmdDpudWxsLGN1cnJlbnRTbGlkZTowLGRpcmVjdGlvbjoxLCRkb3RzOm51bGwsbGlzdFdpZHRoOm51bGwsbGlzdEhlaWdodDpudWxsLGxvYWRJbmRleDowLCRuZXh0QXJyb3c6bnVsbCwkcHJldkFycm93Om51bGwsc2xpZGVDb3VudDpudWxsLHNsaWRlV2lkdGg6bnVsbCwkc2xpZGVUcmFjazpudWxsLCRzbGlkZXM6bnVsbCxzbGlkaW5nOiExLHNsaWRlT2Zmc2V0OjAsc3dpcGVMZWZ0Om51bGwsJGxpc3Q6bnVsbCx0b3VjaE9iamVjdDp7fSx0cmFuc2Zvcm1zRW5hYmxlZDohMSx1bnNsaWNrZWQ6ITF9LGEuZXh0ZW5kKGUsZS5pbml0aWFscyksZS5hY3RpdmVCcmVha3BvaW50PW51bGwsZS5hbmltVHlwZT1udWxsLGUuYW5pbVByb3A9bnVsbCxlLmJyZWFrcG9pbnRzPVtdLGUuYnJlYWtwb2ludFNldHRpbmdzPVtdLGUuY3NzVHJhbnNpdGlvbnM9ITEsZS5mb2N1c3NlZD0hMSxlLmludGVycnVwdGVkPSExLGUuaGlkZGVuPVwiaGlkZGVuXCIsZS5wYXVzZWQ9ITAsZS5wb3NpdGlvblByb3A9bnVsbCxlLnJlc3BvbmRUbz1udWxsLGUucm93Q291bnQ9MSxlLnNob3VsZENsaWNrPSEwLGUuJHNsaWRlcj1hKGMpLGUuJHNsaWRlc0NhY2hlPW51bGwsZS50cmFuc2Zvcm1UeXBlPW51bGwsZS50cmFuc2l0aW9uVHlwZT1udWxsLGUudmlzaWJpbGl0eUNoYW5nZT1cInZpc2liaWxpdHljaGFuZ2VcIixlLndpbmRvd1dpZHRoPTAsZS53aW5kb3dUaW1lcj1udWxsLGY9YShjKS5kYXRhKFwic2xpY2tcIil8fHt9LGUub3B0aW9ucz1hLmV4dGVuZCh7fSxlLmRlZmF1bHRzLGQsZiksZS5jdXJyZW50U2xpZGU9ZS5vcHRpb25zLmluaXRpYWxTbGlkZSxlLm9yaWdpbmFsU2V0dGluZ3M9ZS5vcHRpb25zLFwidW5kZWZpbmVkXCIhPXR5cGVvZiBkb2N1bWVudC5tb3pIaWRkZW4/KGUuaGlkZGVuPVwibW96SGlkZGVuXCIsZS52aXNpYmlsaXR5Q2hhbmdlPVwibW96dmlzaWJpbGl0eWNoYW5nZVwiKTpcInVuZGVmaW5lZFwiIT10eXBlb2YgZG9jdW1lbnQud2Via2l0SGlkZGVuJiYoZS5oaWRkZW49XCJ3ZWJraXRIaWRkZW5cIixlLnZpc2liaWxpdHlDaGFuZ2U9XCJ3ZWJraXR2aXNpYmlsaXR5Y2hhbmdlXCIpLGUuYXV0b1BsYXk9YS5wcm94eShlLmF1dG9QbGF5LGUpLGUuYXV0b1BsYXlDbGVhcj1hLnByb3h5KGUuYXV0b1BsYXlDbGVhcixlKSxlLmF1dG9QbGF5SXRlcmF0b3I9YS5wcm94eShlLmF1dG9QbGF5SXRlcmF0b3IsZSksZS5jaGFuZ2VTbGlkZT1hLnByb3h5KGUuY2hhbmdlU2xpZGUsZSksZS5jbGlja0hhbmRsZXI9YS5wcm94eShlLmNsaWNrSGFuZGxlcixlKSxlLnNlbGVjdEhhbmRsZXI9YS5wcm94eShlLnNlbGVjdEhhbmRsZXIsZSksZS5zZXRQb3NpdGlvbj1hLnByb3h5KGUuc2V0UG9zaXRpb24sZSksZS5zd2lwZUhhbmRsZXI9YS5wcm94eShlLnN3aXBlSGFuZGxlcixlKSxlLmRyYWdIYW5kbGVyPWEucHJveHkoZS5kcmFnSGFuZGxlcixlKSxlLmtleUhhbmRsZXI9YS5wcm94eShlLmtleUhhbmRsZXIsZSksZS5pbnN0YW5jZVVpZD1iKyssZS5odG1sRXhwcj0vXig/OlxccyooPFtcXHdcXFddKz4pW14+XSopJC8sZS5yZWdpc3RlckJyZWFrcG9pbnRzKCksZS5pbml0KCEwKX12YXIgYj0wO3JldHVybiBjfSgpLGIucHJvdG90eXBlLmFjdGl2YXRlQURBPWZ1bmN0aW9uKCl7dmFyIGE9dGhpczthLiRzbGlkZVRyYWNrLmZpbmQoXCIuc2xpY2stYWN0aXZlXCIpLmF0dHIoe1wiYXJpYS1oaWRkZW5cIjpcImZhbHNlXCJ9KS5maW5kKFwiYSwgaW5wdXQsIGJ1dHRvbiwgc2VsZWN0XCIpLmF0dHIoe3RhYmluZGV4OlwiMFwifSl9LGIucHJvdG90eXBlLmFkZFNsaWRlPWIucHJvdG90eXBlLnNsaWNrQWRkPWZ1bmN0aW9uKGIsYyxkKXt2YXIgZT10aGlzO2lmKFwiYm9vbGVhblwiPT10eXBlb2YgYylkPWMsYz1udWxsO2Vsc2UgaWYoMD5jfHxjPj1lLnNsaWRlQ291bnQpcmV0dXJuITE7ZS51bmxvYWQoKSxcIm51bWJlclwiPT10eXBlb2YgYz8wPT09YyYmMD09PWUuJHNsaWRlcy5sZW5ndGg/YShiKS5hcHBlbmRUbyhlLiRzbGlkZVRyYWNrKTpkP2EoYikuaW5zZXJ0QmVmb3JlKGUuJHNsaWRlcy5lcShjKSk6YShiKS5pbnNlcnRBZnRlcihlLiRzbGlkZXMuZXEoYykpOmQ9PT0hMD9hKGIpLnByZXBlbmRUbyhlLiRzbGlkZVRyYWNrKTphKGIpLmFwcGVuZFRvKGUuJHNsaWRlVHJhY2spLGUuJHNsaWRlcz1lLiRzbGlkZVRyYWNrLmNoaWxkcmVuKHRoaXMub3B0aW9ucy5zbGlkZSksZS4kc2xpZGVUcmFjay5jaGlsZHJlbih0aGlzLm9wdGlvbnMuc2xpZGUpLmRldGFjaCgpLGUuJHNsaWRlVHJhY2suYXBwZW5kKGUuJHNsaWRlcyksZS4kc2xpZGVzLmVhY2goZnVuY3Rpb24oYixjKXthKGMpLmF0dHIoXCJkYXRhLXNsaWNrLWluZGV4XCIsYil9KSxlLiRzbGlkZXNDYWNoZT1lLiRzbGlkZXMsZS5yZWluaXQoKX0sYi5wcm90b3R5cGUuYW5pbWF0ZUhlaWdodD1mdW5jdGlvbigpe3ZhciBhPXRoaXM7aWYoMT09PWEub3B0aW9ucy5zbGlkZXNUb1Nob3cmJmEub3B0aW9ucy5hZGFwdGl2ZUhlaWdodD09PSEwJiZhLm9wdGlvbnMudmVydGljYWw9PT0hMSl7dmFyIGI9YS4kc2xpZGVzLmVxKGEuY3VycmVudFNsaWRlKS5vdXRlckhlaWdodCghMCk7YS4kbGlzdC5hbmltYXRlKHtoZWlnaHQ6Yn0sYS5vcHRpb25zLnNwZWVkKX19LGIucHJvdG90eXBlLmFuaW1hdGVTbGlkZT1mdW5jdGlvbihiLGMpe3ZhciBkPXt9LGU9dGhpcztlLmFuaW1hdGVIZWlnaHQoKSxlLm9wdGlvbnMucnRsPT09ITAmJmUub3B0aW9ucy52ZXJ0aWNhbD09PSExJiYoYj0tYiksZS50cmFuc2Zvcm1zRW5hYmxlZD09PSExP2Uub3B0aW9ucy52ZXJ0aWNhbD09PSExP2UuJHNsaWRlVHJhY2suYW5pbWF0ZSh7bGVmdDpifSxlLm9wdGlvbnMuc3BlZWQsZS5vcHRpb25zLmVhc2luZyxjKTplLiRzbGlkZVRyYWNrLmFuaW1hdGUoe3RvcDpifSxlLm9wdGlvbnMuc3BlZWQsZS5vcHRpb25zLmVhc2luZyxjKTplLmNzc1RyYW5zaXRpb25zPT09ITE/KGUub3B0aW9ucy5ydGw9PT0hMCYmKGUuY3VycmVudExlZnQ9LWUuY3VycmVudExlZnQpLGEoe2FuaW1TdGFydDplLmN1cnJlbnRMZWZ0fSkuYW5pbWF0ZSh7YW5pbVN0YXJ0OmJ9LHtkdXJhdGlvbjplLm9wdGlvbnMuc3BlZWQsZWFzaW5nOmUub3B0aW9ucy5lYXNpbmcsc3RlcDpmdW5jdGlvbihhKXthPU1hdGguY2VpbChhKSxlLm9wdGlvbnMudmVydGljYWw9PT0hMT8oZFtlLmFuaW1UeXBlXT1cInRyYW5zbGF0ZShcIithK1wicHgsIDBweClcIixlLiRzbGlkZVRyYWNrLmNzcyhkKSk6KGRbZS5hbmltVHlwZV09XCJ0cmFuc2xhdGUoMHB4LFwiK2ErXCJweClcIixlLiRzbGlkZVRyYWNrLmNzcyhkKSl9LGNvbXBsZXRlOmZ1bmN0aW9uKCl7YyYmYy5jYWxsKCl9fSkpOihlLmFwcGx5VHJhbnNpdGlvbigpLGI9TWF0aC5jZWlsKGIpLGUub3B0aW9ucy52ZXJ0aWNhbD09PSExP2RbZS5hbmltVHlwZV09XCJ0cmFuc2xhdGUzZChcIitiK1wicHgsIDBweCwgMHB4KVwiOmRbZS5hbmltVHlwZV09XCJ0cmFuc2xhdGUzZCgwcHgsXCIrYitcInB4LCAwcHgpXCIsZS4kc2xpZGVUcmFjay5jc3MoZCksYyYmc2V0VGltZW91dChmdW5jdGlvbigpe2UuZGlzYWJsZVRyYW5zaXRpb24oKSxjLmNhbGwoKX0sZS5vcHRpb25zLnNwZWVkKSl9LGIucHJvdG90eXBlLmdldE5hdlRhcmdldD1mdW5jdGlvbigpe3ZhciBiPXRoaXMsYz1iLm9wdGlvbnMuYXNOYXZGb3I7cmV0dXJuIGMmJm51bGwhPT1jJiYoYz1hKGMpLm5vdChiLiRzbGlkZXIpKSxjfSxiLnByb3RvdHlwZS5hc05hdkZvcj1mdW5jdGlvbihiKXt2YXIgYz10aGlzLGQ9Yy5nZXROYXZUYXJnZXQoKTtudWxsIT09ZCYmXCJvYmplY3RcIj09dHlwZW9mIGQmJmQuZWFjaChmdW5jdGlvbigpe3ZhciBjPWEodGhpcykuc2xpY2soXCJnZXRTbGlja1wiKTtjLnVuc2xpY2tlZHx8Yy5zbGlkZUhhbmRsZXIoYiwhMCl9KX0sYi5wcm90b3R5cGUuYXBwbHlUcmFuc2l0aW9uPWZ1bmN0aW9uKGEpe3ZhciBiPXRoaXMsYz17fTtiLm9wdGlvbnMuZmFkZT09PSExP2NbYi50cmFuc2l0aW9uVHlwZV09Yi50cmFuc2Zvcm1UeXBlK1wiIFwiK2Iub3B0aW9ucy5zcGVlZCtcIm1zIFwiK2Iub3B0aW9ucy5jc3NFYXNlOmNbYi50cmFuc2l0aW9uVHlwZV09XCJvcGFjaXR5IFwiK2Iub3B0aW9ucy5zcGVlZCtcIm1zIFwiK2Iub3B0aW9ucy5jc3NFYXNlLGIub3B0aW9ucy5mYWRlPT09ITE/Yi4kc2xpZGVUcmFjay5jc3MoYyk6Yi4kc2xpZGVzLmVxKGEpLmNzcyhjKX0sYi5wcm90b3R5cGUuYXV0b1BsYXk9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2EuYXV0b1BsYXlDbGVhcigpLGEuc2xpZGVDb3VudD5hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiYoYS5hdXRvUGxheVRpbWVyPXNldEludGVydmFsKGEuYXV0b1BsYXlJdGVyYXRvcixhLm9wdGlvbnMuYXV0b3BsYXlTcGVlZCkpfSxiLnByb3RvdHlwZS5hdXRvUGxheUNsZWFyPWZ1bmN0aW9uKCl7dmFyIGE9dGhpczthLmF1dG9QbGF5VGltZXImJmNsZWFySW50ZXJ2YWwoYS5hdXRvUGxheVRpbWVyKX0sYi5wcm90b3R5cGUuYXV0b1BsYXlJdGVyYXRvcj1mdW5jdGlvbigpe3ZhciBhPXRoaXMsYj1hLmN1cnJlbnRTbGlkZSthLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGw7YS5wYXVzZWR8fGEuaW50ZXJydXB0ZWR8fGEuZm9jdXNzZWR8fChhLm9wdGlvbnMuaW5maW5pdGU9PT0hMSYmKDE9PT1hLmRpcmVjdGlvbiYmYS5jdXJyZW50U2xpZGUrMT09PWEuc2xpZGVDb3VudC0xP2EuZGlyZWN0aW9uPTA6MD09PWEuZGlyZWN0aW9uJiYoYj1hLmN1cnJlbnRTbGlkZS1hLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGwsYS5jdXJyZW50U2xpZGUtMT09PTAmJihhLmRpcmVjdGlvbj0xKSkpLGEuc2xpZGVIYW5kbGVyKGIpKX0sYi5wcm90b3R5cGUuYnVpbGRBcnJvd3M9ZnVuY3Rpb24oKXt2YXIgYj10aGlzO2Iub3B0aW9ucy5hcnJvd3M9PT0hMCYmKGIuJHByZXZBcnJvdz1hKGIub3B0aW9ucy5wcmV2QXJyb3cpLmFkZENsYXNzKFwic2xpY2stYXJyb3dcIiksYi4kbmV4dEFycm93PWEoYi5vcHRpb25zLm5leHRBcnJvdykuYWRkQ2xhc3MoXCJzbGljay1hcnJvd1wiKSxiLnNsaWRlQ291bnQ+Yi5vcHRpb25zLnNsaWRlc1RvU2hvdz8oYi4kcHJldkFycm93LnJlbW92ZUNsYXNzKFwic2xpY2staGlkZGVuXCIpLnJlbW92ZUF0dHIoXCJhcmlhLWhpZGRlbiB0YWJpbmRleFwiKSxiLiRuZXh0QXJyb3cucmVtb3ZlQ2xhc3MoXCJzbGljay1oaWRkZW5cIikucmVtb3ZlQXR0cihcImFyaWEtaGlkZGVuIHRhYmluZGV4XCIpLGIuaHRtbEV4cHIudGVzdChiLm9wdGlvbnMucHJldkFycm93KSYmYi4kcHJldkFycm93LnByZXBlbmRUbyhiLm9wdGlvbnMuYXBwZW5kQXJyb3dzKSxiLmh0bWxFeHByLnRlc3QoYi5vcHRpb25zLm5leHRBcnJvdykmJmIuJG5leHRBcnJvdy5hcHBlbmRUbyhiLm9wdGlvbnMuYXBwZW5kQXJyb3dzKSxiLm9wdGlvbnMuaW5maW5pdGUhPT0hMCYmYi4kcHJldkFycm93LmFkZENsYXNzKFwic2xpY2stZGlzYWJsZWRcIikuYXR0cihcImFyaWEtZGlzYWJsZWRcIixcInRydWVcIikpOmIuJHByZXZBcnJvdy5hZGQoYi4kbmV4dEFycm93KS5hZGRDbGFzcyhcInNsaWNrLWhpZGRlblwiKS5hdHRyKHtcImFyaWEtZGlzYWJsZWRcIjpcInRydWVcIix0YWJpbmRleDpcIi0xXCJ9KSl9LGIucHJvdG90eXBlLmJ1aWxkRG90cz1mdW5jdGlvbigpe3ZhciBjLGQsYj10aGlzO2lmKGIub3B0aW9ucy5kb3RzPT09ITAmJmIuc2xpZGVDb3VudD5iLm9wdGlvbnMuc2xpZGVzVG9TaG93KXtmb3IoYi4kc2xpZGVyLmFkZENsYXNzKFwic2xpY2stZG90dGVkXCIpLGQ9YShcIjx1bCAvPlwiKS5hZGRDbGFzcyhiLm9wdGlvbnMuZG90c0NsYXNzKSxjPTA7Yzw9Yi5nZXREb3RDb3VudCgpO2MrPTEpZC5hcHBlbmQoYShcIjxsaSAvPlwiKS5hcHBlbmQoYi5vcHRpb25zLmN1c3RvbVBhZ2luZy5jYWxsKHRoaXMsYixjKSkpO2IuJGRvdHM9ZC5hcHBlbmRUbyhiLm9wdGlvbnMuYXBwZW5kRG90cyksYi4kZG90cy5maW5kKFwibGlcIikuZmlyc3QoKS5hZGRDbGFzcyhcInNsaWNrLWFjdGl2ZVwiKS5hdHRyKFwiYXJpYS1oaWRkZW5cIixcImZhbHNlXCIpfX0sYi5wcm90b3R5cGUuYnVpbGRPdXQ9ZnVuY3Rpb24oKXt2YXIgYj10aGlzO2IuJHNsaWRlcz1iLiRzbGlkZXIuY2hpbGRyZW4oYi5vcHRpb25zLnNsaWRlK1wiOm5vdCguc2xpY2stY2xvbmVkKVwiKS5hZGRDbGFzcyhcInNsaWNrLXNsaWRlXCIpLGIuc2xpZGVDb3VudD1iLiRzbGlkZXMubGVuZ3RoLGIuJHNsaWRlcy5lYWNoKGZ1bmN0aW9uKGIsYyl7YShjKS5hdHRyKFwiZGF0YS1zbGljay1pbmRleFwiLGIpLmRhdGEoXCJvcmlnaW5hbFN0eWxpbmdcIixhKGMpLmF0dHIoXCJzdHlsZVwiKXx8XCJcIil9KSxiLiRzbGlkZXIuYWRkQ2xhc3MoXCJzbGljay1zbGlkZXJcIiksYi4kc2xpZGVUcmFjaz0wPT09Yi5zbGlkZUNvdW50P2EoJzxkaXYgY2xhc3M9XCJzbGljay10cmFja1wiLz4nKS5hcHBlbmRUbyhiLiRzbGlkZXIpOmIuJHNsaWRlcy53cmFwQWxsKCc8ZGl2IGNsYXNzPVwic2xpY2stdHJhY2tcIi8+JykucGFyZW50KCksYi4kbGlzdD1iLiRzbGlkZVRyYWNrLndyYXAoJzxkaXYgYXJpYS1saXZlPVwicG9saXRlXCIgY2xhc3M9XCJzbGljay1saXN0XCIvPicpLnBhcmVudCgpLGIuJHNsaWRlVHJhY2suY3NzKFwib3BhY2l0eVwiLDApLChiLm9wdGlvbnMuY2VudGVyTW9kZT09PSEwfHxiLm9wdGlvbnMuc3dpcGVUb1NsaWRlPT09ITApJiYoYi5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsPTEpLGEoXCJpbWdbZGF0YS1sYXp5XVwiLGIuJHNsaWRlcikubm90KFwiW3NyY11cIikuYWRkQ2xhc3MoXCJzbGljay1sb2FkaW5nXCIpLGIuc2V0dXBJbmZpbml0ZSgpLGIuYnVpbGRBcnJvd3MoKSxiLmJ1aWxkRG90cygpLGIudXBkYXRlRG90cygpLGIuc2V0U2xpZGVDbGFzc2VzKFwibnVtYmVyXCI9PXR5cGVvZiBiLmN1cnJlbnRTbGlkZT9iLmN1cnJlbnRTbGlkZTowKSxiLm9wdGlvbnMuZHJhZ2dhYmxlPT09ITAmJmIuJGxpc3QuYWRkQ2xhc3MoXCJkcmFnZ2FibGVcIil9LGIucHJvdG90eXBlLmJ1aWxkUm93cz1mdW5jdGlvbigpe3ZhciBiLGMsZCxlLGYsZyxoLGE9dGhpcztpZihlPWRvY3VtZW50LmNyZWF0ZURvY3VtZW50RnJhZ21lbnQoKSxnPWEuJHNsaWRlci5jaGlsZHJlbigpLGEub3B0aW9ucy5yb3dzPjEpe2ZvcihoPWEub3B0aW9ucy5zbGlkZXNQZXJSb3cqYS5vcHRpb25zLnJvd3MsZj1NYXRoLmNlaWwoZy5sZW5ndGgvaCksYj0wO2Y+YjtiKyspe3ZhciBpPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7Zm9yKGM9MDtjPGEub3B0aW9ucy5yb3dzO2MrKyl7dmFyIGo9ZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtmb3IoZD0wO2Q8YS5vcHRpb25zLnNsaWRlc1BlclJvdztkKyspe3ZhciBrPWIqaCsoYyphLm9wdGlvbnMuc2xpZGVzUGVyUm93K2QpO2cuZ2V0KGspJiZqLmFwcGVuZENoaWxkKGcuZ2V0KGspKX1pLmFwcGVuZENoaWxkKGopfWUuYXBwZW5kQ2hpbGQoaSl9YS4kc2xpZGVyLmVtcHR5KCkuYXBwZW5kKGUpLGEuJHNsaWRlci5jaGlsZHJlbigpLmNoaWxkcmVuKCkuY2hpbGRyZW4oKS5jc3Moe3dpZHRoOjEwMC9hLm9wdGlvbnMuc2xpZGVzUGVyUm93K1wiJVwiLGRpc3BsYXk6XCJpbmxpbmUtYmxvY2tcIn0pfX0sYi5wcm90b3R5cGUuY2hlY2tSZXNwb25zaXZlPWZ1bmN0aW9uKGIsYyl7dmFyIGUsZixnLGQ9dGhpcyxoPSExLGk9ZC4kc2xpZGVyLndpZHRoKCksaj13aW5kb3cuaW5uZXJXaWR0aHx8YSh3aW5kb3cpLndpZHRoKCk7aWYoXCJ3aW5kb3dcIj09PWQucmVzcG9uZFRvP2c9ajpcInNsaWRlclwiPT09ZC5yZXNwb25kVG8/Zz1pOlwibWluXCI9PT1kLnJlc3BvbmRUbyYmKGc9TWF0aC5taW4oaixpKSksZC5vcHRpb25zLnJlc3BvbnNpdmUmJmQub3B0aW9ucy5yZXNwb25zaXZlLmxlbmd0aCYmbnVsbCE9PWQub3B0aW9ucy5yZXNwb25zaXZlKXtmPW51bGw7Zm9yKGUgaW4gZC5icmVha3BvaW50cylkLmJyZWFrcG9pbnRzLmhhc093blByb3BlcnR5KGUpJiYoZC5vcmlnaW5hbFNldHRpbmdzLm1vYmlsZUZpcnN0PT09ITE/ZzxkLmJyZWFrcG9pbnRzW2VdJiYoZj1kLmJyZWFrcG9pbnRzW2VdKTpnPmQuYnJlYWtwb2ludHNbZV0mJihmPWQuYnJlYWtwb2ludHNbZV0pKTtudWxsIT09Zj9udWxsIT09ZC5hY3RpdmVCcmVha3BvaW50PyhmIT09ZC5hY3RpdmVCcmVha3BvaW50fHxjKSYmKGQuYWN0aXZlQnJlYWtwb2ludD1mLFwidW5zbGlja1wiPT09ZC5icmVha3BvaW50U2V0dGluZ3NbZl0/ZC51bnNsaWNrKGYpOihkLm9wdGlvbnM9YS5leHRlbmQoe30sZC5vcmlnaW5hbFNldHRpbmdzLGQuYnJlYWtwb2ludFNldHRpbmdzW2ZdKSxiPT09ITAmJihkLmN1cnJlbnRTbGlkZT1kLm9wdGlvbnMuaW5pdGlhbFNsaWRlKSxkLnJlZnJlc2goYikpLGg9Zik6KGQuYWN0aXZlQnJlYWtwb2ludD1mLFwidW5zbGlja1wiPT09ZC5icmVha3BvaW50U2V0dGluZ3NbZl0/ZC51bnNsaWNrKGYpOihkLm9wdGlvbnM9YS5leHRlbmQoe30sZC5vcmlnaW5hbFNldHRpbmdzLGQuYnJlYWtwb2ludFNldHRpbmdzW2ZdKSxiPT09ITAmJihkLmN1cnJlbnRTbGlkZT1kLm9wdGlvbnMuaW5pdGlhbFNsaWRlKSxkLnJlZnJlc2goYikpLGg9Zik6bnVsbCE9PWQuYWN0aXZlQnJlYWtwb2ludCYmKGQuYWN0aXZlQnJlYWtwb2ludD1udWxsLGQub3B0aW9ucz1kLm9yaWdpbmFsU2V0dGluZ3MsYj09PSEwJiYoZC5jdXJyZW50U2xpZGU9ZC5vcHRpb25zLmluaXRpYWxTbGlkZSksZC5yZWZyZXNoKGIpLGg9ZiksYnx8aD09PSExfHxkLiRzbGlkZXIudHJpZ2dlcihcImJyZWFrcG9pbnRcIixbZCxoXSl9fSxiLnByb3RvdHlwZS5jaGFuZ2VTbGlkZT1mdW5jdGlvbihiLGMpe3ZhciBmLGcsaCxkPXRoaXMsZT1hKGIuY3VycmVudFRhcmdldCk7c3dpdGNoKGUuaXMoXCJhXCIpJiZiLnByZXZlbnREZWZhdWx0KCksZS5pcyhcImxpXCIpfHwoZT1lLmNsb3Nlc3QoXCJsaVwiKSksaD1kLnNsaWRlQ291bnQlZC5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsIT09MCxmPWg/MDooZC5zbGlkZUNvdW50LWQuY3VycmVudFNsaWRlKSVkLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGwsYi5kYXRhLm1lc3NhZ2Upe2Nhc2VcInByZXZpb3VzXCI6Zz0wPT09Zj9kLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGw6ZC5vcHRpb25zLnNsaWRlc1RvU2hvdy1mLGQuc2xpZGVDb3VudD5kLm9wdGlvbnMuc2xpZGVzVG9TaG93JiZkLnNsaWRlSGFuZGxlcihkLmN1cnJlbnRTbGlkZS1nLCExLGMpO2JyZWFrO2Nhc2VcIm5leHRcIjpnPTA9PT1mP2Qub3B0aW9ucy5zbGlkZXNUb1Njcm9sbDpmLGQuc2xpZGVDb3VudD5kLm9wdGlvbnMuc2xpZGVzVG9TaG93JiZkLnNsaWRlSGFuZGxlcihkLmN1cnJlbnRTbGlkZStnLCExLGMpO2JyZWFrO2Nhc2VcImluZGV4XCI6dmFyIGk9MD09PWIuZGF0YS5pbmRleD8wOmIuZGF0YS5pbmRleHx8ZS5pbmRleCgpKmQub3B0aW9ucy5zbGlkZXNUb1Njcm9sbDtkLnNsaWRlSGFuZGxlcihkLmNoZWNrTmF2aWdhYmxlKGkpLCExLGMpLGUuY2hpbGRyZW4oKS50cmlnZ2VyKFwiZm9jdXNcIik7YnJlYWs7ZGVmYXVsdDpyZXR1cm59fSxiLnByb3RvdHlwZS5jaGVja05hdmlnYWJsZT1mdW5jdGlvbihhKXt2YXIgYyxkLGI9dGhpcztpZihjPWIuZ2V0TmF2aWdhYmxlSW5kZXhlcygpLGQ9MCxhPmNbYy5sZW5ndGgtMV0pYT1jW2MubGVuZ3RoLTFdO2Vsc2UgZm9yKHZhciBlIGluIGMpe2lmKGE8Y1tlXSl7YT1kO2JyZWFrfWQ9Y1tlXX1yZXR1cm4gYX0sYi5wcm90b3R5cGUuY2xlYW5VcEV2ZW50cz1mdW5jdGlvbigpe3ZhciBiPXRoaXM7Yi5vcHRpb25zLmRvdHMmJm51bGwhPT1iLiRkb3RzJiZhKFwibGlcIixiLiRkb3RzKS5vZmYoXCJjbGljay5zbGlja1wiLGIuY2hhbmdlU2xpZGUpLm9mZihcIm1vdXNlZW50ZXIuc2xpY2tcIixhLnByb3h5KGIuaW50ZXJydXB0LGIsITApKS5vZmYoXCJtb3VzZWxlYXZlLnNsaWNrXCIsYS5wcm94eShiLmludGVycnVwdCxiLCExKSksYi4kc2xpZGVyLm9mZihcImZvY3VzLnNsaWNrIGJsdXIuc2xpY2tcIiksYi5vcHRpb25zLmFycm93cz09PSEwJiZiLnNsaWRlQ291bnQ+Yi5vcHRpb25zLnNsaWRlc1RvU2hvdyYmKGIuJHByZXZBcnJvdyYmYi4kcHJldkFycm93Lm9mZihcImNsaWNrLnNsaWNrXCIsYi5jaGFuZ2VTbGlkZSksYi4kbmV4dEFycm93JiZiLiRuZXh0QXJyb3cub2ZmKFwiY2xpY2suc2xpY2tcIixiLmNoYW5nZVNsaWRlKSksYi4kbGlzdC5vZmYoXCJ0b3VjaHN0YXJ0LnNsaWNrIG1vdXNlZG93bi5zbGlja1wiLGIuc3dpcGVIYW5kbGVyKSxiLiRsaXN0Lm9mZihcInRvdWNobW92ZS5zbGljayBtb3VzZW1vdmUuc2xpY2tcIixiLnN3aXBlSGFuZGxlciksYi4kbGlzdC5vZmYoXCJ0b3VjaGVuZC5zbGljayBtb3VzZXVwLnNsaWNrXCIsYi5zd2lwZUhhbmRsZXIpLGIuJGxpc3Qub2ZmKFwidG91Y2hjYW5jZWwuc2xpY2sgbW91c2VsZWF2ZS5zbGlja1wiLGIuc3dpcGVIYW5kbGVyKSxiLiRsaXN0Lm9mZihcImNsaWNrLnNsaWNrXCIsYi5jbGlja0hhbmRsZXIpLGEoZG9jdW1lbnQpLm9mZihiLnZpc2liaWxpdHlDaGFuZ2UsYi52aXNpYmlsaXR5KSxiLmNsZWFuVXBTbGlkZUV2ZW50cygpLGIub3B0aW9ucy5hY2Nlc3NpYmlsaXR5PT09ITAmJmIuJGxpc3Qub2ZmKFwia2V5ZG93bi5zbGlja1wiLGIua2V5SGFuZGxlciksYi5vcHRpb25zLmZvY3VzT25TZWxlY3Q9PT0hMCYmYShiLiRzbGlkZVRyYWNrKS5jaGlsZHJlbigpLm9mZihcImNsaWNrLnNsaWNrXCIsYi5zZWxlY3RIYW5kbGVyKSxhKHdpbmRvdykub2ZmKFwib3JpZW50YXRpb25jaGFuZ2Uuc2xpY2suc2xpY2stXCIrYi5pbnN0YW5jZVVpZCxiLm9yaWVudGF0aW9uQ2hhbmdlKSxhKHdpbmRvdykub2ZmKFwicmVzaXplLnNsaWNrLnNsaWNrLVwiK2IuaW5zdGFuY2VVaWQsYi5yZXNpemUpLGEoXCJbZHJhZ2dhYmxlIT10cnVlXVwiLGIuJHNsaWRlVHJhY2spLm9mZihcImRyYWdzdGFydFwiLGIucHJldmVudERlZmF1bHQpLGEod2luZG93KS5vZmYoXCJsb2FkLnNsaWNrLnNsaWNrLVwiK2IuaW5zdGFuY2VVaWQsYi5zZXRQb3NpdGlvbiksYShkb2N1bWVudCkub2ZmKFwicmVhZHkuc2xpY2suc2xpY2stXCIrYi5pbnN0YW5jZVVpZCxiLnNldFBvc2l0aW9uKX0sYi5wcm90b3R5cGUuY2xlYW5VcFNsaWRlRXZlbnRzPWZ1bmN0aW9uKCl7dmFyIGI9dGhpcztiLiRsaXN0Lm9mZihcIm1vdXNlZW50ZXIuc2xpY2tcIixhLnByb3h5KGIuaW50ZXJydXB0LGIsITApKSxiLiRsaXN0Lm9mZihcIm1vdXNlbGVhdmUuc2xpY2tcIixhLnByb3h5KGIuaW50ZXJydXB0LGIsITEpKX0sYi5wcm90b3R5cGUuY2xlYW5VcFJvd3M9ZnVuY3Rpb24oKXt2YXIgYixhPXRoaXM7YS5vcHRpb25zLnJvd3M+MSYmKGI9YS4kc2xpZGVzLmNoaWxkcmVuKCkuY2hpbGRyZW4oKSxiLnJlbW92ZUF0dHIoXCJzdHlsZVwiKSxhLiRzbGlkZXIuZW1wdHkoKS5hcHBlbmQoYikpfSxiLnByb3RvdHlwZS5jbGlja0hhbmRsZXI9ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcztiLnNob3VsZENsaWNrPT09ITEmJihhLnN0b3BJbW1lZGlhdGVQcm9wYWdhdGlvbigpLGEuc3RvcFByb3BhZ2F0aW9uKCksYS5wcmV2ZW50RGVmYXVsdCgpKX0sYi5wcm90b3R5cGUuZGVzdHJveT1mdW5jdGlvbihiKXt2YXIgYz10aGlzO2MuYXV0b1BsYXlDbGVhcigpLGMudG91Y2hPYmplY3Q9e30sYy5jbGVhblVwRXZlbnRzKCksYShcIi5zbGljay1jbG9uZWRcIixjLiRzbGlkZXIpLmRldGFjaCgpLGMuJGRvdHMmJmMuJGRvdHMucmVtb3ZlKCksYy4kcHJldkFycm93JiZjLiRwcmV2QXJyb3cubGVuZ3RoJiYoYy4kcHJldkFycm93LnJlbW92ZUNsYXNzKFwic2xpY2stZGlzYWJsZWQgc2xpY2stYXJyb3cgc2xpY2staGlkZGVuXCIpLnJlbW92ZUF0dHIoXCJhcmlhLWhpZGRlbiBhcmlhLWRpc2FibGVkIHRhYmluZGV4XCIpLmNzcyhcImRpc3BsYXlcIixcIlwiKSxjLmh0bWxFeHByLnRlc3QoYy5vcHRpb25zLnByZXZBcnJvdykmJmMuJHByZXZBcnJvdy5yZW1vdmUoKSksYy4kbmV4dEFycm93JiZjLiRuZXh0QXJyb3cubGVuZ3RoJiYoYy4kbmV4dEFycm93LnJlbW92ZUNsYXNzKFwic2xpY2stZGlzYWJsZWQgc2xpY2stYXJyb3cgc2xpY2staGlkZGVuXCIpLnJlbW92ZUF0dHIoXCJhcmlhLWhpZGRlbiBhcmlhLWRpc2FibGVkIHRhYmluZGV4XCIpLmNzcyhcImRpc3BsYXlcIixcIlwiKSxjLmh0bWxFeHByLnRlc3QoYy5vcHRpb25zLm5leHRBcnJvdykmJmMuJG5leHRBcnJvdy5yZW1vdmUoKSksYy4kc2xpZGVzJiYoYy4kc2xpZGVzLnJlbW92ZUNsYXNzKFwic2xpY2stc2xpZGUgc2xpY2stYWN0aXZlIHNsaWNrLWNlbnRlciBzbGljay12aXNpYmxlIHNsaWNrLWN1cnJlbnRcIikucmVtb3ZlQXR0cihcImFyaWEtaGlkZGVuXCIpLnJlbW92ZUF0dHIoXCJkYXRhLXNsaWNrLWluZGV4XCIpLmVhY2goZnVuY3Rpb24oKXthKHRoaXMpLmF0dHIoXCJzdHlsZVwiLGEodGhpcykuZGF0YShcIm9yaWdpbmFsU3R5bGluZ1wiKSl9KSxjLiRzbGlkZVRyYWNrLmNoaWxkcmVuKHRoaXMub3B0aW9ucy5zbGlkZSkuZGV0YWNoKCksYy4kc2xpZGVUcmFjay5kZXRhY2goKSxjLiRsaXN0LmRldGFjaCgpLGMuJHNsaWRlci5hcHBlbmQoYy4kc2xpZGVzKSksYy5jbGVhblVwUm93cygpLGMuJHNsaWRlci5yZW1vdmVDbGFzcyhcInNsaWNrLXNsaWRlclwiKSxjLiRzbGlkZXIucmVtb3ZlQ2xhc3MoXCJzbGljay1pbml0aWFsaXplZFwiKSxjLiRzbGlkZXIucmVtb3ZlQ2xhc3MoXCJzbGljay1kb3R0ZWRcIiksYy51bnNsaWNrZWQ9ITAsYnx8Yy4kc2xpZGVyLnRyaWdnZXIoXCJkZXN0cm95XCIsW2NdKX0sYi5wcm90b3R5cGUuZGlzYWJsZVRyYW5zaXRpb249ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcyxjPXt9O2NbYi50cmFuc2l0aW9uVHlwZV09XCJcIixiLm9wdGlvbnMuZmFkZT09PSExP2IuJHNsaWRlVHJhY2suY3NzKGMpOmIuJHNsaWRlcy5lcShhKS5jc3MoYyl9LGIucHJvdG90eXBlLmZhZGVTbGlkZT1mdW5jdGlvbihhLGIpe3ZhciBjPXRoaXM7Yy5jc3NUcmFuc2l0aW9ucz09PSExPyhjLiRzbGlkZXMuZXEoYSkuY3NzKHt6SW5kZXg6Yy5vcHRpb25zLnpJbmRleH0pLGMuJHNsaWRlcy5lcShhKS5hbmltYXRlKHtvcGFjaXR5OjF9LGMub3B0aW9ucy5zcGVlZCxjLm9wdGlvbnMuZWFzaW5nLGIpKTooYy5hcHBseVRyYW5zaXRpb24oYSksYy4kc2xpZGVzLmVxKGEpLmNzcyh7b3BhY2l0eToxLHpJbmRleDpjLm9wdGlvbnMuekluZGV4fSksYiYmc2V0VGltZW91dChmdW5jdGlvbigpe2MuZGlzYWJsZVRyYW5zaXRpb24oYSksYi5jYWxsKCl9LGMub3B0aW9ucy5zcGVlZCkpfSxiLnByb3RvdHlwZS5mYWRlU2xpZGVPdXQ9ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcztiLmNzc1RyYW5zaXRpb25zPT09ITE/Yi4kc2xpZGVzLmVxKGEpLmFuaW1hdGUoe29wYWNpdHk6MCx6SW5kZXg6Yi5vcHRpb25zLnpJbmRleC0yfSxiLm9wdGlvbnMuc3BlZWQsYi5vcHRpb25zLmVhc2luZyk6KGIuYXBwbHlUcmFuc2l0aW9uKGEpLGIuJHNsaWRlcy5lcShhKS5jc3Moe29wYWNpdHk6MCx6SW5kZXg6Yi5vcHRpb25zLnpJbmRleC0yfSkpfSxiLnByb3RvdHlwZS5maWx0ZXJTbGlkZXM9Yi5wcm90b3R5cGUuc2xpY2tGaWx0ZXI9ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcztudWxsIT09YSYmKGIuJHNsaWRlc0NhY2hlPWIuJHNsaWRlcyxiLnVubG9hZCgpLGIuJHNsaWRlVHJhY2suY2hpbGRyZW4odGhpcy5vcHRpb25zLnNsaWRlKS5kZXRhY2goKSxiLiRzbGlkZXNDYWNoZS5maWx0ZXIoYSkuYXBwZW5kVG8oYi4kc2xpZGVUcmFjayksYi5yZWluaXQoKSl9LGIucHJvdG90eXBlLmZvY3VzSGFuZGxlcj1mdW5jdGlvbigpe3ZhciBiPXRoaXM7Yi4kc2xpZGVyLm9mZihcImZvY3VzLnNsaWNrIGJsdXIuc2xpY2tcIikub24oXCJmb2N1cy5zbGljayBibHVyLnNsaWNrXCIsXCIqOm5vdCguc2xpY2stYXJyb3cpXCIsZnVuY3Rpb24oYyl7Yy5zdG9wSW1tZWRpYXRlUHJvcGFnYXRpb24oKTt2YXIgZD1hKHRoaXMpO3NldFRpbWVvdXQoZnVuY3Rpb24oKXtiLm9wdGlvbnMucGF1c2VPbkZvY3VzJiYoYi5mb2N1c3NlZD1kLmlzKFwiOmZvY3VzXCIpLGIuYXV0b1BsYXkoKSl9LDApfSl9LGIucHJvdG90eXBlLmdldEN1cnJlbnQ9Yi5wcm90b3R5cGUuc2xpY2tDdXJyZW50U2xpZGU9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO3JldHVybiBhLmN1cnJlbnRTbGlkZX0sYi5wcm90b3R5cGUuZ2V0RG90Q291bnQ9ZnVuY3Rpb24oKXt2YXIgYT10aGlzLGI9MCxjPTAsZD0wO2lmKGEub3B0aW9ucy5pbmZpbml0ZT09PSEwKWZvcig7YjxhLnNsaWRlQ291bnQ7KSsrZCxiPWMrYS5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsLGMrPWEub3B0aW9ucy5zbGlkZXNUb1Njcm9sbDw9YS5vcHRpb25zLnNsaWRlc1RvU2hvdz9hLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGw6YS5vcHRpb25zLnNsaWRlc1RvU2hvdztlbHNlIGlmKGEub3B0aW9ucy5jZW50ZXJNb2RlPT09ITApZD1hLnNsaWRlQ291bnQ7ZWxzZSBpZihhLm9wdGlvbnMuYXNOYXZGb3IpZm9yKDtiPGEuc2xpZGVDb3VudDspKytkLGI9YythLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGwsYys9YS5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsPD1hLm9wdGlvbnMuc2xpZGVzVG9TaG93P2Eub3B0aW9ucy5zbGlkZXNUb1Njcm9sbDphLm9wdGlvbnMuc2xpZGVzVG9TaG93O2Vsc2UgZD0xK01hdGguY2VpbCgoYS5zbGlkZUNvdW50LWEub3B0aW9ucy5zbGlkZXNUb1Nob3cpL2Eub3B0aW9ucy5zbGlkZXNUb1Njcm9sbCk7cmV0dXJuIGQtMX0sYi5wcm90b3R5cGUuZ2V0TGVmdD1mdW5jdGlvbihhKXt2YXIgYyxkLGYsYj10aGlzLGU9MDtyZXR1cm4gYi5zbGlkZU9mZnNldD0wLGQ9Yi4kc2xpZGVzLmZpcnN0KCkub3V0ZXJIZWlnaHQoITApLGIub3B0aW9ucy5pbmZpbml0ZT09PSEwPyhiLnNsaWRlQ291bnQ+Yi5vcHRpb25zLnNsaWRlc1RvU2hvdyYmKGIuc2xpZGVPZmZzZXQ9Yi5zbGlkZVdpZHRoKmIub3B0aW9ucy5zbGlkZXNUb1Nob3cqLTEsZT1kKmIub3B0aW9ucy5zbGlkZXNUb1Nob3cqLTEpLGIuc2xpZGVDb3VudCViLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGwhPT0wJiZhK2Iub3B0aW9ucy5zbGlkZXNUb1Njcm9sbD5iLnNsaWRlQ291bnQmJmIuc2xpZGVDb3VudD5iLm9wdGlvbnMuc2xpZGVzVG9TaG93JiYoYT5iLnNsaWRlQ291bnQ/KGIuc2xpZGVPZmZzZXQ9KGIub3B0aW9ucy5zbGlkZXNUb1Nob3ctKGEtYi5zbGlkZUNvdW50KSkqYi5zbGlkZVdpZHRoKi0xLGU9KGIub3B0aW9ucy5zbGlkZXNUb1Nob3ctKGEtYi5zbGlkZUNvdW50KSkqZCotMSk6KGIuc2xpZGVPZmZzZXQ9Yi5zbGlkZUNvdW50JWIub3B0aW9ucy5zbGlkZXNUb1Njcm9sbCpiLnNsaWRlV2lkdGgqLTEsZT1iLnNsaWRlQ291bnQlYi5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsKmQqLTEpKSk6YStiLm9wdGlvbnMuc2xpZGVzVG9TaG93PmIuc2xpZGVDb3VudCYmKGIuc2xpZGVPZmZzZXQ9KGErYi5vcHRpb25zLnNsaWRlc1RvU2hvdy1iLnNsaWRlQ291bnQpKmIuc2xpZGVXaWR0aCxlPShhK2Iub3B0aW9ucy5zbGlkZXNUb1Nob3ctYi5zbGlkZUNvdW50KSpkKSxiLnNsaWRlQ291bnQ8PWIub3B0aW9ucy5zbGlkZXNUb1Nob3cmJihiLnNsaWRlT2Zmc2V0PTAsZT0wKSxiLm9wdGlvbnMuY2VudGVyTW9kZT09PSEwJiZiLm9wdGlvbnMuaW5maW5pdGU9PT0hMD9iLnNsaWRlT2Zmc2V0Kz1iLnNsaWRlV2lkdGgqTWF0aC5mbG9vcihiLm9wdGlvbnMuc2xpZGVzVG9TaG93LzIpLWIuc2xpZGVXaWR0aDpiLm9wdGlvbnMuY2VudGVyTW9kZT09PSEwJiYoYi5zbGlkZU9mZnNldD0wLGIuc2xpZGVPZmZzZXQrPWIuc2xpZGVXaWR0aCpNYXRoLmZsb29yKGIub3B0aW9ucy5zbGlkZXNUb1Nob3cvMikpLGM9Yi5vcHRpb25zLnZlcnRpY2FsPT09ITE/YSpiLnNsaWRlV2lkdGgqLTErYi5zbGlkZU9mZnNldDphKmQqLTErZSxiLm9wdGlvbnMudmFyaWFibGVXaWR0aD09PSEwJiYoZj1iLnNsaWRlQ291bnQ8PWIub3B0aW9ucy5zbGlkZXNUb1Nob3d8fGIub3B0aW9ucy5pbmZpbml0ZT09PSExP2IuJHNsaWRlVHJhY2suY2hpbGRyZW4oXCIuc2xpY2stc2xpZGVcIikuZXEoYSk6Yi4kc2xpZGVUcmFjay5jaGlsZHJlbihcIi5zbGljay1zbGlkZVwiKS5lcShhK2Iub3B0aW9ucy5zbGlkZXNUb1Nob3cpLGM9Yi5vcHRpb25zLnJ0bD09PSEwP2ZbMF0/LTEqKGIuJHNsaWRlVHJhY2sud2lkdGgoKS1mWzBdLm9mZnNldExlZnQtZi53aWR0aCgpKTowOmZbMF0/LTEqZlswXS5vZmZzZXRMZWZ0OjAsYi5vcHRpb25zLmNlbnRlck1vZGU9PT0hMCYmKGY9Yi5zbGlkZUNvdW50PD1iLm9wdGlvbnMuc2xpZGVzVG9TaG93fHxiLm9wdGlvbnMuaW5maW5pdGU9PT0hMT9iLiRzbGlkZVRyYWNrLmNoaWxkcmVuKFwiLnNsaWNrLXNsaWRlXCIpLmVxKGEpOmIuJHNsaWRlVHJhY2suY2hpbGRyZW4oXCIuc2xpY2stc2xpZGVcIikuZXEoYStiLm9wdGlvbnMuc2xpZGVzVG9TaG93KzEpLGM9Yi5vcHRpb25zLnJ0bD09PSEwP2ZbMF0/LTEqKGIuJHNsaWRlVHJhY2sud2lkdGgoKS1mWzBdLm9mZnNldExlZnQtZi53aWR0aCgpKTowOmZbMF0/LTEqZlswXS5vZmZzZXRMZWZ0OjAsYys9KGIuJGxpc3Qud2lkdGgoKS1mLm91dGVyV2lkdGgoKSkvMikpLGN9LGIucHJvdG90eXBlLmdldE9wdGlvbj1iLnByb3RvdHlwZS5zbGlja0dldE9wdGlvbj1mdW5jdGlvbihhKXt2YXIgYj10aGlzO3JldHVybiBiLm9wdGlvbnNbYV19LGIucHJvdG90eXBlLmdldE5hdmlnYWJsZUluZGV4ZXM9ZnVuY3Rpb24oKXt2YXIgZSxhPXRoaXMsYj0wLGM9MCxkPVtdO2ZvcihhLm9wdGlvbnMuaW5maW5pdGU9PT0hMT9lPWEuc2xpZGVDb3VudDooYj0tMSphLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGwsYz0tMSphLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGwsZT0yKmEuc2xpZGVDb3VudCk7ZT5iOylkLnB1c2goYiksYj1jK2Eub3B0aW9ucy5zbGlkZXNUb1Njcm9sbCxjKz1hLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGw8PWEub3B0aW9ucy5zbGlkZXNUb1Nob3c/YS5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsOmEub3B0aW9ucy5zbGlkZXNUb1Nob3c7cmV0dXJuIGR9LGIucHJvdG90eXBlLmdldFNsaWNrPWZ1bmN0aW9uKCl7cmV0dXJuIHRoaXN9LGIucHJvdG90eXBlLmdldFNsaWRlQ291bnQ9ZnVuY3Rpb24oKXt2YXIgYyxkLGUsYj10aGlzO3JldHVybiBlPWIub3B0aW9ucy5jZW50ZXJNb2RlPT09ITA/Yi5zbGlkZVdpZHRoKk1hdGguZmxvb3IoYi5vcHRpb25zLnNsaWRlc1RvU2hvdy8yKTowLGIub3B0aW9ucy5zd2lwZVRvU2xpZGU9PT0hMD8oYi4kc2xpZGVUcmFjay5maW5kKFwiLnNsaWNrLXNsaWRlXCIpLmVhY2goZnVuY3Rpb24oYyxmKXtyZXR1cm4gZi5vZmZzZXRMZWZ0LWUrYShmKS5vdXRlcldpZHRoKCkvMj4tMSpiLnN3aXBlTGVmdD8oZD1mLCExKTp2b2lkIDB9KSxjPU1hdGguYWJzKGEoZCkuYXR0cihcImRhdGEtc2xpY2staW5kZXhcIiktYi5jdXJyZW50U2xpZGUpfHwxKTpiLm9wdGlvbnMuc2xpZGVzVG9TY3JvbGx9LGIucHJvdG90eXBlLmdvVG89Yi5wcm90b3R5cGUuc2xpY2tHb1RvPWZ1bmN0aW9uKGEsYil7dmFyIGM9dGhpcztjLmNoYW5nZVNsaWRlKHtkYXRhOnttZXNzYWdlOlwiaW5kZXhcIixpbmRleDpwYXJzZUludChhKX19LGIpfSxiLnByb3RvdHlwZS5pbml0PWZ1bmN0aW9uKGIpe3ZhciBjPXRoaXM7YShjLiRzbGlkZXIpLmhhc0NsYXNzKFwic2xpY2staW5pdGlhbGl6ZWRcIil8fChhKGMuJHNsaWRlcikuYWRkQ2xhc3MoXCJzbGljay1pbml0aWFsaXplZFwiKSxjLmJ1aWxkUm93cygpLGMuYnVpbGRPdXQoKSxjLnNldFByb3BzKCksYy5zdGFydExvYWQoKSxjLmxvYWRTbGlkZXIoKSxjLmluaXRpYWxpemVFdmVudHMoKSxjLnVwZGF0ZUFycm93cygpLGMudXBkYXRlRG90cygpLGMuY2hlY2tSZXNwb25zaXZlKCEwKSxjLmZvY3VzSGFuZGxlcigpKSxiJiZjLiRzbGlkZXIudHJpZ2dlcihcImluaXRcIixbY10pLGMub3B0aW9ucy5hY2Nlc3NpYmlsaXR5PT09ITAmJmMuaW5pdEFEQSgpLGMub3B0aW9ucy5hdXRvcGxheSYmKGMucGF1c2VkPSExLGMuYXV0b1BsYXkoKSl9LGIucHJvdG90eXBlLmluaXRBREE9ZnVuY3Rpb24oKXt2YXIgYj10aGlzO2IuJHNsaWRlcy5hZGQoYi4kc2xpZGVUcmFjay5maW5kKFwiLnNsaWNrLWNsb25lZFwiKSkuYXR0cih7XCJhcmlhLWhpZGRlblwiOlwidHJ1ZVwiLHRhYmluZGV4OlwiLTFcIn0pLmZpbmQoXCJhLCBpbnB1dCwgYnV0dG9uLCBzZWxlY3RcIikuYXR0cih7dGFiaW5kZXg6XCItMVwifSksYi4kc2xpZGVUcmFjay5hdHRyKFwicm9sZVwiLFwibGlzdGJveFwiKSxiLiRzbGlkZXMubm90KGIuJHNsaWRlVHJhY2suZmluZChcIi5zbGljay1jbG9uZWRcIikpLmVhY2goZnVuY3Rpb24oYyl7YSh0aGlzKS5hdHRyKHtyb2xlOlwib3B0aW9uXCIsXCJhcmlhLWRlc2NyaWJlZGJ5XCI6XCJzbGljay1zbGlkZVwiK2IuaW5zdGFuY2VVaWQrY30pfSksbnVsbCE9PWIuJGRvdHMmJmIuJGRvdHMuYXR0cihcInJvbGVcIixcInRhYmxpc3RcIikuZmluZChcImxpXCIpLmVhY2goZnVuY3Rpb24oYyl7YSh0aGlzKS5hdHRyKHtyb2xlOlwicHJlc2VudGF0aW9uXCIsXCJhcmlhLXNlbGVjdGVkXCI6XCJmYWxzZVwiLFwiYXJpYS1jb250cm9sc1wiOlwibmF2aWdhdGlvblwiK2IuaW5zdGFuY2VVaWQrYyxpZDpcInNsaWNrLXNsaWRlXCIrYi5pbnN0YW5jZVVpZCtjfSl9KS5maXJzdCgpLmF0dHIoXCJhcmlhLXNlbGVjdGVkXCIsXCJ0cnVlXCIpLmVuZCgpLmZpbmQoXCJidXR0b25cIikuYXR0cihcInJvbGVcIixcImJ1dHRvblwiKS5lbmQoKS5jbG9zZXN0KFwiZGl2XCIpLmF0dHIoXCJyb2xlXCIsXCJ0b29sYmFyXCIpLGIuYWN0aXZhdGVBREEoKX0sYi5wcm90b3R5cGUuaW5pdEFycm93RXZlbnRzPWZ1bmN0aW9uKCl7dmFyIGE9dGhpczthLm9wdGlvbnMuYXJyb3dzPT09ITAmJmEuc2xpZGVDb3VudD5hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiYoYS4kcHJldkFycm93Lm9mZihcImNsaWNrLnNsaWNrXCIpLm9uKFwiY2xpY2suc2xpY2tcIix7bWVzc2FnZTpcInByZXZpb3VzXCJ9LGEuY2hhbmdlU2xpZGUpLGEuJG5leHRBcnJvdy5vZmYoXCJjbGljay5zbGlja1wiKS5vbihcImNsaWNrLnNsaWNrXCIse21lc3NhZ2U6XCJuZXh0XCJ9LGEuY2hhbmdlU2xpZGUpKX0sYi5wcm90b3R5cGUuaW5pdERvdEV2ZW50cz1mdW5jdGlvbigpe3ZhciBiPXRoaXM7Yi5vcHRpb25zLmRvdHM9PT0hMCYmYi5zbGlkZUNvdW50PmIub3B0aW9ucy5zbGlkZXNUb1Nob3cmJmEoXCJsaVwiLGIuJGRvdHMpLm9uKFwiY2xpY2suc2xpY2tcIix7bWVzc2FnZTpcImluZGV4XCJ9LGIuY2hhbmdlU2xpZGUpLGIub3B0aW9ucy5kb3RzPT09ITAmJmIub3B0aW9ucy5wYXVzZU9uRG90c0hvdmVyPT09ITAmJmEoXCJsaVwiLGIuJGRvdHMpLm9uKFwibW91c2VlbnRlci5zbGlja1wiLGEucHJveHkoYi5pbnRlcnJ1cHQsYiwhMCkpLm9uKFwibW91c2VsZWF2ZS5zbGlja1wiLGEucHJveHkoYi5pbnRlcnJ1cHQsYiwhMSkpfSxiLnByb3RvdHlwZS5pbml0U2xpZGVFdmVudHM9ZnVuY3Rpb24oKXt2YXIgYj10aGlzO2Iub3B0aW9ucy5wYXVzZU9uSG92ZXImJihiLiRsaXN0Lm9uKFwibW91c2VlbnRlci5zbGlja1wiLGEucHJveHkoYi5pbnRlcnJ1cHQsYiwhMCkpLGIuJGxpc3Qub24oXCJtb3VzZWxlYXZlLnNsaWNrXCIsYS5wcm94eShiLmludGVycnVwdCxiLCExKSkpfSxiLnByb3RvdHlwZS5pbml0aWFsaXplRXZlbnRzPWZ1bmN0aW9uKCl7dmFyIGI9dGhpcztiLmluaXRBcnJvd0V2ZW50cygpLGIuaW5pdERvdEV2ZW50cygpLGIuaW5pdFNsaWRlRXZlbnRzKCksYi4kbGlzdC5vbihcInRvdWNoc3RhcnQuc2xpY2sgbW91c2Vkb3duLnNsaWNrXCIse2FjdGlvbjpcInN0YXJ0XCJ9LGIuc3dpcGVIYW5kbGVyKSxiLiRsaXN0Lm9uKFwidG91Y2htb3ZlLnNsaWNrIG1vdXNlbW92ZS5zbGlja1wiLHthY3Rpb246XCJtb3ZlXCJ9LGIuc3dpcGVIYW5kbGVyKSxiLiRsaXN0Lm9uKFwidG91Y2hlbmQuc2xpY2sgbW91c2V1cC5zbGlja1wiLHthY3Rpb246XCJlbmRcIn0sYi5zd2lwZUhhbmRsZXIpLGIuJGxpc3Qub24oXCJ0b3VjaGNhbmNlbC5zbGljayBtb3VzZWxlYXZlLnNsaWNrXCIse2FjdGlvbjpcImVuZFwifSxiLnN3aXBlSGFuZGxlciksYi4kbGlzdC5vbihcImNsaWNrLnNsaWNrXCIsYi5jbGlja0hhbmRsZXIpLGEoZG9jdW1lbnQpLm9uKGIudmlzaWJpbGl0eUNoYW5nZSxhLnByb3h5KGIudmlzaWJpbGl0eSxiKSksYi5vcHRpb25zLmFjY2Vzc2liaWxpdHk9PT0hMCYmYi4kbGlzdC5vbihcImtleWRvd24uc2xpY2tcIixiLmtleUhhbmRsZXIpLGIub3B0aW9ucy5mb2N1c09uU2VsZWN0PT09ITAmJmEoYi4kc2xpZGVUcmFjaykuY2hpbGRyZW4oKS5vbihcImNsaWNrLnNsaWNrXCIsYi5zZWxlY3RIYW5kbGVyKSxhKHdpbmRvdykub24oXCJvcmllbnRhdGlvbmNoYW5nZS5zbGljay5zbGljay1cIitiLmluc3RhbmNlVWlkLGEucHJveHkoYi5vcmllbnRhdGlvbkNoYW5nZSxiKSksYSh3aW5kb3cpLm9uKFwicmVzaXplLnNsaWNrLnNsaWNrLVwiK2IuaW5zdGFuY2VVaWQsYS5wcm94eShiLnJlc2l6ZSxiKSksYShcIltkcmFnZ2FibGUhPXRydWVdXCIsYi4kc2xpZGVUcmFjaykub24oXCJkcmFnc3RhcnRcIixiLnByZXZlbnREZWZhdWx0KSxhKHdpbmRvdykub24oXCJsb2FkLnNsaWNrLnNsaWNrLVwiK2IuaW5zdGFuY2VVaWQsYi5zZXRQb3NpdGlvbiksYShkb2N1bWVudCkub24oXCJyZWFkeS5zbGljay5zbGljay1cIitiLmluc3RhbmNlVWlkLGIuc2V0UG9zaXRpb24pfSxiLnByb3RvdHlwZS5pbml0VUk9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2Eub3B0aW9ucy5hcnJvd3M9PT0hMCYmYS5zbGlkZUNvdW50PmEub3B0aW9ucy5zbGlkZXNUb1Nob3cmJihhLiRwcmV2QXJyb3cuc2hvdygpLGEuJG5leHRBcnJvdy5zaG93KCkpLGEub3B0aW9ucy5kb3RzPT09ITAmJmEuc2xpZGVDb3VudD5hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiZhLiRkb3RzLnNob3coKX0sYi5wcm90b3R5cGUua2V5SGFuZGxlcj1mdW5jdGlvbihhKXt2YXIgYj10aGlzO2EudGFyZ2V0LnRhZ05hbWUubWF0Y2goXCJURVhUQVJFQXxJTlBVVHxTRUxFQ1RcIil8fCgzNz09PWEua2V5Q29kZSYmYi5vcHRpb25zLmFjY2Vzc2liaWxpdHk9PT0hMD9iLmNoYW5nZVNsaWRlKHtkYXRhOnttZXNzYWdlOmIub3B0aW9ucy5ydGw9PT0hMD9cIm5leHRcIjpcInByZXZpb3VzXCJ9fSk6Mzk9PT1hLmtleUNvZGUmJmIub3B0aW9ucy5hY2Nlc3NpYmlsaXR5PT09ITAmJmIuY2hhbmdlU2xpZGUoe2RhdGE6e21lc3NhZ2U6Yi5vcHRpb25zLnJ0bD09PSEwP1wicHJldmlvdXNcIjpcIm5leHRcIn19KSl9LGIucHJvdG90eXBlLmxhenlMb2FkPWZ1bmN0aW9uKCl7ZnVuY3Rpb24gZyhjKXthKFwiaW1nW2RhdGEtbGF6eV1cIixjKS5lYWNoKGZ1bmN0aW9uKCl7dmFyIGM9YSh0aGlzKSxkPWEodGhpcykuYXR0cihcImRhdGEtbGF6eVwiKSxlPWRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpbWdcIik7ZS5vbmxvYWQ9ZnVuY3Rpb24oKXtjLmFuaW1hdGUoe29wYWNpdHk6MH0sMTAwLGZ1bmN0aW9uKCl7Yy5hdHRyKFwic3JjXCIsZCkuYW5pbWF0ZSh7b3BhY2l0eToxfSwyMDAsZnVuY3Rpb24oKXtjLnJlbW92ZUF0dHIoXCJkYXRhLWxhenlcIikucmVtb3ZlQ2xhc3MoXCJzbGljay1sb2FkaW5nXCIpfSksYi4kc2xpZGVyLnRyaWdnZXIoXCJsYXp5TG9hZGVkXCIsW2IsYyxkXSl9KX0sZS5vbmVycm9yPWZ1bmN0aW9uKCl7Yy5yZW1vdmVBdHRyKFwiZGF0YS1sYXp5XCIpLnJlbW92ZUNsYXNzKFwic2xpY2stbG9hZGluZ1wiKS5hZGRDbGFzcyhcInNsaWNrLWxhenlsb2FkLWVycm9yXCIpLGIuJHNsaWRlci50cmlnZ2VyKFwibGF6eUxvYWRFcnJvclwiLFtiLGMsZF0pfSxlLnNyYz1kfSl9dmFyIGMsZCxlLGYsYj10aGlzO2Iub3B0aW9ucy5jZW50ZXJNb2RlPT09ITA/Yi5vcHRpb25zLmluZmluaXRlPT09ITA/KGU9Yi5jdXJyZW50U2xpZGUrKGIub3B0aW9ucy5zbGlkZXNUb1Nob3cvMisxKSxmPWUrYi5vcHRpb25zLnNsaWRlc1RvU2hvdysyKTooZT1NYXRoLm1heCgwLGIuY3VycmVudFNsaWRlLShiLm9wdGlvbnMuc2xpZGVzVG9TaG93LzIrMSkpLGY9MisoYi5vcHRpb25zLnNsaWRlc1RvU2hvdy8yKzEpK2IuY3VycmVudFNsaWRlKTooZT1iLm9wdGlvbnMuaW5maW5pdGU/Yi5vcHRpb25zLnNsaWRlc1RvU2hvdytiLmN1cnJlbnRTbGlkZTpiLmN1cnJlbnRTbGlkZSxmPU1hdGguY2VpbChlK2Iub3B0aW9ucy5zbGlkZXNUb1Nob3cpLGIub3B0aW9ucy5mYWRlPT09ITAmJihlPjAmJmUtLSxmPD1iLnNsaWRlQ291bnQmJmYrKykpLGM9Yi4kc2xpZGVyLmZpbmQoXCIuc2xpY2stc2xpZGVcIikuc2xpY2UoZSxmKSxnKGMpLGIuc2xpZGVDb3VudDw9Yi5vcHRpb25zLnNsaWRlc1RvU2hvdz8oZD1iLiRzbGlkZXIuZmluZChcIi5zbGljay1zbGlkZVwiKSxnKGQpKTpiLmN1cnJlbnRTbGlkZT49Yi5zbGlkZUNvdW50LWIub3B0aW9ucy5zbGlkZXNUb1Nob3c/KGQ9Yi4kc2xpZGVyLmZpbmQoXCIuc2xpY2stY2xvbmVkXCIpLnNsaWNlKDAsYi5vcHRpb25zLnNsaWRlc1RvU2hvdyksZyhkKSk6MD09PWIuY3VycmVudFNsaWRlJiYoZD1iLiRzbGlkZXIuZmluZChcIi5zbGljay1jbG9uZWRcIikuc2xpY2UoLTEqYi5vcHRpb25zLnNsaWRlc1RvU2hvdyksZyhkKSl9LGIucHJvdG90eXBlLmxvYWRTbGlkZXI9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2Euc2V0UG9zaXRpb24oKSxhLiRzbGlkZVRyYWNrLmNzcyh7b3BhY2l0eToxfSksYS4kc2xpZGVyLnJlbW92ZUNsYXNzKFwic2xpY2stbG9hZGluZ1wiKSxhLmluaXRVSSgpLFwicHJvZ3Jlc3NpdmVcIj09PWEub3B0aW9ucy5sYXp5TG9hZCYmYS5wcm9ncmVzc2l2ZUxhenlMb2FkKCl9LGIucHJvdG90eXBlLm5leHQ9Yi5wcm90b3R5cGUuc2xpY2tOZXh0PWZ1bmN0aW9uKCl7dmFyIGE9dGhpczthLmNoYW5nZVNsaWRlKHtkYXRhOnttZXNzYWdlOlwibmV4dFwifX0pfSxiLnByb3RvdHlwZS5vcmllbnRhdGlvbkNoYW5nZT1mdW5jdGlvbigpe3ZhciBhPXRoaXM7YS5jaGVja1Jlc3BvbnNpdmUoKSxhLnNldFBvc2l0aW9uKCl9LGIucHJvdG90eXBlLnBhdXNlPWIucHJvdG90eXBlLnNsaWNrUGF1c2U9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2EuYXV0b1BsYXlDbGVhcigpLGEucGF1c2VkPSEwfSxiLnByb3RvdHlwZS5wbGF5PWIucHJvdG90eXBlLnNsaWNrUGxheT1mdW5jdGlvbigpe3ZhciBhPXRoaXM7YS5hdXRvUGxheSgpLGEub3B0aW9ucy5hdXRvcGxheT0hMCxhLnBhdXNlZD0hMSxhLmZvY3Vzc2VkPSExLGEuaW50ZXJydXB0ZWQ9ITF9LGIucHJvdG90eXBlLnBvc3RTbGlkZT1mdW5jdGlvbihhKXt2YXIgYj10aGlzO2IudW5zbGlja2VkfHwoYi4kc2xpZGVyLnRyaWdnZXIoXCJhZnRlckNoYW5nZVwiLFtiLGFdKSxiLmFuaW1hdGluZz0hMSxiLnNldFBvc2l0aW9uKCksYi5zd2lwZUxlZnQ9bnVsbCxiLm9wdGlvbnMuYXV0b3BsYXkmJmIuYXV0b1BsYXkoKSxiLm9wdGlvbnMuYWNjZXNzaWJpbGl0eT09PSEwJiZiLmluaXRBREEoKSl9LGIucHJvdG90eXBlLnByZXY9Yi5wcm90b3R5cGUuc2xpY2tQcmV2PWZ1bmN0aW9uKCl7dmFyIGE9dGhpczthLmNoYW5nZVNsaWRlKHtkYXRhOnttZXNzYWdlOlwicHJldmlvdXNcIn19KX0sYi5wcm90b3R5cGUucHJldmVudERlZmF1bHQ9ZnVuY3Rpb24oYSl7YS5wcmV2ZW50RGVmYXVsdCgpfSxiLnByb3RvdHlwZS5wcm9ncmVzc2l2ZUxhenlMb2FkPWZ1bmN0aW9uKGIpe2I9Ynx8MTt2YXIgZSxmLGcsYz10aGlzLGQ9YShcImltZ1tkYXRhLWxhenldXCIsYy4kc2xpZGVyKTtkLmxlbmd0aD8oZT1kLmZpcnN0KCksZj1lLmF0dHIoXCJkYXRhLWxhenlcIiksZz1kb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaW1nXCIpLGcub25sb2FkPWZ1bmN0aW9uKCl7ZS5hdHRyKFwic3JjXCIsZikucmVtb3ZlQXR0cihcImRhdGEtbGF6eVwiKS5yZW1vdmVDbGFzcyhcInNsaWNrLWxvYWRpbmdcIiksYy5vcHRpb25zLmFkYXB0aXZlSGVpZ2h0PT09ITAmJmMuc2V0UG9zaXRpb24oKSxjLiRzbGlkZXIudHJpZ2dlcihcImxhenlMb2FkZWRcIixbYyxlLGZdKSxjLnByb2dyZXNzaXZlTGF6eUxvYWQoKX0sZy5vbmVycm9yPWZ1bmN0aW9uKCl7Mz5iP3NldFRpbWVvdXQoZnVuY3Rpb24oKXtjLnByb2dyZXNzaXZlTGF6eUxvYWQoYisxKX0sNTAwKTooZS5yZW1vdmVBdHRyKFwiZGF0YS1sYXp5XCIpLnJlbW92ZUNsYXNzKFwic2xpY2stbG9hZGluZ1wiKS5hZGRDbGFzcyhcInNsaWNrLWxhenlsb2FkLWVycm9yXCIpLGMuJHNsaWRlci50cmlnZ2VyKFwibGF6eUxvYWRFcnJvclwiLFtjLGUsZl0pLGMucHJvZ3Jlc3NpdmVMYXp5TG9hZCgpKX0sZy5zcmM9Zik6Yy4kc2xpZGVyLnRyaWdnZXIoXCJhbGxJbWFnZXNMb2FkZWRcIixbY10pfSxiLnByb3RvdHlwZS5yZWZyZXNoPWZ1bmN0aW9uKGIpe3ZhciBkLGUsYz10aGlzO2U9Yy5zbGlkZUNvdW50LWMub3B0aW9ucy5zbGlkZXNUb1Nob3csIWMub3B0aW9ucy5pbmZpbml0ZSYmYy5jdXJyZW50U2xpZGU+ZSYmKGMuY3VycmVudFNsaWRlPWUpLGMuc2xpZGVDb3VudDw9Yy5vcHRpb25zLnNsaWRlc1RvU2hvdyYmKGMuY3VycmVudFNsaWRlPTApLGQ9Yy5jdXJyZW50U2xpZGUsYy5kZXN0cm95KCEwKSxhLmV4dGVuZChjLGMuaW5pdGlhbHMse2N1cnJlbnRTbGlkZTpkfSksYy5pbml0KCksYnx8Yy5jaGFuZ2VTbGlkZSh7ZGF0YTp7bWVzc2FnZTpcImluZGV4XCIsaW5kZXg6ZH19LCExKX0sYi5wcm90b3R5cGUucmVnaXN0ZXJCcmVha3BvaW50cz1mdW5jdGlvbigpe3ZhciBjLGQsZSxiPXRoaXMsZj1iLm9wdGlvbnMucmVzcG9uc2l2ZXx8bnVsbDtpZihcImFycmF5XCI9PT1hLnR5cGUoZikmJmYubGVuZ3RoKXtiLnJlc3BvbmRUbz1iLm9wdGlvbnMucmVzcG9uZFRvfHxcIndpbmRvd1wiO2ZvcihjIGluIGYpaWYoZT1iLmJyZWFrcG9pbnRzLmxlbmd0aC0xLGQ9ZltjXS5icmVha3BvaW50LGYuaGFzT3duUHJvcGVydHkoYykpe2Zvcig7ZT49MDspYi5icmVha3BvaW50c1tlXSYmYi5icmVha3BvaW50c1tlXT09PWQmJmIuYnJlYWtwb2ludHMuc3BsaWNlKGUsMSksZS0tO2IuYnJlYWtwb2ludHMucHVzaChkKSxiLmJyZWFrcG9pbnRTZXR0aW5nc1tkXT1mW2NdLnNldHRpbmdzfWIuYnJlYWtwb2ludHMuc29ydChmdW5jdGlvbihhLGMpe3JldHVybiBiLm9wdGlvbnMubW9iaWxlRmlyc3Q/YS1jOmMtYX0pfX0sYi5wcm90b3R5cGUucmVpbml0PWZ1bmN0aW9uKCl7dmFyIGI9dGhpcztiLiRzbGlkZXM9Yi4kc2xpZGVUcmFjay5jaGlsZHJlbihiLm9wdGlvbnMuc2xpZGUpLmFkZENsYXNzKFwic2xpY2stc2xpZGVcIiksYi5zbGlkZUNvdW50PWIuJHNsaWRlcy5sZW5ndGgsYi5jdXJyZW50U2xpZGU+PWIuc2xpZGVDb3VudCYmMCE9PWIuY3VycmVudFNsaWRlJiYoYi5jdXJyZW50U2xpZGU9Yi5jdXJyZW50U2xpZGUtYi5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsKSxiLnNsaWRlQ291bnQ8PWIub3B0aW9ucy5zbGlkZXNUb1Nob3cmJihiLmN1cnJlbnRTbGlkZT0wKSxiLnJlZ2lzdGVyQnJlYWtwb2ludHMoKSxiLnNldFByb3BzKCksYi5zZXR1cEluZmluaXRlKCksYi5idWlsZEFycm93cygpLGIudXBkYXRlQXJyb3dzKCksYi5pbml0QXJyb3dFdmVudHMoKSxiLmJ1aWxkRG90cygpLGIudXBkYXRlRG90cygpLGIuaW5pdERvdEV2ZW50cygpLGIuY2xlYW5VcFNsaWRlRXZlbnRzKCksYi5pbml0U2xpZGVFdmVudHMoKSxiLmNoZWNrUmVzcG9uc2l2ZSghMSwhMCksYi5vcHRpb25zLmZvY3VzT25TZWxlY3Q9PT0hMCYmYShiLiRzbGlkZVRyYWNrKS5jaGlsZHJlbigpLm9uKFwiY2xpY2suc2xpY2tcIixiLnNlbGVjdEhhbmRsZXIpLGIuc2V0U2xpZGVDbGFzc2VzKFwibnVtYmVyXCI9PXR5cGVvZiBiLmN1cnJlbnRTbGlkZT9iLmN1cnJlbnRTbGlkZTowKSxiLnNldFBvc2l0aW9uKCksYi5mb2N1c0hhbmRsZXIoKSxiLnBhdXNlZD0hYi5vcHRpb25zLmF1dG9wbGF5LGIuYXV0b1BsYXkoKSxiLiRzbGlkZXIudHJpZ2dlcihcInJlSW5pdFwiLFtiXSl9LGIucHJvdG90eXBlLnJlc2l6ZT1mdW5jdGlvbigpe3ZhciBiPXRoaXM7YSh3aW5kb3cpLndpZHRoKCkhPT1iLndpbmRvd1dpZHRoJiYoY2xlYXJUaW1lb3V0KGIud2luZG93RGVsYXkpLGIud2luZG93RGVsYXk9d2luZG93LnNldFRpbWVvdXQoZnVuY3Rpb24oKXtiLndpbmRvd1dpZHRoPWEod2luZG93KS53aWR0aCgpLGIuY2hlY2tSZXNwb25zaXZlKCksYi51bnNsaWNrZWR8fGIuc2V0UG9zaXRpb24oKX0sNTApKX0sYi5wcm90b3R5cGUucmVtb3ZlU2xpZGU9Yi5wcm90b3R5cGUuc2xpY2tSZW1vdmU9ZnVuY3Rpb24oYSxiLGMpe3ZhciBkPXRoaXM7cmV0dXJuXCJib29sZWFuXCI9PXR5cGVvZiBhPyhiPWEsYT1iPT09ITA/MDpkLnNsaWRlQ291bnQtMSk6YT1iPT09ITA/LS1hOmEsZC5zbGlkZUNvdW50PDF8fDA+YXx8YT5kLnNsaWRlQ291bnQtMT8hMTooZC51bmxvYWQoKSxjPT09ITA/ZC4kc2xpZGVUcmFjay5jaGlsZHJlbigpLnJlbW92ZSgpOmQuJHNsaWRlVHJhY2suY2hpbGRyZW4odGhpcy5vcHRpb25zLnNsaWRlKS5lcShhKS5yZW1vdmUoKSxkLiRzbGlkZXM9ZC4kc2xpZGVUcmFjay5jaGlsZHJlbih0aGlzLm9wdGlvbnMuc2xpZGUpLGQuJHNsaWRlVHJhY2suY2hpbGRyZW4odGhpcy5vcHRpb25zLnNsaWRlKS5kZXRhY2goKSxkLiRzbGlkZVRyYWNrLmFwcGVuZChkLiRzbGlkZXMpLGQuJHNsaWRlc0NhY2hlPWQuJHNsaWRlcyx2b2lkIGQucmVpbml0KCkpfSxiLnByb3RvdHlwZS5zZXRDU1M9ZnVuY3Rpb24oYSl7dmFyIGQsZSxiPXRoaXMsYz17fTtiLm9wdGlvbnMucnRsPT09ITAmJihhPS1hKSxkPVwibGVmdFwiPT1iLnBvc2l0aW9uUHJvcD9NYXRoLmNlaWwoYSkrXCJweFwiOlwiMHB4XCIsZT1cInRvcFwiPT1iLnBvc2l0aW9uUHJvcD9NYXRoLmNlaWwoYSkrXCJweFwiOlwiMHB4XCIsY1tiLnBvc2l0aW9uUHJvcF09YSxiLnRyYW5zZm9ybXNFbmFibGVkPT09ITE/Yi4kc2xpZGVUcmFjay5jc3MoYyk6KGM9e30sYi5jc3NUcmFuc2l0aW9ucz09PSExPyhjW2IuYW5pbVR5cGVdPVwidHJhbnNsYXRlKFwiK2QrXCIsIFwiK2UrXCIpXCIsYi4kc2xpZGVUcmFjay5jc3MoYykpOihjW2IuYW5pbVR5cGVdPVwidHJhbnNsYXRlM2QoXCIrZCtcIiwgXCIrZStcIiwgMHB4KVwiLGIuJHNsaWRlVHJhY2suY3NzKGMpKSl9LGIucHJvdG90eXBlLnNldERpbWVuc2lvbnM9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2Eub3B0aW9ucy52ZXJ0aWNhbD09PSExP2Eub3B0aW9ucy5jZW50ZXJNb2RlPT09ITAmJmEuJGxpc3QuY3NzKHtwYWRkaW5nOlwiMHB4IFwiK2Eub3B0aW9ucy5jZW50ZXJQYWRkaW5nfSk6KGEuJGxpc3QuaGVpZ2h0KGEuJHNsaWRlcy5maXJzdCgpLm91dGVySGVpZ2h0KCEwKSphLm9wdGlvbnMuc2xpZGVzVG9TaG93KSxhLm9wdGlvbnMuY2VudGVyTW9kZT09PSEwJiZhLiRsaXN0LmNzcyh7cGFkZGluZzphLm9wdGlvbnMuY2VudGVyUGFkZGluZytcIiAwcHhcIn0pKSxhLmxpc3RXaWR0aD1hLiRsaXN0LndpZHRoKCksYS5saXN0SGVpZ2h0PWEuJGxpc3QuaGVpZ2h0KCksYS5vcHRpb25zLnZlcnRpY2FsPT09ITEmJmEub3B0aW9ucy52YXJpYWJsZVdpZHRoPT09ITE/KGEuc2xpZGVXaWR0aD1NYXRoLmNlaWwoYS5saXN0V2lkdGgvYS5vcHRpb25zLnNsaWRlc1RvU2hvdyksYS4kc2xpZGVUcmFjay53aWR0aChNYXRoLmNlaWwoYS5zbGlkZVdpZHRoKmEuJHNsaWRlVHJhY2suY2hpbGRyZW4oXCIuc2xpY2stc2xpZGVcIikubGVuZ3RoKSkpOmEub3B0aW9ucy52YXJpYWJsZVdpZHRoPT09ITA/YS4kc2xpZGVUcmFjay53aWR0aCg1ZTMqYS5zbGlkZUNvdW50KTooYS5zbGlkZVdpZHRoPU1hdGguY2VpbChhLmxpc3RXaWR0aCksYS4kc2xpZGVUcmFjay5oZWlnaHQoTWF0aC5jZWlsKGEuJHNsaWRlcy5maXJzdCgpLm91dGVySGVpZ2h0KCEwKSphLiRzbGlkZVRyYWNrLmNoaWxkcmVuKFwiLnNsaWNrLXNsaWRlXCIpLmxlbmd0aCkpKTt2YXIgYj1hLiRzbGlkZXMuZmlyc3QoKS5vdXRlcldpZHRoKCEwKS1hLiRzbGlkZXMuZmlyc3QoKS53aWR0aCgpO2Eub3B0aW9ucy52YXJpYWJsZVdpZHRoPT09ITEmJmEuJHNsaWRlVHJhY2suY2hpbGRyZW4oXCIuc2xpY2stc2xpZGVcIikud2lkdGgoYS5zbGlkZVdpZHRoLWIpfSxiLnByb3RvdHlwZS5zZXRGYWRlPWZ1bmN0aW9uKCl7dmFyIGMsYj10aGlzO2IuJHNsaWRlcy5lYWNoKGZ1bmN0aW9uKGQsZSl7Yz1iLnNsaWRlV2lkdGgqZCotMSxiLm9wdGlvbnMucnRsPT09ITA/YShlKS5jc3Moe3Bvc2l0aW9uOlwicmVsYXRpdmVcIixyaWdodDpjLHRvcDowLHpJbmRleDpiLm9wdGlvbnMuekluZGV4LTIsb3BhY2l0eTowfSk6YShlKS5jc3Moe3Bvc2l0aW9uOlwicmVsYXRpdmVcIixsZWZ0OmMsdG9wOjAsekluZGV4OmIub3B0aW9ucy56SW5kZXgtMixvcGFjaXR5OjB9KX0pLGIuJHNsaWRlcy5lcShiLmN1cnJlbnRTbGlkZSkuY3NzKHt6SW5kZXg6Yi5vcHRpb25zLnpJbmRleC0xLG9wYWNpdHk6MX0pfSxiLnByb3RvdHlwZS5zZXRIZWlnaHQ9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2lmKDE9PT1hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiZhLm9wdGlvbnMuYWRhcHRpdmVIZWlnaHQ9PT0hMCYmYS5vcHRpb25zLnZlcnRpY2FsPT09ITEpe3ZhciBiPWEuJHNsaWRlcy5lcShhLmN1cnJlbnRTbGlkZSkub3V0ZXJIZWlnaHQoITApO2EuJGxpc3QuY3NzKFwiaGVpZ2h0XCIsYil9fSxiLnByb3RvdHlwZS5zZXRPcHRpb249Yi5wcm90b3R5cGUuc2xpY2tTZXRPcHRpb249ZnVuY3Rpb24oKXt2YXIgYyxkLGUsZixoLGI9dGhpcyxnPSExO2lmKFwib2JqZWN0XCI9PT1hLnR5cGUoYXJndW1lbnRzWzBdKT8oZT1hcmd1bWVudHNbMF0sZz1hcmd1bWVudHNbMV0saD1cIm11bHRpcGxlXCIpOlwic3RyaW5nXCI9PT1hLnR5cGUoYXJndW1lbnRzWzBdKSYmKGU9YXJndW1lbnRzWzBdLGY9YXJndW1lbnRzWzFdLGc9YXJndW1lbnRzWzJdLFwicmVzcG9uc2l2ZVwiPT09YXJndW1lbnRzWzBdJiZcImFycmF5XCI9PT1hLnR5cGUoYXJndW1lbnRzWzFdKT9oPVwicmVzcG9uc2l2ZVwiOlwidW5kZWZpbmVkXCIhPXR5cGVvZiBhcmd1bWVudHNbMV0mJihoPVwic2luZ2xlXCIpKSxcInNpbmdsZVwiPT09aCliLm9wdGlvbnNbZV09ZjtlbHNlIGlmKFwibXVsdGlwbGVcIj09PWgpYS5lYWNoKGUsZnVuY3Rpb24oYSxjKXtiLm9wdGlvbnNbYV09Y30pO2Vsc2UgaWYoXCJyZXNwb25zaXZlXCI9PT1oKWZvcihkIGluIGYpaWYoXCJhcnJheVwiIT09YS50eXBlKGIub3B0aW9ucy5yZXNwb25zaXZlKSliLm9wdGlvbnMucmVzcG9uc2l2ZT1bZltkXV07ZWxzZXtmb3IoYz1iLm9wdGlvbnMucmVzcG9uc2l2ZS5sZW5ndGgtMTtjPj0wOyliLm9wdGlvbnMucmVzcG9uc2l2ZVtjXS5icmVha3BvaW50PT09ZltkXS5icmVha3BvaW50JiZiLm9wdGlvbnMucmVzcG9uc2l2ZS5zcGxpY2UoYywxKSxjLS07Yi5vcHRpb25zLnJlc3BvbnNpdmUucHVzaChmW2RdKX1nJiYoYi51bmxvYWQoKSxiLnJlaW5pdCgpKX0sYi5wcm90b3R5cGUuc2V0UG9zaXRpb249ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2Euc2V0RGltZW5zaW9ucygpLGEuc2V0SGVpZ2h0KCksYS5vcHRpb25zLmZhZGU9PT0hMT9hLnNldENTUyhhLmdldExlZnQoYS5jdXJyZW50U2xpZGUpKTphLnNldEZhZGUoKSxhLiRzbGlkZXIudHJpZ2dlcihcInNldFBvc2l0aW9uXCIsW2FdKX0sYi5wcm90b3R5cGUuc2V0UHJvcHM9ZnVuY3Rpb24oKXt2YXIgYT10aGlzLGI9ZG9jdW1lbnQuYm9keS5zdHlsZTthLnBvc2l0aW9uUHJvcD1hLm9wdGlvbnMudmVydGljYWw9PT0hMD9cInRvcFwiOlwibGVmdFwiLFwidG9wXCI9PT1hLnBvc2l0aW9uUHJvcD9hLiRzbGlkZXIuYWRkQ2xhc3MoXCJzbGljay12ZXJ0aWNhbFwiKTphLiRzbGlkZXIucmVtb3ZlQ2xhc3MoXCJzbGljay12ZXJ0aWNhbFwiKSwodm9pZCAwIT09Yi5XZWJraXRUcmFuc2l0aW9ufHx2b2lkIDAhPT1iLk1velRyYW5zaXRpb258fHZvaWQgMCE9PWIubXNUcmFuc2l0aW9uKSYmYS5vcHRpb25zLnVzZUNTUz09PSEwJiYoYS5jc3NUcmFuc2l0aW9ucz0hMCksYS5vcHRpb25zLmZhZGUmJihcIm51bWJlclwiPT10eXBlb2YgYS5vcHRpb25zLnpJbmRleD9hLm9wdGlvbnMuekluZGV4PDMmJihhLm9wdGlvbnMuekluZGV4PTMpOmEub3B0aW9ucy56SW5kZXg9YS5kZWZhdWx0cy56SW5kZXgpLHZvaWQgMCE9PWIuT1RyYW5zZm9ybSYmKGEuYW5pbVR5cGU9XCJPVHJhbnNmb3JtXCIsYS50cmFuc2Zvcm1UeXBlPVwiLW8tdHJhbnNmb3JtXCIsYS50cmFuc2l0aW9uVHlwZT1cIk9UcmFuc2l0aW9uXCIsdm9pZCAwPT09Yi5wZXJzcGVjdGl2ZVByb3BlcnR5JiZ2b2lkIDA9PT1iLndlYmtpdFBlcnNwZWN0aXZlJiYoYS5hbmltVHlwZT0hMSkpLHZvaWQgMCE9PWIuTW96VHJhbnNmb3JtJiYoYS5hbmltVHlwZT1cIk1velRyYW5zZm9ybVwiLGEudHJhbnNmb3JtVHlwZT1cIi1tb3otdHJhbnNmb3JtXCIsYS50cmFuc2l0aW9uVHlwZT1cIk1velRyYW5zaXRpb25cIix2b2lkIDA9PT1iLnBlcnNwZWN0aXZlUHJvcGVydHkmJnZvaWQgMD09PWIuTW96UGVyc3BlY3RpdmUmJihhLmFuaW1UeXBlPSExKSksdm9pZCAwIT09Yi53ZWJraXRUcmFuc2Zvcm0mJihhLmFuaW1UeXBlPVwid2Via2l0VHJhbnNmb3JtXCIsYS50cmFuc2Zvcm1UeXBlPVwiLXdlYmtpdC10cmFuc2Zvcm1cIixhLnRyYW5zaXRpb25UeXBlPVwid2Via2l0VHJhbnNpdGlvblwiLHZvaWQgMD09PWIucGVyc3BlY3RpdmVQcm9wZXJ0eSYmdm9pZCAwPT09Yi53ZWJraXRQZXJzcGVjdGl2ZSYmKGEuYW5pbVR5cGU9ITEpKSx2b2lkIDAhPT1iLm1zVHJhbnNmb3JtJiYoYS5hbmltVHlwZT1cIm1zVHJhbnNmb3JtXCIsYS50cmFuc2Zvcm1UeXBlPVwiLW1zLXRyYW5zZm9ybVwiLGEudHJhbnNpdGlvblR5cGU9XCJtc1RyYW5zaXRpb25cIix2b2lkIDA9PT1iLm1zVHJhbnNmb3JtJiYoYS5hbmltVHlwZT0hMSkpLHZvaWQgMCE9PWIudHJhbnNmb3JtJiZhLmFuaW1UeXBlIT09ITEmJihhLmFuaW1UeXBlPVwidHJhbnNmb3JtXCIsYS50cmFuc2Zvcm1UeXBlPVwidHJhbnNmb3JtXCIsYS50cmFuc2l0aW9uVHlwZT1cInRyYW5zaXRpb25cIiksYS50cmFuc2Zvcm1zRW5hYmxlZD1hLm9wdGlvbnMudXNlVHJhbnNmb3JtJiZudWxsIT09YS5hbmltVHlwZSYmYS5hbmltVHlwZSE9PSExfSxiLnByb3RvdHlwZS5zZXRTbGlkZUNsYXNzZXM9ZnVuY3Rpb24oYSl7dmFyIGMsZCxlLGYsYj10aGlzO2Q9Yi4kc2xpZGVyLmZpbmQoXCIuc2xpY2stc2xpZGVcIikucmVtb3ZlQ2xhc3MoXCJzbGljay1hY3RpdmUgc2xpY2stY2VudGVyIHNsaWNrLWN1cnJlbnRcIikuYXR0cihcImFyaWEtaGlkZGVuXCIsXCJ0cnVlXCIpLGIuJHNsaWRlcy5lcShhKS5hZGRDbGFzcyhcInNsaWNrLWN1cnJlbnRcIiksYi5vcHRpb25zLmNlbnRlck1vZGU9PT0hMD8oYz1NYXRoLmZsb29yKGIub3B0aW9ucy5zbGlkZXNUb1Nob3cvMiksYi5vcHRpb25zLmluZmluaXRlPT09ITAmJihhPj1jJiZhPD1iLnNsaWRlQ291bnQtMS1jP2IuJHNsaWRlcy5zbGljZShhLWMsYStjKzEpLmFkZENsYXNzKFwic2xpY2stYWN0aXZlXCIpLmF0dHIoXCJhcmlhLWhpZGRlblwiLFwiZmFsc2VcIik6KGU9Yi5vcHRpb25zLnNsaWRlc1RvU2hvdythLFxuZC5zbGljZShlLWMrMSxlK2MrMikuYWRkQ2xhc3MoXCJzbGljay1hY3RpdmVcIikuYXR0cihcImFyaWEtaGlkZGVuXCIsXCJmYWxzZVwiKSksMD09PWE/ZC5lcShkLmxlbmd0aC0xLWIub3B0aW9ucy5zbGlkZXNUb1Nob3cpLmFkZENsYXNzKFwic2xpY2stY2VudGVyXCIpOmE9PT1iLnNsaWRlQ291bnQtMSYmZC5lcShiLm9wdGlvbnMuc2xpZGVzVG9TaG93KS5hZGRDbGFzcyhcInNsaWNrLWNlbnRlclwiKSksYi4kc2xpZGVzLmVxKGEpLmFkZENsYXNzKFwic2xpY2stY2VudGVyXCIpKTphPj0wJiZhPD1iLnNsaWRlQ291bnQtYi5vcHRpb25zLnNsaWRlc1RvU2hvdz9iLiRzbGlkZXMuc2xpY2UoYSxhK2Iub3B0aW9ucy5zbGlkZXNUb1Nob3cpLmFkZENsYXNzKFwic2xpY2stYWN0aXZlXCIpLmF0dHIoXCJhcmlhLWhpZGRlblwiLFwiZmFsc2VcIik6ZC5sZW5ndGg8PWIub3B0aW9ucy5zbGlkZXNUb1Nob3c/ZC5hZGRDbGFzcyhcInNsaWNrLWFjdGl2ZVwiKS5hdHRyKFwiYXJpYS1oaWRkZW5cIixcImZhbHNlXCIpOihmPWIuc2xpZGVDb3VudCViLm9wdGlvbnMuc2xpZGVzVG9TaG93LGU9Yi5vcHRpb25zLmluZmluaXRlPT09ITA/Yi5vcHRpb25zLnNsaWRlc1RvU2hvdythOmEsYi5vcHRpb25zLnNsaWRlc1RvU2hvdz09Yi5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsJiZiLnNsaWRlQ291bnQtYTxiLm9wdGlvbnMuc2xpZGVzVG9TaG93P2Quc2xpY2UoZS0oYi5vcHRpb25zLnNsaWRlc1RvU2hvdy1mKSxlK2YpLmFkZENsYXNzKFwic2xpY2stYWN0aXZlXCIpLmF0dHIoXCJhcmlhLWhpZGRlblwiLFwiZmFsc2VcIik6ZC5zbGljZShlLGUrYi5vcHRpb25zLnNsaWRlc1RvU2hvdykuYWRkQ2xhc3MoXCJzbGljay1hY3RpdmVcIikuYXR0cihcImFyaWEtaGlkZGVuXCIsXCJmYWxzZVwiKSksXCJvbmRlbWFuZFwiPT09Yi5vcHRpb25zLmxhenlMb2FkJiZiLmxhenlMb2FkKCl9LGIucHJvdG90eXBlLnNldHVwSW5maW5pdGU9ZnVuY3Rpb24oKXt2YXIgYyxkLGUsYj10aGlzO2lmKGIub3B0aW9ucy5mYWRlPT09ITAmJihiLm9wdGlvbnMuY2VudGVyTW9kZT0hMSksYi5vcHRpb25zLmluZmluaXRlPT09ITAmJmIub3B0aW9ucy5mYWRlPT09ITEmJihkPW51bGwsYi5zbGlkZUNvdW50PmIub3B0aW9ucy5zbGlkZXNUb1Nob3cpKXtmb3IoZT1iLm9wdGlvbnMuY2VudGVyTW9kZT09PSEwP2Iub3B0aW9ucy5zbGlkZXNUb1Nob3crMTpiLm9wdGlvbnMuc2xpZGVzVG9TaG93LGM9Yi5zbGlkZUNvdW50O2M+Yi5zbGlkZUNvdW50LWU7Yy09MSlkPWMtMSxhKGIuJHNsaWRlc1tkXSkuY2xvbmUoITApLmF0dHIoXCJpZFwiLFwiXCIpLmF0dHIoXCJkYXRhLXNsaWNrLWluZGV4XCIsZC1iLnNsaWRlQ291bnQpLnByZXBlbmRUbyhiLiRzbGlkZVRyYWNrKS5hZGRDbGFzcyhcInNsaWNrLWNsb25lZFwiKTtmb3IoYz0wO2U+YztjKz0xKWQ9YyxhKGIuJHNsaWRlc1tkXSkuY2xvbmUoITApLmF0dHIoXCJpZFwiLFwiXCIpLmF0dHIoXCJkYXRhLXNsaWNrLWluZGV4XCIsZCtiLnNsaWRlQ291bnQpLmFwcGVuZFRvKGIuJHNsaWRlVHJhY2spLmFkZENsYXNzKFwic2xpY2stY2xvbmVkXCIpO2IuJHNsaWRlVHJhY2suZmluZChcIi5zbGljay1jbG9uZWRcIikuZmluZChcIltpZF1cIikuZWFjaChmdW5jdGlvbigpe2EodGhpcykuYXR0cihcImlkXCIsXCJcIil9KX19LGIucHJvdG90eXBlLmludGVycnVwdD1mdW5jdGlvbihhKXt2YXIgYj10aGlzO2F8fGIuYXV0b1BsYXkoKSxiLmludGVycnVwdGVkPWF9LGIucHJvdG90eXBlLnNlbGVjdEhhbmRsZXI9ZnVuY3Rpb24oYil7dmFyIGM9dGhpcyxkPWEoYi50YXJnZXQpLmlzKFwiLnNsaWNrLXNsaWRlXCIpP2EoYi50YXJnZXQpOmEoYi50YXJnZXQpLnBhcmVudHMoXCIuc2xpY2stc2xpZGVcIiksZT1wYXJzZUludChkLmF0dHIoXCJkYXRhLXNsaWNrLWluZGV4XCIpKTtyZXR1cm4gZXx8KGU9MCksYy5zbGlkZUNvdW50PD1jLm9wdGlvbnMuc2xpZGVzVG9TaG93PyhjLnNldFNsaWRlQ2xhc3NlcyhlKSx2b2lkIGMuYXNOYXZGb3IoZSkpOnZvaWQgYy5zbGlkZUhhbmRsZXIoZSl9LGIucHJvdG90eXBlLnNsaWRlSGFuZGxlcj1mdW5jdGlvbihhLGIsYyl7dmFyIGQsZSxmLGcsaixoPW51bGwsaT10aGlzO3JldHVybiBiPWJ8fCExLGkuYW5pbWF0aW5nPT09ITAmJmkub3B0aW9ucy53YWl0Rm9yQW5pbWF0ZT09PSEwfHxpLm9wdGlvbnMuZmFkZT09PSEwJiZpLmN1cnJlbnRTbGlkZT09PWF8fGkuc2xpZGVDb3VudDw9aS5vcHRpb25zLnNsaWRlc1RvU2hvdz92b2lkIDA6KGI9PT0hMSYmaS5hc05hdkZvcihhKSxkPWEsaD1pLmdldExlZnQoZCksZz1pLmdldExlZnQoaS5jdXJyZW50U2xpZGUpLGkuY3VycmVudExlZnQ9bnVsbD09PWkuc3dpcGVMZWZ0P2c6aS5zd2lwZUxlZnQsaS5vcHRpb25zLmluZmluaXRlPT09ITEmJmkub3B0aW9ucy5jZW50ZXJNb2RlPT09ITEmJigwPmF8fGE+aS5nZXREb3RDb3VudCgpKmkub3B0aW9ucy5zbGlkZXNUb1Njcm9sbCk/dm9pZChpLm9wdGlvbnMuZmFkZT09PSExJiYoZD1pLmN1cnJlbnRTbGlkZSxjIT09ITA/aS5hbmltYXRlU2xpZGUoZyxmdW5jdGlvbigpe2kucG9zdFNsaWRlKGQpfSk6aS5wb3N0U2xpZGUoZCkpKTppLm9wdGlvbnMuaW5maW5pdGU9PT0hMSYmaS5vcHRpb25zLmNlbnRlck1vZGU9PT0hMCYmKDA+YXx8YT5pLnNsaWRlQ291bnQtaS5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsKT92b2lkKGkub3B0aW9ucy5mYWRlPT09ITEmJihkPWkuY3VycmVudFNsaWRlLGMhPT0hMD9pLmFuaW1hdGVTbGlkZShnLGZ1bmN0aW9uKCl7aS5wb3N0U2xpZGUoZCl9KTppLnBvc3RTbGlkZShkKSkpOihpLm9wdGlvbnMuYXV0b3BsYXkmJmNsZWFySW50ZXJ2YWwoaS5hdXRvUGxheVRpbWVyKSxlPTA+ZD9pLnNsaWRlQ291bnQlaS5vcHRpb25zLnNsaWRlc1RvU2Nyb2xsIT09MD9pLnNsaWRlQ291bnQtaS5zbGlkZUNvdW50JWkub3B0aW9ucy5zbGlkZXNUb1Njcm9sbDppLnNsaWRlQ291bnQrZDpkPj1pLnNsaWRlQ291bnQ/aS5zbGlkZUNvdW50JWkub3B0aW9ucy5zbGlkZXNUb1Njcm9sbCE9PTA/MDpkLWkuc2xpZGVDb3VudDpkLGkuYW5pbWF0aW5nPSEwLGkuJHNsaWRlci50cmlnZ2VyKFwiYmVmb3JlQ2hhbmdlXCIsW2ksaS5jdXJyZW50U2xpZGUsZV0pLGY9aS5jdXJyZW50U2xpZGUsaS5jdXJyZW50U2xpZGU9ZSxpLnNldFNsaWRlQ2xhc3NlcyhpLmN1cnJlbnRTbGlkZSksaS5vcHRpb25zLmFzTmF2Rm9yJiYoaj1pLmdldE5hdlRhcmdldCgpLGo9ai5zbGljayhcImdldFNsaWNrXCIpLGouc2xpZGVDb3VudDw9ai5vcHRpb25zLnNsaWRlc1RvU2hvdyYmai5zZXRTbGlkZUNsYXNzZXMoaS5jdXJyZW50U2xpZGUpKSxpLnVwZGF0ZURvdHMoKSxpLnVwZGF0ZUFycm93cygpLGkub3B0aW9ucy5mYWRlPT09ITA/KGMhPT0hMD8oaS5mYWRlU2xpZGVPdXQoZiksaS5mYWRlU2xpZGUoZSxmdW5jdGlvbigpe2kucG9zdFNsaWRlKGUpfSkpOmkucG9zdFNsaWRlKGUpLHZvaWQgaS5hbmltYXRlSGVpZ2h0KCkpOnZvaWQoYyE9PSEwP2kuYW5pbWF0ZVNsaWRlKGgsZnVuY3Rpb24oKXtpLnBvc3RTbGlkZShlKX0pOmkucG9zdFNsaWRlKGUpKSkpfSxiLnByb3RvdHlwZS5zdGFydExvYWQ9ZnVuY3Rpb24oKXt2YXIgYT10aGlzO2Eub3B0aW9ucy5hcnJvd3M9PT0hMCYmYS5zbGlkZUNvdW50PmEub3B0aW9ucy5zbGlkZXNUb1Nob3cmJihhLiRwcmV2QXJyb3cuaGlkZSgpLGEuJG5leHRBcnJvdy5oaWRlKCkpLGEub3B0aW9ucy5kb3RzPT09ITAmJmEuc2xpZGVDb3VudD5hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiZhLiRkb3RzLmhpZGUoKSxhLiRzbGlkZXIuYWRkQ2xhc3MoXCJzbGljay1sb2FkaW5nXCIpfSxiLnByb3RvdHlwZS5zd2lwZURpcmVjdGlvbj1mdW5jdGlvbigpe3ZhciBhLGIsYyxkLGU9dGhpcztyZXR1cm4gYT1lLnRvdWNoT2JqZWN0LnN0YXJ0WC1lLnRvdWNoT2JqZWN0LmN1clgsYj1lLnRvdWNoT2JqZWN0LnN0YXJ0WS1lLnRvdWNoT2JqZWN0LmN1clksYz1NYXRoLmF0YW4yKGIsYSksZD1NYXRoLnJvdW5kKDE4MCpjL01hdGguUEkpLDA+ZCYmKGQ9MzYwLU1hdGguYWJzKGQpKSw0NT49ZCYmZD49MD9lLm9wdGlvbnMucnRsPT09ITE/XCJsZWZ0XCI6XCJyaWdodFwiOjM2MD49ZCYmZD49MzE1P2Uub3B0aW9ucy5ydGw9PT0hMT9cImxlZnRcIjpcInJpZ2h0XCI6ZD49MTM1JiYyMjU+PWQ/ZS5vcHRpb25zLnJ0bD09PSExP1wicmlnaHRcIjpcImxlZnRcIjplLm9wdGlvbnMudmVydGljYWxTd2lwaW5nPT09ITA/ZD49MzUmJjEzNT49ZD9cImRvd25cIjpcInVwXCI6XCJ2ZXJ0aWNhbFwifSxiLnByb3RvdHlwZS5zd2lwZUVuZD1mdW5jdGlvbihhKXt2YXIgYyxkLGI9dGhpcztpZihiLmRyYWdnaW5nPSExLGIuaW50ZXJydXB0ZWQ9ITEsYi5zaG91bGRDbGljaz1iLnRvdWNoT2JqZWN0LnN3aXBlTGVuZ3RoPjEwPyExOiEwLHZvaWQgMD09PWIudG91Y2hPYmplY3QuY3VyWClyZXR1cm4hMTtpZihiLnRvdWNoT2JqZWN0LmVkZ2VIaXQ9PT0hMCYmYi4kc2xpZGVyLnRyaWdnZXIoXCJlZGdlXCIsW2IsYi5zd2lwZURpcmVjdGlvbigpXSksYi50b3VjaE9iamVjdC5zd2lwZUxlbmd0aD49Yi50b3VjaE9iamVjdC5taW5Td2lwZSl7c3dpdGNoKGQ9Yi5zd2lwZURpcmVjdGlvbigpKXtjYXNlXCJsZWZ0XCI6Y2FzZVwiZG93blwiOmM9Yi5vcHRpb25zLnN3aXBlVG9TbGlkZT9iLmNoZWNrTmF2aWdhYmxlKGIuY3VycmVudFNsaWRlK2IuZ2V0U2xpZGVDb3VudCgpKTpiLmN1cnJlbnRTbGlkZStiLmdldFNsaWRlQ291bnQoKSxiLmN1cnJlbnREaXJlY3Rpb249MDticmVhaztjYXNlXCJyaWdodFwiOmNhc2VcInVwXCI6Yz1iLm9wdGlvbnMuc3dpcGVUb1NsaWRlP2IuY2hlY2tOYXZpZ2FibGUoYi5jdXJyZW50U2xpZGUtYi5nZXRTbGlkZUNvdW50KCkpOmIuY3VycmVudFNsaWRlLWIuZ2V0U2xpZGVDb3VudCgpLGIuY3VycmVudERpcmVjdGlvbj0xfVwidmVydGljYWxcIiE9ZCYmKGIuc2xpZGVIYW5kbGVyKGMpLGIudG91Y2hPYmplY3Q9e30sYi4kc2xpZGVyLnRyaWdnZXIoXCJzd2lwZVwiLFtiLGRdKSl9ZWxzZSBiLnRvdWNoT2JqZWN0LnN0YXJ0WCE9PWIudG91Y2hPYmplY3QuY3VyWCYmKGIuc2xpZGVIYW5kbGVyKGIuY3VycmVudFNsaWRlKSxiLnRvdWNoT2JqZWN0PXt9KX0sYi5wcm90b3R5cGUuc3dpcGVIYW5kbGVyPWZ1bmN0aW9uKGEpe3ZhciBiPXRoaXM7aWYoIShiLm9wdGlvbnMuc3dpcGU9PT0hMXx8XCJvbnRvdWNoZW5kXCJpbiBkb2N1bWVudCYmYi5vcHRpb25zLnN3aXBlPT09ITF8fGIub3B0aW9ucy5kcmFnZ2FibGU9PT0hMSYmLTEhPT1hLnR5cGUuaW5kZXhPZihcIm1vdXNlXCIpKSlzd2l0Y2goYi50b3VjaE9iamVjdC5maW5nZXJDb3VudD1hLm9yaWdpbmFsRXZlbnQmJnZvaWQgMCE9PWEub3JpZ2luYWxFdmVudC50b3VjaGVzP2Eub3JpZ2luYWxFdmVudC50b3VjaGVzLmxlbmd0aDoxLGIudG91Y2hPYmplY3QubWluU3dpcGU9Yi5saXN0V2lkdGgvYi5vcHRpb25zLnRvdWNoVGhyZXNob2xkLGIub3B0aW9ucy52ZXJ0aWNhbFN3aXBpbmc9PT0hMCYmKGIudG91Y2hPYmplY3QubWluU3dpcGU9Yi5saXN0SGVpZ2h0L2Iub3B0aW9ucy50b3VjaFRocmVzaG9sZCksYS5kYXRhLmFjdGlvbil7Y2FzZVwic3RhcnRcIjpiLnN3aXBlU3RhcnQoYSk7YnJlYWs7Y2FzZVwibW92ZVwiOmIuc3dpcGVNb3ZlKGEpO2JyZWFrO2Nhc2VcImVuZFwiOmIuc3dpcGVFbmQoYSl9fSxiLnByb3RvdHlwZS5zd2lwZU1vdmU9ZnVuY3Rpb24oYSl7dmFyIGQsZSxmLGcsaCxiPXRoaXM7cmV0dXJuIGg9dm9pZCAwIT09YS5vcmlnaW5hbEV2ZW50P2Eub3JpZ2luYWxFdmVudC50b3VjaGVzOm51bGwsIWIuZHJhZ2dpbmd8fGgmJjEhPT1oLmxlbmd0aD8hMTooZD1iLmdldExlZnQoYi5jdXJyZW50U2xpZGUpLGIudG91Y2hPYmplY3QuY3VyWD12b2lkIDAhPT1oP2hbMF0ucGFnZVg6YS5jbGllbnRYLGIudG91Y2hPYmplY3QuY3VyWT12b2lkIDAhPT1oP2hbMF0ucGFnZVk6YS5jbGllbnRZLGIudG91Y2hPYmplY3Quc3dpcGVMZW5ndGg9TWF0aC5yb3VuZChNYXRoLnNxcnQoTWF0aC5wb3coYi50b3VjaE9iamVjdC5jdXJYLWIudG91Y2hPYmplY3Quc3RhcnRYLDIpKSksYi5vcHRpb25zLnZlcnRpY2FsU3dpcGluZz09PSEwJiYoYi50b3VjaE9iamVjdC5zd2lwZUxlbmd0aD1NYXRoLnJvdW5kKE1hdGguc3FydChNYXRoLnBvdyhiLnRvdWNoT2JqZWN0LmN1clktYi50b3VjaE9iamVjdC5zdGFydFksMikpKSksZT1iLnN3aXBlRGlyZWN0aW9uKCksXCJ2ZXJ0aWNhbFwiIT09ZT8odm9pZCAwIT09YS5vcmlnaW5hbEV2ZW50JiZiLnRvdWNoT2JqZWN0LnN3aXBlTGVuZ3RoPjQmJmEucHJldmVudERlZmF1bHQoKSxnPShiLm9wdGlvbnMucnRsPT09ITE/MTotMSkqKGIudG91Y2hPYmplY3QuY3VyWD5iLnRvdWNoT2JqZWN0LnN0YXJ0WD8xOi0xKSxiLm9wdGlvbnMudmVydGljYWxTd2lwaW5nPT09ITAmJihnPWIudG91Y2hPYmplY3QuY3VyWT5iLnRvdWNoT2JqZWN0LnN0YXJ0WT8xOi0xKSxmPWIudG91Y2hPYmplY3Quc3dpcGVMZW5ndGgsYi50b3VjaE9iamVjdC5lZGdlSGl0PSExLGIub3B0aW9ucy5pbmZpbml0ZT09PSExJiYoMD09PWIuY3VycmVudFNsaWRlJiZcInJpZ2h0XCI9PT1lfHxiLmN1cnJlbnRTbGlkZT49Yi5nZXREb3RDb3VudCgpJiZcImxlZnRcIj09PWUpJiYoZj1iLnRvdWNoT2JqZWN0LnN3aXBlTGVuZ3RoKmIub3B0aW9ucy5lZGdlRnJpY3Rpb24sYi50b3VjaE9iamVjdC5lZGdlSGl0PSEwKSxiLm9wdGlvbnMudmVydGljYWw9PT0hMT9iLnN3aXBlTGVmdD1kK2YqZzpiLnN3aXBlTGVmdD1kK2YqKGIuJGxpc3QuaGVpZ2h0KCkvYi5saXN0V2lkdGgpKmcsYi5vcHRpb25zLnZlcnRpY2FsU3dpcGluZz09PSEwJiYoYi5zd2lwZUxlZnQ9ZCtmKmcpLGIub3B0aW9ucy5mYWRlPT09ITB8fGIub3B0aW9ucy50b3VjaE1vdmU9PT0hMT8hMTpiLmFuaW1hdGluZz09PSEwPyhiLnN3aXBlTGVmdD1udWxsLCExKTp2b2lkIGIuc2V0Q1NTKGIuc3dpcGVMZWZ0KSk6dm9pZCAwKX0sYi5wcm90b3R5cGUuc3dpcGVTdGFydD1mdW5jdGlvbihhKXt2YXIgYyxiPXRoaXM7cmV0dXJuIGIuaW50ZXJydXB0ZWQ9ITAsMSE9PWIudG91Y2hPYmplY3QuZmluZ2VyQ291bnR8fGIuc2xpZGVDb3VudDw9Yi5vcHRpb25zLnNsaWRlc1RvU2hvdz8oYi50b3VjaE9iamVjdD17fSwhMSk6KHZvaWQgMCE9PWEub3JpZ2luYWxFdmVudCYmdm9pZCAwIT09YS5vcmlnaW5hbEV2ZW50LnRvdWNoZXMmJihjPWEub3JpZ2luYWxFdmVudC50b3VjaGVzWzBdKSxiLnRvdWNoT2JqZWN0LnN0YXJ0WD1iLnRvdWNoT2JqZWN0LmN1clg9dm9pZCAwIT09Yz9jLnBhZ2VYOmEuY2xpZW50WCxiLnRvdWNoT2JqZWN0LnN0YXJ0WT1iLnRvdWNoT2JqZWN0LmN1clk9dm9pZCAwIT09Yz9jLnBhZ2VZOmEuY2xpZW50WSx2b2lkKGIuZHJhZ2dpbmc9ITApKX0sYi5wcm90b3R5cGUudW5maWx0ZXJTbGlkZXM9Yi5wcm90b3R5cGUuc2xpY2tVbmZpbHRlcj1mdW5jdGlvbigpe3ZhciBhPXRoaXM7bnVsbCE9PWEuJHNsaWRlc0NhY2hlJiYoYS51bmxvYWQoKSxhLiRzbGlkZVRyYWNrLmNoaWxkcmVuKHRoaXMub3B0aW9ucy5zbGlkZSkuZGV0YWNoKCksYS4kc2xpZGVzQ2FjaGUuYXBwZW5kVG8oYS4kc2xpZGVUcmFjayksYS5yZWluaXQoKSl9LGIucHJvdG90eXBlLnVubG9hZD1mdW5jdGlvbigpe3ZhciBiPXRoaXM7YShcIi5zbGljay1jbG9uZWRcIixiLiRzbGlkZXIpLnJlbW92ZSgpLGIuJGRvdHMmJmIuJGRvdHMucmVtb3ZlKCksYi4kcHJldkFycm93JiZiLmh0bWxFeHByLnRlc3QoYi5vcHRpb25zLnByZXZBcnJvdykmJmIuJHByZXZBcnJvdy5yZW1vdmUoKSxiLiRuZXh0QXJyb3cmJmIuaHRtbEV4cHIudGVzdChiLm9wdGlvbnMubmV4dEFycm93KSYmYi4kbmV4dEFycm93LnJlbW92ZSgpLGIuJHNsaWRlcy5yZW1vdmVDbGFzcyhcInNsaWNrLXNsaWRlIHNsaWNrLWFjdGl2ZSBzbGljay12aXNpYmxlIHNsaWNrLWN1cnJlbnRcIikuYXR0cihcImFyaWEtaGlkZGVuXCIsXCJ0cnVlXCIpLmNzcyhcIndpZHRoXCIsXCJcIil9LGIucHJvdG90eXBlLnVuc2xpY2s9ZnVuY3Rpb24oYSl7dmFyIGI9dGhpcztiLiRzbGlkZXIudHJpZ2dlcihcInVuc2xpY2tcIixbYixhXSksYi5kZXN0cm95KCl9LGIucHJvdG90eXBlLnVwZGF0ZUFycm93cz1mdW5jdGlvbigpe3ZhciBiLGE9dGhpcztiPU1hdGguZmxvb3IoYS5vcHRpb25zLnNsaWRlc1RvU2hvdy8yKSxhLm9wdGlvbnMuYXJyb3dzPT09ITAmJmEuc2xpZGVDb3VudD5hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiYhYS5vcHRpb25zLmluZmluaXRlJiYoYS4kcHJldkFycm93LnJlbW92ZUNsYXNzKFwic2xpY2stZGlzYWJsZWRcIikuYXR0cihcImFyaWEtZGlzYWJsZWRcIixcImZhbHNlXCIpLGEuJG5leHRBcnJvdy5yZW1vdmVDbGFzcyhcInNsaWNrLWRpc2FibGVkXCIpLmF0dHIoXCJhcmlhLWRpc2FibGVkXCIsXCJmYWxzZVwiKSwwPT09YS5jdXJyZW50U2xpZGU/KGEuJHByZXZBcnJvdy5hZGRDbGFzcyhcInNsaWNrLWRpc2FibGVkXCIpLmF0dHIoXCJhcmlhLWRpc2FibGVkXCIsXCJ0cnVlXCIpLGEuJG5leHRBcnJvdy5yZW1vdmVDbGFzcyhcInNsaWNrLWRpc2FibGVkXCIpLmF0dHIoXCJhcmlhLWRpc2FibGVkXCIsXCJmYWxzZVwiKSk6YS5jdXJyZW50U2xpZGU+PWEuc2xpZGVDb3VudC1hLm9wdGlvbnMuc2xpZGVzVG9TaG93JiZhLm9wdGlvbnMuY2VudGVyTW9kZT09PSExPyhhLiRuZXh0QXJyb3cuYWRkQ2xhc3MoXCJzbGljay1kaXNhYmxlZFwiKS5hdHRyKFwiYXJpYS1kaXNhYmxlZFwiLFwidHJ1ZVwiKSxhLiRwcmV2QXJyb3cucmVtb3ZlQ2xhc3MoXCJzbGljay1kaXNhYmxlZFwiKS5hdHRyKFwiYXJpYS1kaXNhYmxlZFwiLFwiZmFsc2VcIikpOmEuY3VycmVudFNsaWRlPj1hLnNsaWRlQ291bnQtMSYmYS5vcHRpb25zLmNlbnRlck1vZGU9PT0hMCYmKGEuJG5leHRBcnJvdy5hZGRDbGFzcyhcInNsaWNrLWRpc2FibGVkXCIpLmF0dHIoXCJhcmlhLWRpc2FibGVkXCIsXCJ0cnVlXCIpLGEuJHByZXZBcnJvdy5yZW1vdmVDbGFzcyhcInNsaWNrLWRpc2FibGVkXCIpLmF0dHIoXCJhcmlhLWRpc2FibGVkXCIsXCJmYWxzZVwiKSkpfSxiLnByb3RvdHlwZS51cGRhdGVEb3RzPWZ1bmN0aW9uKCl7dmFyIGE9dGhpcztudWxsIT09YS4kZG90cyYmKGEuJGRvdHMuZmluZChcImxpXCIpLnJlbW92ZUNsYXNzKFwic2xpY2stYWN0aXZlXCIpLmF0dHIoXCJhcmlhLWhpZGRlblwiLFwidHJ1ZVwiKSxhLiRkb3RzLmZpbmQoXCJsaVwiKS5lcShNYXRoLmZsb29yKGEuY3VycmVudFNsaWRlL2Eub3B0aW9ucy5zbGlkZXNUb1Njcm9sbCkpLmFkZENsYXNzKFwic2xpY2stYWN0aXZlXCIpLmF0dHIoXCJhcmlhLWhpZGRlblwiLFwiZmFsc2VcIikpfSxiLnByb3RvdHlwZS52aXNpYmlsaXR5PWZ1bmN0aW9uKCl7dmFyIGE9dGhpczthLm9wdGlvbnMuYXV0b3BsYXkmJihkb2N1bWVudFthLmhpZGRlbl0/YS5pbnRlcnJ1cHRlZD0hMDphLmludGVycnVwdGVkPSExKX0sYS5mbi5zbGljaz1mdW5jdGlvbigpe3ZhciBmLGcsYT10aGlzLGM9YXJndW1lbnRzWzBdLGQ9QXJyYXkucHJvdG90eXBlLnNsaWNlLmNhbGwoYXJndW1lbnRzLDEpLGU9YS5sZW5ndGg7Zm9yKGY9MDtlPmY7ZisrKWlmKFwib2JqZWN0XCI9PXR5cGVvZiBjfHxcInVuZGVmaW5lZFwiPT10eXBlb2YgYz9hW2ZdLnNsaWNrPW5ldyBiKGFbZl0sYyk6Zz1hW2ZdLnNsaWNrW2NdLmFwcGx5KGFbZl0uc2xpY2ssZCksXCJ1bmRlZmluZWRcIiE9dHlwZW9mIGcpcmV0dXJuIGc7cmV0dXJuIGF9fSk7IiwiLyoqXG4gKiBJbml0IEhlcm8gc2xpZGVycy5cbiAqXG4gKiBUaGlzIGp1c3QgdGFrZXMgYWxsIHRoZSBzbGlkZXJzIHBsYWNlcyBvbiB0aGUgcGFnZVxuICogYW5kIGluaXRpYXRlcyBTbGljayBKUyB0byBhbmltYXRlIGFuZCBzbGlkZSB0aGVtLlxuICpcbiAqIEBwYXJhbSAge09iamVjdH0gJCBqUXVlcnlcbiAqL1xuKCBmdW5jdGlvbiggJCApIHtcblx0Ly8gQW55dGhpbmcgd2l0aCBkYXRhIGF0dGFjaGVkIHRvIGl0LCBzbGljayBpdCFcblx0JCggJy5oZXJvIC5zbGlkZXJzJyApLmVhY2goIGZ1bmN0aW9uKCBpLCB2ICkge1xuXHRcdHZhciBzcGVlZCA9ICQoIHRoaXMgKS5hdHRyKCAnZGF0YS1zbGlkZXItc3BlZWQnICk7XG5cblx0XHQkKCB0aGlzICkuc2xpY2soIHtcblx0XHRcdHNsaWRlc1RvU2hvdzogICAgMSxcblx0XHRcdHNsaWRlc1RvU2Nyb2xsOiAgMSxcblx0XHRcdGF1dG9wbGF5OiAgICAgICAgdHJ1ZSxcblx0XHRcdGF1dG9wbGF5U3BlZWQ6ICAgc3BlZWQgKiAxMDAwLFxuXHRcdFx0ZG90czpcdFx0XHRcdHRydWUsXG5cdFx0XHRwcmV2QXJyb3c6ICcnLFxuXHRcdFx0bmV4dEFycm93OiAnJyxcblx0XHR9ICk7XG5cdH0gKTtcbn0gKSggalF1ZXJ5ICk7XG4iLCIvKipcbiAqIEZpbGUgd2luZG93LXJlYWR5LmpzXG4gKlxuICogQWRkIGEgXCJyZWFkeVwiIGNsYXNzIHRvIDxib2R5PiB3aGVuIHdpbmRvdyBpcyByZWFkeS5cbiAqL1xud2luZG93LldpbmRvd19SZWFkeSA9IHt9O1xuKCBmdW5jdGlvbiggd2luZG93LCAkLCBhcHAgKSB7XG5cblx0Ly8gQ29uc3RydWN0b3IuXG5cdGFwcC5pbml0ID0gZnVuY3Rpb24oKSB7XG5cdFx0YXBwLmNhY2hlKCk7XG5cdFx0YXBwLmJpbmRFdmVudHMoKTtcblx0fTtcblxuXHQvLyBDYWNoZSBkb2N1bWVudCBlbGVtZW50cy5cblx0YXBwLmNhY2hlID0gZnVuY3Rpb24oKSB7XG5cdFx0YXBwLiRjID0ge1xuXHRcdFx0d2luZG93OiAkKCB3aW5kb3cgKSxcblx0XHRcdGJvZHk6ICQoIGRvY3VtZW50LmJvZHkgKSxcblx0XHR9O1xuXHR9O1xuXG5cdC8vIENvbWJpbmUgYWxsIGV2ZW50cy5cblx0YXBwLmJpbmRFdmVudHMgPSBmdW5jdGlvbigpIHtcblx0XHRhcHAuJGMud2luZG93LmxvYWQoIGFwcC5hZGRCb2R5Q2xhc3MgKTtcblx0fTtcblxuXHQvLyBBZGQgYSBjbGFzcyB0byA8Ym9keT4uXG5cdGFwcC5hZGRCb2R5Q2xhc3MgPSBmdW5jdGlvbigpIHtcblx0XHRhcHAuJGMuYm9keS5hZGRDbGFzcyggJ3JlYWR5JyApO1xuXHR9O1xuXG5cdC8vIEVuZ2FnZSFcblx0JCggYXBwLmluaXQgKTtcblxufSkoIHdpbmRvdywgalF1ZXJ5LCB3aW5kb3cuV2luZG93X1JlYWR5ICk7Il0sInNvdXJjZVJvb3QiOiIvc291cmNlLyJ9
