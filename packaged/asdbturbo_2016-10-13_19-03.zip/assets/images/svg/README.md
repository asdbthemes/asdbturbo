# Using SVG images with wd_s

If you don't want your SVGs to be optimized and concatenated, then drop them here and use
them like you would any ol image.