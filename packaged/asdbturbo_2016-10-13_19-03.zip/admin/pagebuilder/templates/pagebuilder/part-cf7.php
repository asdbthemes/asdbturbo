<?php
/**
 * Part Name: Contact Form 7
 * Description:
 */

$cf7 = wds_page_builder_get_this_part_data( 'cf7' );
?>

<?php echo do_shortcode( '[contact-form-7 id="'.$cf7.'"]' ); ?>
