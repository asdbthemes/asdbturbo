<?php
/**
Template Name: FrontPage
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package asdbTurbo
 * @since asdbTurbo 1.0.0
 */

get_header(); ?>

	<div class="wrap">

		<div class="primary-area content-area">
			<main id="main" class="site-main" role="main">

				<?php while ( have_posts() ) : the_post(); ?>

					<?php get_template_part( 'parts/content/content', 'front' ); ?>

				<?php endwhile; // End of the loop.	?>

			</main><!-- #main -->
		</div><!-- .primary -->

		<?php get_sidebar(); ?>

	</div><!-- .wrap -->

<?php get_footer(); ?>