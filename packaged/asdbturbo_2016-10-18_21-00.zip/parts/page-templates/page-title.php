<section class="page-header">
	<div class="page-title">
		<h2><?php echo asdb_page_title(); ?></h2>
	</div><!--/.page-title-->
</section><!--/.sub-header-->
