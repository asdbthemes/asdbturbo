<?php
global $asdbblock;

?>

<div class="mod10 mod_wrap">

    <div class="entry-meta">
        <?php echo get_blocks_time_date();?>
    </div>

    <?php echo get_blocks_title();?>

    <div class="entry-excerpt excerpt">
        <?php echo get_blocks_excerpt(18);?>
    </div>

</div>
